 <div class="row">
    <div class="col-md-12">
      <div class="box">
        
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Foto</td>
                <td>Nama</td>
                <td>Tempat / Tanggal Lahir</td>
                <td>Jenis Kelamin</td>
                <td>Alamat</td>
                <td>No HP</td>
                <td>Email</td>
                <td>Instagram</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $y_n = ['Tidak', 'Ya'];
            $satuan_masa_aktif = ['Hari', 'Bulan'];
            foreach ($instruktur as $d1) { 
                if ($d1['foto']=='') { 
                $src_foto = base_url('assets/gambar/user.webp');  
                }else{ 
                $src_foto = base_url('file/instruktur/'.$d1['foto']); 
                } 
                ?>

              <tr>
                <td><?php echo $no++ ?></td>
                <td>
                  
                <img class=" img-responsive " src="<?php echo $src_foto  ?>" alt="User profile picture" width="100px">
                </td>
                <td><?php echo $d1['nama'] ?></td>
                <td><?php echo $d1['tmpl'].' / '.$d1['tgll'] ?></td>
                <td><?php echo $d1['jk'] ?></td>
                <td><?php echo $d1['alamat'] ?></td>
                <td><?php echo $d1['no_hp'] ?></td>
                <td><?php echo $d1['email'] ?></td>
                <td><?php echo $d1['ig'] ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
              
                <td>

                 <button type="button" class="btn btn-info btn-xs" onclick="detail('<?php echo enkripsi($d1['id_instruktur']) ?>')">
                Detail
              </button>
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit" onclick="edit('<?php echo $d1['id_instruktur'] ?>')">
                Edit
              </button>
                	
                 <button type="button" class="btn btn-info btn-xs" onclick="nonaktifkan('<?php echo $d1['id_instruktur'] ?>','<?php echo $d1['nama'] ?>')">
                Nonaktifkan
              </button>
                
                </td>
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/instruktur/simpan') ?>" method='post' enctype="multipart/form-data">  
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Instruktur</h4>
              </div>
              <div class="modal-body">











                  <div class="row">
                    <div class="col-md-6">
                       <div class="form-group">
                          <label>Nama</label>
                          <input type="text" name="nama" id="nama" class="form-control" required>
                        </div>
                     
                        <div class="form-group">
                          <label>Jenis Kelamin</label>
                          <select name="jk" id="jk" class="form-control" required>
                            <option>Laki laki</option>
                            <option>Perempuan</option>
                          </select>
                        </div>
                         <div class="form-group">
                          <label>Tempat Lahir</label>
                          <input type="text" name="tmpl" id="tmpl" class="form-control" required>
                        </div>
                        <div class="form-group">
                          <label>Tanggal Lahir</label>
                          <div class="row">
                            <div class="col-md-3">
                              <select class="form-control" name="tgll" id="tgll">
                                <?php for ($i=1; $i <= 31 ; $i++) { ?>
                                <option><?php echo $i ?></option>
                                <?php } ?>
                              </select>
                              
                            </div>
                            <div class="col-md-6">
                              <select class="form-control" name="blll" id="blll">
                                <?php for ($i=1; $i <= 12 ; $i++) { ?>
                                <option value="<?php echo $i ?>"><?php echo bulan_global($i) ?></option>
                                <?php } ?>
                              </select>
                            </div>
                            <div class="col-md-3">
                              <select class="form-control" name="thll" id="thll">
                                <?php for ($i=date('Y'); $i >= 1945 ; $i--) { ?>
                                <option><?php echo $i ?></option>
                                <?php } ?>
                              </select>
                              
                            </div>
                            
                          </div>
                        </div>

                      <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" required>
                      </div>


                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Pekerjaan</label>
                        <input type="text" name="pekerjaan" id="pekerjaan" class="form-control">
                      </div>
                      <div class="form-group">
                        <label>No HP</label>
                        <input type="text" name="nohp" id="nohp" class="form-control" required>
                      </div>
                      <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" id="email" class="form-control">
                      </div>
                      <div class="form-group">
                        <label>Instagram</label>
                        <input type="text" name="ig" id="ig" class="form-control">
                      </div>
                      <div class="form-group">
                        <label>Foto</label>
                        <input type="file" name="berkas" id="ig" class="form-control">
                      </div>
                     
                      
                    </div>
                  </div>

                    
             

                  





              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>




  <div class="modal fade" id="edit">
    <form action="<?php echo base_url('user/admin/instruktur/simpanedit') ?>" method='post' enctype="multipart/form-data">  
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Instruktur</h4>
              </div>
              <div class="modal-body">






                          <input type="" name="foto_lama" id="foto_lama" class="form-control">





                  <div class="row">
                    <div class="col-md-6">
                       <div class="form-group">
                          <label>Nama</label>
                          <input type="text" name="nama" id="nama" class="form-control" required>
                          <input type="hidden" name="id_instruktur" id="id_instruktur" class="form-control">
                        </div>
                     
                        <div class="form-group">
                          <label>Jenis Kelamin</label>
                          <select name="jk" id="jk" class="form-control" required>
                            <option>Laki laki</option>
                            <option>Perempuan</option>
                          </select>
                        </div>
                         <div class="form-group">
                          <label>Tempat Lahir</label>
                          <input type="text" name="tmpl" id="tmpl" class="form-control" required>
                        </div>
                        <div class="form-group">
                          <label>Tanggal Lahir</label>
                          <div class="row">
                            <div class="col-md-3">
                              <select class="form-control" name="tgll" id="tgll">
                                <?php for ($i=1; $i <= 31 ; $i++) { ?>
                                <option><?php echo $i ?></option>
                                <?php } ?>
                              </select>
                              
                            </div>
                            <div class="col-md-6">
                              <select class="form-control" name="blll" id="blll">
                                <?php for ($i=1; $i <= 12 ; $i++) { ?>
                                <option value="<?php echo $i ?>"><?php echo bulan_global($i) ?></option>
                                <?php } ?>
                              </select>
                            </div>
                            <div class="col-md-3">
                              <select class="form-control" name="thll" id="thll">
                                <?php for ($i=date('Y'); $i >= 1945 ; $i--) { ?>
                                <option><?php echo $i ?></option>
                                <?php } ?>
                              </select>
                              
                            </div>
                            
                          </div>
                        </div>

                      <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" required>
                      </div>
                       <div class="form-group">
                        <label>Pekerjaan</label>
                        <input type="text" name="pekerjaan" id="pekerjaan" class="form-control">
                      </div>

                    </div>
                    <div class="col-md-6">
                     
                      <div class="form-group">
                        <label>No HP</label>
                        <input type="text" name="nohp" id="nohp" class="form-control" required>
                      </div>
                      <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" id="email" class="form-control">
                      </div>
                      <div class="form-group">
                        <label>Instagram</label>
                        <input type="text" name="ig" id="ig" class="form-control">
                      </div>
                      <div class="form-group">
                        <label>Foto</label>
                        <input type="file" name="berkas" id="ig" class="form-control">
                      </div>
                       <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" name="status" id="status">
                          <option value="1">Aktif</option>
                          <option value="0">Tidak Aktif</option>
                        </select>
                      </div>

                     
                      
                    </div>
                  </div>

                    
             

                  





              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>





<script>
  

function nonaktifkan(id_instruktur, instruktur)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan Instruktur '+instruktur+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/instruktur/nonaktifkan'),
              type    : 'POST',
              data    : { 
                id_instruktur : id_instruktur,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/instruktur');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_instruktur)
  {
            $.ajax(
            {
              url     : baseUrl('/user/admin/instruktur/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_instruktur : id_instruktur,
                
              },
              success : function(data)
              {

    var pecah = data.tgll.split('-');
    console.log(data.foto);
                  $('#edit').find('#id_instruktur').val(data.id_instruktur);
                  $('#edit').find('#foto_lama').val(data.foto);
                  $('#edit').find('#nama').val(data.nama);
                  $('#edit').find('#jk').val(data.jk);
                  $('#edit').find('#tmpl').val(data.tmpl);
                  $('#edit').find('#tgll').val(pecah[2]).change();
                  $('#edit').find('#blll').val(pecah[1]).change();
                  $('#edit').find('#thll').val(pecah[0]).change();
                  $('#edit').find('#alamat').val(data.alamat);
                  $('#edit').find('#pekerjaan').val(data.pekerjaan);
                  $('#edit').find('#nohp').val(data.no_hp);
                  $('#edit').find('#email').val(data.email);
                  $('#edit').find('#ig').val(data.ig);
                  $('#edit').find('#status').val(data.status).change();


              },
              error : function(){
              }
            });
          }
      

function detail(id_instruktur)
  {
    window.location.href="<?php echo base_url('user/admin/instruktur/detail/') ?>" + id_instruktur
  }
      

</script>









