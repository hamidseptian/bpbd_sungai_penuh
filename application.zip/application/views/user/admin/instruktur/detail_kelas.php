 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Nama Paket</td>
                <td>Banyak Pertemuan</td>
                <td>Masa Aktif</td>
                <td>Biaya</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            foreach ($instruktur_kelas as $d1) { 

              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['nama_paket_kelas'] ?></td>
                <td><?php echo $d1['banyak_pertemuan'] ?> Kali</td>
                <td><?php echo $d1['masa_aktif'].' '.$d1['satuan_masa_aktif'] ?></td>
                <td><?php echo number_format($d1['biaya']) ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>
               
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit" onclick="edit('<?php echo $d1['id_detail_kelas'] ?>')">
                Edit
              </button>
                 <button type="button" class="btn btn-info btn-xs" onclick="nonaktifkan('<?php echo $d1['id_detail_kelas'] ?>','<?php echo $d1['nama_paket_kelas'] ?>','<?php echo $kelas['kelas'] ?>')">
                Nonaktifkan
              </button>
                 
                </td>
              </tr>

            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>







<script>
  

function nonaktifkan(id_detail_kelas, detail_kelas, kelas)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan  paket '+ detail_kelas+' pada kelas '+kelas+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/kelas/nonaktifkan_detail_kelas'),
              type    : 'POST',
              data    : { 
                id_detail_kelas : id_detail_kelas,
                kelas : detail_kelas,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/kelas/detail/<?php echo enkripsi($kelas['id_kelas']) ?>');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



function edit(id_detail_kelas)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/kelas/edit_detail'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_detail_kelas : id_detail_kelas,
                
              },
              success : function(data)
              {
                console.log(data);
                  $('#edit').find('#nama_paket').val(data.nama_paket_kelas);
                  $('#edit').find('#id_detail_kelas').val(data.id_detail_kelas);
                  $('#edit').find('#pertemuan').val(data.banyak_pertemuan);
                  $('#edit').find('#masa_aktif').val(data.masa_aktif);
                  $('#edit').find('#satuan_masa_aktif').val(data.satuan_masa_aktif);
                  $('#edit').find('#biaya').val(data.biaya);
                  $('#edit').find('#status').val(data.status).change();
              },
              error : function(){
              }
            });
          }
      

function detail(id_detail_kelas)
  {
    window.location.href="<?php echo base_url() ?>user/admin/detail_kelas/detail/" + id_detail_kelas;
  }
      

</script>









