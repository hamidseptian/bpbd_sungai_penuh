 <div class="row">
    <div class="col-md-3">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php 

                if ($instruktur['foto']=='') { 
                $src_foto = base_url('assets/gambar/user.webp');  
                }else{ 
                $src_foto = base_url('file/instruktur/'.$instruktur['foto']); 
                } 


                 ?>
                  <img class=" img-responsive " src="<?php echo $src_foto  ?>" alt="User profile picture" width="100%">
        </div>
      </div>
    </div>


    <div class="col-md-3">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Identitas Instruktur</h3>
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <table class="table table-striped table-bordered">
            <tr>
              <td>Nama</td>
              <td>:</td>
              <td><?php echo $instruktur['nama'] ?></td>
            </tr>
            <tr>
              <td>Jenis Kelamin</td>
              <td>:</td>
              <td><?php echo $instruktur['jk'] ?></td>
            </tr>
            <tr>
              <td>Tempat / Tgl Lahir</td>
              <td>:</td>
              <td><?php echo $instruktur['tmpl'].' / '.$instruktur['tgll'] ?></td>
            </tr>
            <tr>
              <td>Alamat</td>
              <td>:</td>
              <td><?php echo $instruktur['alamat'] ?></td>
            </tr>
            <tr>
              <td>No HP</td>
              <td>:</td>
              <td><?php echo $instruktur['no_hp'] ?></td>
            </tr>
            <tr>
              <td>Email</td>
              <td>:</td>
              <td><?php echo $instruktur['email'] ?></td>
            </tr>
            <tr>
              <td>Status</td>
              <td>:</td>
              <td><?php echo $status[$instruktur['status']] ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="box">
       
        <div class="box-header">
          <h3 class="box-title">Kelas Instruktur</h3>
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Kelas</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            foreach ($instruktur_kelas as $d1) { 

              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['kelas'].'<br>'.$d1['nama_paket_kelas'] ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>
               
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit" onclick="edit_instruktur_kelas('<?php echo $d1['id_instruktur_kelas'] ?>')">
                Edit
              </button>
                 <button type="button" class="btn btn-info btn-xs" onclick="hapus_kelas_instruktur('<?php echo $d1['id_instruktur_kelas'] ?>','<?php echo enkripsi($d1['id_instruktur']) ?>','<?php echo $d1['kelas'].' - '.$d1['nama_paket_kelas'] ?><br>')">
                Hapus
              </button>
                 
                </td>
              </tr>

            <?php } ?>
            
          </table>
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/instruktur/simpan_kelas_instruktur') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Kelas Instruktur</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  
                  <input type="hidden" name="id_instruktur" id="id_instruktur" class="form-control" value="<?php echo $instruktur['id_instruktur'] ?>">
                  <label>Kelas</label>
                    <select class="form-control" name="id_kelas" id="id_kelas">
                      <option value="">--Pilih Kelas--</option>
                      <?php foreach ($kelas as $k => $v) {  ?>
                      <option value="<?php echo $v['id_kelas'] ?>"><?php echo $v['kelas'] ?></option>
                      <?php } ?>
                    </select>
                </div>
            
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
  </div>


  <div class="modal fade" id="edit">
    <form action="<?php echo base_url('user/admin/instruktur/simpanedit_kelas_instruktur') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Kelas Instruktur</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Kelas</label>
                  <input type="hidden" name="id_instruktur" id="id_instruktur" class="form-control" value="<?php echo $instruktur['id_instruktur'] ?>">
                  <input type="hidden" name="id_instruktur_kelas" id="id_instruktur_kelas" class="form-control">
                    <select class="form-control" name="id_detail_kelas" id="id_detail_kelas">
                     
                    </select>
                </div>
                
               <div class="form-group">
                <label>Status</label>
                <select class="form-control" name="status" id="status">
                  <option value="1">Aktif</option>
                  <option value="0">Tidak Aktif</option>
                </select>
              </div>
                     
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
  </div>





<script>
  

function hapus_kelas_instruktur(id_kelas_instruktur, id_instruktur, kelas)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Hapus kelas '+ kelas+' pada instruktur <?php echo $instruktur['nama'] ?> ?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/instruktur/hapus_kelas_instruktur'),
              type    : 'POST',
              data    : { 
                id_kelas_instruktur : id_kelas_instruktur,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/instruktur/detail/' + id_instruktur);
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



function edit_instruktur_kelas(id_kelas_instruktur)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/instruktur/edit_instruktur_kelas'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_kelas_instruktur : id_kelas_instruktur,
                
              },
              success : function(data)
              {

                  $('#edit').find('#id_detail_kelas').html('');
              	$.each(data.list_kelas, function(k,v){
              		var value = v.id_detail_kelas+'|'+v.id_kelas ; 
              		var value_selected = data.data.id_detail_kelas+'|'+data.data.id_kelas ; 
              	var selected = value == value_selected ? 'selected' : '' ; 
                  $('#edit').find('#id_detail_kelas').append('<option value="'+ value+'" '+selected	+'>' + v.kelas + ' [Paket '+v.nama_paket_kelas	+']</option>');

              	});
                  // $('#edit').find('#id_detail_kelas').val(data.data.id_detail_kelas+'|'+data.data.id_kelas).change();
                  $('#edit').find('#id_instruktur_kelas').val(data.data.id_instruktur_kelas);
                  $('#edit').find('#awal').val(data.data.tgl_awal);
                  $('#edit').find('#akhir').val(data.data.tgl_akhir );
                
              },
              error : function(){
              }
            });
          }
      

</script>









