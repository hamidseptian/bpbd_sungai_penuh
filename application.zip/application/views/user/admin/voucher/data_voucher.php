 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Peruntukan Voucher</td>
                <td>Nama voucher</td>
                <td>Keterangan</td>
                <td>Jenis voucher</td>
                <td>Besar voucher</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Potongan Harga', 'Persentase'];
            $peruntukan = ['Membership', 'Kelas'];
            foreach ($voucher as $d1) { ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td> 
                  <?php 
                  echo $d1['peruntukan'].'<br>';
                  if ($d1['peruntukan']=='Membership') {
                    echo $d1['id_jenis_member'] == 'semua' ? 'Semua Jenis Member' : $d1['jenis_member'];
                  }else{
                    $paket_kelas = $d1['id_detail_kelas'] == 'semua' ? 'Semua paket pada kelas '.$d1['kelas'] : "Kelas : ".$d1['kelas'].'<br>Paket : '.$d1['nama_paket_kelas'] ;
                    echo $d1['id_kelas'] == 'semua' ? 'Semua Kelas' : $paket_kelas;

                  } 
                  ?>
                 </td>
                <td><?php echo $d1['nama_voucher'] ?></td>
                <td><?php echo $d1['keterangan'] ?></td>
                <td><?php echo $d1['jenis'] ?></td>
                <td><?php echo ($d1['jenis'] == 'Persentase' ? number_format($d1['besar_voucher']).' %' : 'Rp. '.number_format($d1['besar_voucher']) )  ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit" onclick="edit('<?php echo $d1['id_voucher'] ?>')">
                Edit
              </button>
                 <button type="button" class="btn btn-info btn-xs" onclick="hapus('<?php echo $d1['id_voucher'] ?>','<?php echo $d1['nama_voucher'] ?>')">
                Nonaktifkan
              </button>
                 
                </td>
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/voucher/simpan') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah voucher</h4>
              </div>
              <div class="modal-body">
                  <div class="form-group">
                  <label>Nama voucher</label>
                  <input type="text" class="form-control" name="nama_voucher" required id="nama_voucher">
                </div>
                <div class="form-group">
                  <label>Jenis voucher</label>
                  

                  <select class="form-control jenis_voucher" name="jenis" id="jenis">
                        <?php foreach ($jenis as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>



                </div>
              
               
                 <div class="form-group">
                  <label>Besar voucher <span class="caption_jenis_voucher">(Rp.) </span></label>
                  <input type="text" class="form-control" name="voucher" required id="voucher"  onkeypress="return isNumber(event)">
                  <span class="caption_voucher">Masukan Jumlah Potongan voucher dalam Rupiah</span>
                </div>
                 <div class="form-group">
                  <label>Keterangan voucher</label>
                  <textarea rows="5" class="form-control" name="keterangan" id="keterangan"></textarea>
                </div>

                <hr>

                <div class="form-group">
                  <label>Peruntukan voucher</label>
                  

                  <select class="form-control peruntukan" name="peruntukan" id="peruntukan">
                          <option value="">Pilih Peruntukan</option>
                        <?php foreach ($peruntukan as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>
                </div>
                <div id="f_member" hidden="true">
                  <div class="form-group">
                    <label>Pilih Membership</label>
                    <select class="form-control" name="id_jenis_member" id="id_jenis_member">
                    </select>
                  </div>
                </div>
                <div id="f_kelas" hidden="true">
                  <div class="form-group">
                    <label>Pilih Kelas</label>
                    <select class="form-control" name="kelas" id="kelas">
                    </select>
                  </div>
                  <div class="form-group" id="f_detail_kelas" hidden="true">
                    <label>Pilih Paket Kelas</label>
                    <select class="form-control" name="paket_kelas" id="paket_kelas">
                    </select>
                  </div>
                </div>
             
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="simpan_voucher">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>


  <div class="modal fade" id="edit">
    <form action="<?php echo base_url('user/admin/voucher/simpanedit') ?>" method='post' id='xxxx'> 
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit voucher</h4>
              </div>
                <input type="hidden" class="form-control" name="id_voucher" required id="id_voucher">
               <div class="modal-body">
                <div class="form-group">
                  <label>Nama voucher</label>
                  <input type="text" class="form-control" name="nama_voucher" required id="nama_voucher">
                </div>
                <div class="form-group">
                  <label>Jenis voucher</label>
                  <select class="form-control jenis_voucher" name="jenis" id="jenis">
                        <?php foreach ($jenis as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>
                </div>
                 <div class="form-group">
                  <label>Besar voucher</label>
                  <input type="text" class="form-control" name="voucher" required id="voucher" onkeypress="return isNumber(event)">
                  <span class="caption_voucher"></span>
                </div>
                 <div class="form-group">
                  <label>Keterangan voucher</label>
                  <textarea rows="5" class="form-control" name="keterangan" id="keterangan"></textarea>
                </div>
                 <hr>

                <div class="form-group">
                  <label>Peruntukan voucher</label>
                  

                  <select class="form-control peruntukan" name="peruntukan" id="peruntukan">
                        <?php foreach ($peruntukan as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>
                </div>
                <div id="f_member" hidden="true">
                  <div class="form-group">
                    <label>Pilih Membership</label>
                    <select class="form-control" name="id_jenis_member" id="id_jenis_member">
                    </select>
                  </div>
                </div>
                <div id="f_kelas" hidden="true">
                  <div class="form-group">
                    <label>Pilih Kelas</label>
                    <select class="form-control" name="kelas" id="kelas">
                    </select>
                  </div>
                  <div class="form-group" id="f_detail_kelas" hidden="true">
                    <label>Pilih Paket Kelas</label>
                    <select class="form-control" name="paket_kelas" id="paket_kelas">
                    </select>
                  </div>
                </div>
                 <div class="form-group">
                  <label>Status</label>
                  <select class="form-control" name="status" id="status">
                    <option value="1">Aktif</option>
                    <option value="0">Tidak Aktif</option>
                  </select>
                </div>


              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
            
          </div>
    </form>
        </div>




<script>
$('#simpan_voucher').click(function(){
  var peruntukan = $('.peruntukan').val();
  if (peruntukan=='') {
    Swal.fire('Error','Anda belum memilih peruntukan','error');
    return false;
  }else{
    return true;

  }
});



 $('.jenis_voucher').change(function(){
   var jenis_voucher_2 = $('.jenis_voucher').val();
 if (jenis_voucher_2=='Persentase') {
  $('.caption_jenis_voucher').html('(%)')
  $('.caption_voucher').html('Masukan Jumlah Potongan voucher dalam persentasi (angkanya saja)')
 }else{
  $('.caption_jenis_voucher').html('(Rp.)')
  $('.caption_voucher').html('Masukan Jumlah Potongan voucher potongan harga Rupiah')
 }

 });





 $('#tambah').find('.peruntukan').change(function(){
   var peruntukan = $('.peruntukan').val();
 if (peruntukan=='Membership') {
   pilihan_member();
  $('#tambah').find('#f_member').show();
  $('#tambah').find('#f_kelas').hide();

 }
 else if (peruntukan=='Kelas') {
  $('#tambah').find('#f_member').hide();
  $('#tambah').find('#f_kelas').show();
   pilihan_kelas();
 }else{
  $('#tambah').find('#f_member').hide();
  $('#tambah').find('#f_kelas').hide();
 }

 });



 $('#edit').find('.peruntukan').change(function(){
   var peruntukan = $('#edit').find('.peruntukan').val();
 if (peruntukan=='Membership') {
   pilihan_member();
  $('#edit').find('#f_member').show();
  $('#edit').find('#f_kelas').hide();

 }
 else if (peruntukan=='Kelas') {
  $('#edit').find('#f_member').hide();
  $('#edit').find('#f_kelas').show();
   pilihan_kelas();
 }else{
  $('#edit').find('#f_member').hide();
  $('#edit').find('#f_kelas').hide();
 }

 });




function hapus(id_voucher, metode_pembayaran)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan voucher '+metode_pembayaran+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/voucher/hapus'),
              type    : 'POST',
              data    : { 
                id_voucher : id_voucher,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/voucher');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_voucher)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/voucher/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_voucher : id_voucher,
                
              },
              success : function(data)
              {
                console.log(data);
                  $('#edit').find('#id_voucher').val(data.id_voucher);
                  $('#edit').find('#jenis').val(data.jenis).change();
                  if (data.jenis=='Persentase') {
                    $('.caption_jenis_voucher').html('(%)')
                    $('.caption_voucher').html('Masukan Jumlah Potongan voucher dalam persentasi (angkanya saja)')
                   }else{
                    $('.caption_jenis_voucher').html('(Rp.)')
                    $('.caption_voucher').html('Masukan Jumlah Potongan voucher potongan harga Rupiah')
                   }

                  $('#edit').find('#nama_voucher').val(data.nama_voucher);
                  $('#edit').find('#voucher').val(data.besar_voucher);

                  $('#edit').find('#keterangan').val(data.keterangan);
                  $('#edit').find('#status').val(data.status).change();

                  $('#edit').find('#peruntukan').val(data.peruntukan).change();
                  $('#edit').find('#id_jenis_member').val(data.id_jenis_member).change();
                  $('#edit').find('#kelas').val(data.id_kelas).change();
                  $('#edit').find('#paket_kelas').val(data.id_detail_kelas).change();


                  if (data.peruntukan=='Membership') {
                    $('#edit').find('#f_member').show();
                    $('#edit').find('#f_kelas').hide();
                     pilihan_member(data.id_jenis_member);

                  }else{
                     pilihan_kelas(data.id_kelas);
                    $('#edit').find('#f_member').hide();
                    $('#edit').find('#f_kelas').show();
                    if (data.id_kelas=='semua') {
                      $('#edit').find('#f_detail_kelas').hide();
                    }else{
                       paket_kelas(data.id_kelas, data.id_detail_kelas);
                      $('#edit').find('#f_detail_kelas').show();

                    }
                  }







              
              },
              error : function(){
              }
            });
          }
 


function pilihan_member(id_jenis_member='')
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/voucher/pilihan_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                
              },
              success : function(data)
              {
                  $('#tambah').find('#id_jenis_member').html('<option value="semua">Semua Jenis member</option>');
                  $('#edit').find('#id_jenis_member').html('<option value="semua">Semua Jenis member</option>');
                  $.each(data.data, function(k,v){
                    var selected = id_jenis_member == v.id_jenis_member ? 'selected' : '';
                  $('#tambah').find('#id_jenis_member').append('<option value="'+v.id_jenis_member+'">'+v.jenis_member+'</option>');
                  $('#edit').find('#id_jenis_member').append('<option value="'+v.id_jenis_member+'" '+selected+'>'+v.jenis_member+'</option>');

                  });
                 
              
              },
              error : function(){
              }
            });
          }
      

function pilihan_kelas(id_kelas='')
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/voucher/pilihan_kelas'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                
              },
              success : function(data)
              {
                var id_kelas_pertama = "";
                  $('#tambah').find('#kelas').html('<option value="semua">Semua Kelas</option>');
                  $('#edit').find('#kelas').html('<option value="semua">Semua Kelas</option>');
                  $.each(data.data, function(k,v){
                   
                    var selected = id_kelas == v.id_kelas ? 'selected' : '';
                  $('#tambah').find('#kelas').append('<option value="'+v.id_kelas+'">'+v.kelas+'</option>');
                  $('#edit').find('#kelas').append('<option value="'+v.id_kelas+'" '+selected+'>'+v.kelas+'</option>');

                  });

                  // paket_kelas(id_kelas_pertama);
                
              
              },
              error : function(){
              }
            });
          }
      



  $('#tambah').find('#kelas').change(function(){
    var id_kelas = $('#tambah').find('#kelas').val();
      if (id_kelas=='semua') {
        $('#tambah').find('#f_detail_kelas').hide();
      }else{
        $('#tambah').find('#f_detail_kelas').show();
        paket_kelas(id_kelas);
      }
    });


  $('#edit').find('#kelas').change(function(){
    var id_kelas = $('#edit').find('#kelas').val();
      if (id_kelas=='semua') {
        $('#edit').find('#f_detail_kelas').hide();
      }else{
        $('#edit').find('#f_detail_kelas').show();
        paket_kelas(id_kelas);
      }
    });

function paket_kelas(id_kelas, id_detail_kelas='')
  {
    
                  $('#tambah').find('#paket_kelas').html('');
            $.ajax(
            {
              url     : baseUrl('/user/admin/voucher/paket_kelas'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_kelas : id_kelas
              },
              success : function(data)
              {

                  $('#tambah').find('#paket_kelas').html('<option value="semua">Semua Paket Pada  Kelas '+data.kelas+'</option>');
                  $('#edit').find('#paket_kelas').html('<option value="semua">Semua Paket Pada  Kelas '+data.kelas+'</option>');
                  $.each(data.data, function(k,v){
                   
                    var selected = id_detail_kelas == v.id_detail_kelas ? 'selected' : '';
                  $('#tambah').find('#paket_kelas').append('<option value="'+v.id_detail_kelas+'">'+v.nama_paket_kelas+'</option>');
                  $('#edit').find('#paket_kelas').append('<option value="'+v.id_detail_kelas+'" '+selected+'>'+v.nama_paket_kelas+'</option>');

                  });

                
              
              },
              error : function(){
              }
            });
          }
      

</script>









