 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Jenis Produk</td>
                <td>Produk</td>
                <td>Harga Modal</td>
                <td>Harga Jual</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Apparel', 'Perlengkapan Gym'];
            foreach ($sourvenir as $d1) { ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis'] ?></td>
                <td><?php echo $d1['produk'] ?></td>
                <td><?php echo number_format($d1['modal']) ?></td>
                <td><?php echo number_format($d1['harga']) ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit_sourvenir" onclick="edit('<?php echo $d1['id_sourvenir'] ?>')">
                Edit
              </button>
                 <button type="button" class="btn btn-info btn-xs" onclick="hapus('<?php echo $d1['id_sourvenir'] ?>','<?php echo $d1['produk'] ?>')">
                Nonaktifkan
              </button>
                 
                </td>
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/sourvenir/simpan') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Sourvenir</h4>
              </div>
              <div class="modal-body">
               
                <div class="form-group">
                  <label>Jenis Sourvenir</label>
                  

                  <select class="form-control" name="jenis" id="jenis">
                        <?php foreach ($jenis as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>



                </div>
                 <div class="form-group">
                  <label>Produk</label>
                  <input type="text" class="form-control" name="sourvenir" required>
                </div>
                <div class="form-group">
                  <label>Harga Modal</label>
                  <input type="text" class="form-control" name="modal" required>
                </div>
                <div class="form-group">
                  <label>Harga Jual</label>
                  <input type="text" class="form-control" name="harga" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>


  <div class="modal fade" id="edit_sourvenir">
    <form action="<?php echo base_url('user/admin/sourvenir/simpanedit') ?>" method='post' id='xxxx'> 
      
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Sourvenir</h4>
              </div>
                <input type="hidden" class="form-control" name="id_sourvenir" required id="id_sourvenir">
               <div class="modal-body">
               
                <div class="form-group">
                  <label>Jenis Sourvenir</label>
                  

                  <select class="form-control" name="jenis" id="jenis">
                        <?php foreach ($jenis as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>



                </div>
                 <div class="form-group">
                  <label>Produk</label>
                  <input type="text" class="form-control" name="sourvenir" required id="sourvenir">
                </div>
                <div class="form-group">
                  <label>Harga Modal</label>
                  <input type="text" class="form-control" name="modal" required id="modal">
                </div>
                <div class="form-group">
                  <label>Harga Jual</label>
                  <input type="text" class="form-control" name="harga" required id="harga">
                </div>

                 <div class="form-group">
                  <label>Status</label>
                  <select class="form-control" name="status" id="status">
                    <option value="1">Aktif</option>
                    <option value="0">Tidak Aktif</option>
                  </select>
                </div>


              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
            
          </div>
    </form>
        </div>




<script>
  

function hapus(id_sourvenir, sourvenir)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan sourvenir '+sourvenir+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/sourvenir/hapus'),
              type    : 'POST',
              data    : { 
                id_sourvenir : id_sourvenir,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/sourvenir');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_sourvenir)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/sourvenir/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_sourvenir : id_sourvenir,
                
              },
              success : function(data)
              {
                  $('#edit_sourvenir').find('#id_sourvenir').val(data.id_sourvenir);
                  $('#edit_sourvenir').find('#sourvenir').val(data.produk);
                  $('#edit_sourvenir').find('#jenis').val(data.jenis).change();
                  $('#edit_sourvenir').find('#harga').val(data.harga);
                  $('#edit_sourvenir').find('#modal').val(data.modal);
                  $('#edit_sourvenir').find('#status').val(data.status).change();
              },
              error : function(){
              }
            });
          }
      

</script>









