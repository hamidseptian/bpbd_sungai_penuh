 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Jenis barang</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            foreach ($jenis_barang as $d1) { ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis_barang'] ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit_metode" onclick="edit('<?php echo $d1['id_jenis_barang'] ?>')">
                Edit
              </button>
                 <button type="button" class="btn btn-info btn-xs" onclick="hapus('<?php echo $d1['id_jenis_barang'] ?>','<?php echo $d1['jenis_barang'] ?>')">
                Nonaktifkan
              </button>
                 
                </td>
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/jenis_barang/simpan') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Jenis barang</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Jenis barang</label>
                  <input type="text" class="form-control" name="jenis_barang" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>


  <div class="modal fade" id="edit_metode">
    <form action="<?php echo base_url('user/admin/jenis_barang/simpanedit') ?>" method='post' id='xxxx'> 
      
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Jenis barang</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Jenis barang</label>
                  <input type="hidden" class="form-control" name="id_jenis_barang" required id="id_metode">
                  <input type="text" class="form-control" name="jenis_barang" required id="metode">
                </div>
                <div class="form-group">
                  <label>Status</label>
                  <select class="form-control" name="status" id="status">
                    <option value="1">Aktif</option>
                    <option value="0">Tidak Aktif</option>
                  </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
            
          </div>
    </form>
        </div>




<script>
  

function hapus(id_jenis_barang, jenis_barang)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan Jenis barang '+jenis_barang+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/jenis_barang/hapus'),
              type    : 'POST',
              data    : { 
                id_jenis_barang : id_jenis_barang,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/jenis_barang');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



function edit(id_jenis_barang)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/jenis_barang/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_jenis_barang : id_jenis_barang,
                
              },
              success : function(data)
              {
                  $('#edit_metode').find('#id_metode').val(data.id_jenis_barang);
                  $('#edit_metode').find('#metode').val(data.jenis_barang);
                  $('#edit_metode').find('#status').val(data.status).change();
              },
              error : function(){
              }
            });
          }
      

</script>









