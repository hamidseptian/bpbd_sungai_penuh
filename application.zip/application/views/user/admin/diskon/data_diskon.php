 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Nama Diskon</td>
                <td>Keterangan</td>
                <td>Jenis Diskon</td>
                <td>Besar Diskon</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Potongan Harga', 'Persentase'];
            foreach ($diskon as $d1) { ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['nama_diskon'] ?></td>
                <td><?php echo $d1['keterangan'] ?></td>
                <td><?php echo $d1['jenis'] ?></td>
                <td><?php echo ($d1['jenis'] == 'Persentase' ? number_format($d1['besar_diskon']).' %' : 'Rp. '.number_format($d1['besar_diskon']) )  ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>
                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit_metode" onclick="edit('<?php echo $d1['id_diskon'] ?>')">
                Edit
              </button>
                 <button type="button" class="btn btn-info btn-xs" onclick="hapus('<?php echo $d1['id_diskon'] ?>','<?php echo $d1['nama_diskon'] ?>')">
                Nonaktifkan
              </button>
                 
                </td>
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/diskon/simpan') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Diskon</h4>
              </div>
              <div class="modal-body">
                  <div class="form-group">
                  <label>Nama Diskon</label>
                  <input type="text" class="form-control" name="nama_diskon" required id="nama_diskon">
                </div>
                <div class="form-group">
                  <label>Jenis Diskon</label>
                  

                  <select class="form-control jenis_diskon" name="jenis" id="jenis">
                        <?php foreach ($jenis as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>



                </div>
              
               
                 <div class="form-group">
                  <label>Besar Diskon <span class="caption_jenis_diskon">(Rp.) </span></label>
                  <input type="text" class="form-control" name="diskon" required id="diskon">
                  <span class="caption_diskon">Masukan Jumlah Potongan diskon dalam Rupiah</span>
                </div>
                 <div class="form-group">
                  <label>Keterangan Diskon</label>
                  <textarea rows="5" class="form-control" name="keterangan" id="keterangan"></textarea>
                </div>
             
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>


  <div class="modal fade" id="edit_metode">
    <form action="<?php echo base_url('user/admin/diskon/simpanedit') ?>" method='post' id='xxxx'> 
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Diskon</h4>
              </div>
                <input type="hidden" class="form-control" name="id_diskon" required id="id_diskon">
               <div class="modal-body">
                <div class="form-group">
                  <label>Nama Diskon</label>
                  <input type="text" class="form-control" name="nama_diskon" required id="nama_diskon">
                </div>
                <div class="form-group">
                  <label>Jenis Diskon</label>
                  <select class="form-control jenis_diskon" name="jenis" id="jenis">
                        <?php foreach ($jenis as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>
                </div>
                 <div class="form-group">
                  <label>Besar Diskon</label>
                  <input type="text" class="form-control" name="diskon" required id="diskon">
                  <span class="caption_diskon"></span>
                </div>
                 <div class="form-group">
                  <label>Keterangan Diskon</label>
                  <textarea rows="5" class="form-control" name="keterangan" id="keterangan"></textarea>
                </div>
             
                 <div class="form-group">
                  <label>Status</label>
                  <select class="form-control" name="status" id="status">
                    <option value="1">Aktif</option>
                    <option value="0">Tidak Aktif</option>
                  </select>
                </div>


              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
            
          </div>
    </form>
        </div>




<script>

 $('.jenis_diskon').change(function(){
   var jenis_diskon_2 = $('.jenis_diskon').val();
 if (jenis_diskon_2=='Persentase') {
  $('.caption_jenis_diskon').html('(%)')
  $('.caption_diskon').html('Masukan Jumlah Potongan diskon dalam persentasi (angkanya saja)')
 }else{
  $('.caption_jenis_diskon').html('(Rp.)')
  $('.caption_diskon').html('Masukan Jumlah Potongan diskon potongan harga Rupiah')
 }

 });

function hapus(id_diskon, metode_pembayaran)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan diskon '+metode_pembayaran+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/diskon/hapus'),
              type    : 'POST',
              data    : { 
                id_diskon : id_diskon,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/diskon');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_diskon)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/diskon/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_diskon : id_diskon,
                
              },
              success : function(data)
              {
                  $('#edit_metode').find('#id_diskon').val(data.id_diskon);
                  $('#edit_metode').find('#jenis').val(data.jenis).change();
                  if (data.jenis=='Persentase') {
                    $('.caption_jenis_diskon').html('(%)')
                    $('.caption_diskon').html('Masukan Jumlah Potongan diskon dalam persentasi (angkanya saja)')
                   }else{
                    $('.caption_jenis_diskon').html('(Rp.)')
                    $('.caption_diskon').html('Masukan Jumlah Potongan diskon potongan harga Rupiah')
                   }

                  $('#edit_metode').find('#nama_diskon').val(data.nama_diskon);
                  $('#edit_metode').find('#diskon').val(data.besar_diskon);

                  $('#edit_metode').find('#keterangan').val(data.keterangan);
                  $('#edit_metode').find('#status').val(data.status).change();
              
              },
              error : function(){
              }
            });
          }
      

</script>









