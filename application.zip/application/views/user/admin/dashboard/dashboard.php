<div class="row">
  
  <div class="col-md-12">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-aqua">
              <div class="widget-user-image">
                <?php 
                $foto = $user['foto'] == '' ? base_url().'/file/user/user.webp' : base_url().'/file/user/'.$user['foto'];
   ?>
                <img class="img" src="<?php echo $foto ?>" alt="User Avatar">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?php echo $user['nama'] ?></h3>
              <h5 class="widget-user-desc"><?php echo $user['nama_hak_akses'] ?></h5>
            </div>
         
          </div>
          <!-- /.widget-user -->
        </div>


</div>






<div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['jenis_member'] ?></h3>

              <p>Jenis Member Aktif</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="<?php echo base_url('user/admin/member') ?>" class="small-box-footer">
             Kelola Jenis Member
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['fnb'] ?></h3>

              <p>FnB Aktif</p>
            </div>
            <div class="icon">
              <i class="fa fa-cutlery"></i>
            </div>
               <a href="<?php echo base_url('user/admin/fnb') ?>" class="small-box-footer">
              Kelola Fnb
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['sourvenir'] ?></h3>

              <p>Sourvenir Aktif</p>
            </div>
            <div class="icon">
              <i class="fa fa-gift"></i>
            </div>
               <a href="<?php echo base_url('user/admin/sourvenir') ?>" class="small-box-footer">
              Kelola Sourvenir
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['diskon'] ?></h3>

              <p>Diskon Aktif</p>
            </div>
            <div class="icon">
              <i class=" fa fa-money"></i>
            </div>
               <a href="<?php echo base_url('user/admin/diskon') ?>" class="small-box-footer">
              Kelola Diskon
            </a>
          </div>
        </div>
       
      </div>