 <div class="row">
    <div class="col-md-12">
      <div class="box">
        
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Jenis Member</td>
                <td>Masa Aktif</td>
                <td>Biaya</td>
                <td>Wajib Registrasi</td>
                <td>Status</td>
              
                <td width="90px">Option</td>
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $y_n = ['Tidak', 'Ya'];
            $satuan_masa_aktif = ['Hari', 'Bulan'];
            foreach ($jenis_member as $d1) { ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis_member'] ?></td>
                <td><?php echo $d1['masa_aktif'].' '.$d1['satuan_masa_aktif'] ?></td>
                <td><?php echo number_format($d1['biaya']) ?></td>
                <td><?php echo @$y_n[$d1['wajib_register']] ?></td>
                <td><?php echo $status[$d1['status']] ?></td>
                <td>

                 <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#edit_metode" onclick="edit('<?php echo $d1['id_jenis_member'] ?>')">
                Edit
              </button>
                	<?php if ($d1['id_jenis_member']!=1): ?>
                 <button type="button" class="btn btn-info btn-xs" onclick="hapus('<?php echo $d1['id_jenis_member'] ?>','<?php echo $d1['jenis_member'] ?>')">
                Nonaktifkan
              </button>
                 
                	<?php endif ?>
                </td>
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/admin/member/simpan') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Jenis Member</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Jenis Member</label>
                  <input type="text" class="form-control" name="jenis_member" required>
                </div>
                <div class="form-group">
                  <label>Masa Aktif</label>
                  

                  <div class="row">
                    <div class="col-xs-3">
                      <input type="text" class="form-control" name="masa_aktif">
                    </div>
                    <div class="col-xs-9">
                      <select class="form-control" name="satuan_masa_aktif">
                        <?php foreach ($satuan_masa_aktif as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  
                  </div>



                </div>
                <div class="form-group">
                  <label>Biaya</label>
                  <input type="text" class="form-control" name="biaya" required onkeypress="return isNumber(event)">
                </div>
                <div class="form-group">
                  <input type="checkbox" name="wajib_register" class="wajib_register"> <label>Wajib Registrasi</label>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>


  <div class="modal fade" id="edit_metode">
    <form action="<?php echo base_url('user/admin/member/simpanedit') ?>" method='post' id='xxxx'> 
      
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Jenis Member</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Jenis Member</label>
                  <input type="hidden" class="form-control" name="id_jenis_member" required id="id_jenis_member">
                  <input type="text" class="form-control" name="jenis_member" required id="jenis_member">
                </div>
                <div class="form-group">
                  <label>Masa Aktif</label>
                  

                  <div class="row">
                    <div class="col-xs-3">
                      <input type="text" class="form-control" name="masa_aktif" id="masa_aktif">
                    </div>
                    <div class="col-xs-9">
                      <select class="form-control" name="satuan_masa_aktif" id="satuan_masa_aktif">
                        <?php foreach ($satuan_masa_aktif as $v) { ?>
                          <option value="<?php echo $v ?>"><?php echo $v ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  
                  </div>

                </div>
                <div class="form-group">
                  <label>Biaya</label>
                  <input type="text" class="form-control currency" name="biaya" required id="biaya" onkeypress="return isNumber(event)">
                </div>

    <div class="form-group" id="form_wajib_register">
                  <input type="checkbox" name="wajib_register" id="wajib_register_edit"> <label>Wajib Registrasi</label>
                </div>
                  <div class="form-group">
                  <label>Status</label>
                  <select class="form-control" name="status" id="status">
                    <option value="1">Aktif</option>
                    <option value="0">Tidak Aktif</option>
                  </select>
                </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
            
          </div>
    </form>
        </div>




<script>
  

function hapus(id_jenis_member, jenis_member)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Nonaktifkan jenis member '+jenis_member+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Nonaktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/member/hapus'),
              type    : 'POST',
              data    : { 
                id_jenis_member : id_jenis_member,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/member');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_jenis_member)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/member/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_jenis_member : id_jenis_member,
                
              },
              success : function(data)
              {
                  $('#edit_metode').find('#id_jenis_member').val(data.id_jenis_member);
                  $('#edit_metode').find('#jenis_member').val(data.jenis_member);
                  $('#edit_metode').find('#masa_aktif').val(data.masa_aktif);
                  $('#edit_metode').find('#satuan_masa_aktif').val(data.satuan_masa_aktif);
                  $('#edit_metode').find('#biaya').val(data.biaya);
                  $('#edit_metode').find('#status').val(data.status).change();


                  if (data.wajib_register==1) {
                      $("#wajib_register_edit").prop('checked', true);
                  }else{
                      $("#wajib_register_edit").prop('checked', false);


                  }


                  if (data.id_jenis_member==1) {
	                  $('#edit_metode').find('#id_jenis_member').attr('readonly','readonly');
	                  $('#edit_metode').find('#jenis_member').attr('readonly','readonly');
	                  $('#edit_metode').find('#masa_aktif').attr('readonly','readonly');
	                  $('#edit_metode').find('#satuan_masa_aktif').attr('disabled','disabled');
	                  $('#edit_metode').find('#status').attr('disabled','disabled');
	                  $('#edit_metode').find('#form_wajib_register').attr('hidden','true');

                  }else{
                  		$('#edit_metode').find('#id_jenis_member').removeAttr('readonly');
	                  $('#edit_metode').find('#jenis_member').removeAttr('readonly');
	                  $('#edit_metode').find('#masa_aktif').removeAttr('readonly');
	                  $('#edit_metode').find('#satuan_masa_aktif').removeAttr('readonly');
	                  $('#edit_metode').find('#status').removeAttr('disabled');
	                  $('#edit_metode').find('#form_wajib_register').removeAttr('hidden');
                  }

              },
              error : function(){
              }
            });
          }
      

</script>









