 <?php 
              $no=1;
                foreach($pengeluaran as $v){ 
                $src_foto = base_url('file/kartu/'.$v['file']);  
                  ?>

                     <style>
  .example_<?php echo $v['id_kartu_member'] ?> {
  border: 2px solid black;
  background: url(<?php echo $src_foto ?>);
  background-repeat: no-repeat;
    background-size: 100% 100%;
    width : 100%;
    height : auto;
    /*opacity: 0.5;*/
}
</style>

<?php   } ?>


<div class="row">

   
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">
            <?php echo $caption ?>
          </h3>
           <div class="pull-right">
             <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>
           </div>
        </div>
    
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Tanggal</th>
                <th>Pengusul</th>
                <th>Besar Pengeluaran</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Option</th>
             
              
              </tr>
            </thead>
            <tbody> 
              <?php 
              $no=1;
                foreach($pengeluaran as $v){ 
                $src_foto = base_url('file/kartu/'.$v['file']);  
                  ?>
              <tr>  
                <td><?php echo $no++ ?></td>
               
                <td><?php echo $v['tgl_transaksi'] ?></td>
                <td><?php echo $v['nama'] ?></td>
                <td align="right"><?php echo number_format($v['besar_pengeluaran']) ?></td>
                <td><?php echo $v['keterangan'] ?></td>
                <?php if ($v['status']!=1) { ?>
                  <td><?php echo $status[$v['status']] ?></td>
                <?php }else{ ?>
                  <td><?php echo $status[$v['status']].' - '.$approval[$v['approval']].'<br>'.$v['keterangan_approval'] ?></td>

                <?php } ?>
                <td>
                    <a href="javascript:void(0)" class="btn btn-info btn-xs"  onclick="detail('<?php echo $v['id_pengeluaran'] ?>','<?php echo $v['file'] ?>')">Detail</a>
                  <?php if ($v['status']==0) { ?>
                    <a href="javascript:void(0)" class="btn btn-info btn-xs"  onclick="batal('<?php echo $v['id_pengeluaran'] ?>','<?php echo $v['file'] ?>')">Batal</a>
                  <?php }else{ ?>
                </td>
              <?php   } ?>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="tambah_pengeluaran">
          <div class="modal-dialog">
            <div class="modal-content">
            <form action="<?php echo base_url('/user/kassa/pengeluaran/simpan_pengeluaran') ?>" enctype="multipart/form-data" method="post">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Tambah Pengeluaran</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Tanggal Transaksi</label>
                    <input type="date" name="tgl" class="form-control" value="<?php echo date('Y-m-d') ?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Besar Pengeluaran (Rp.)</label>
                      <input type="text" name="rp" required class="form-control" id="rp"  onkeypress="return isNumber(event)">
                  </div>
                  <div class="form-group">
                    <label>Keterangan</label>
                    <textarea name="keterangan" class="form-control" rows="4"></textarea>
                  </div>
                  <div class="form-group">
                    <label>Bukti Pembayaran</label>
                    <input type="file" name="berkas" class="form-control" required>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-info pull-right">Simpan Pengeluaran</button>
                </div>
            </form>
              </div>
          </div>
        </div>



  <div class="modal fade" id="detail_pengeluaran">
          <div class="modal-dialog">
            <div class="modal-content">
            <form>
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Detail Pengeluaran</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                      <table class="table">
                         <tr>
                           <td>Waktu Transaksi</td>
                           <td>:</td>
                           <td id="waktu"></td>
                         </tr>
                         <tr>
                           <td>Keterangan</td>
                           <td>:</td>
                           <td id="keterangan"></td>
                         </tr>
                         <tr>
                           <td>Besar Pengeluaran</td>
                           <td>:</td>
                           <td id="besar_pengeluaran"></td>
                         </tr>
                      
                         <tr>
                           <td>Kasir</td>
                           <td>:</td>
                           <td id="kasir"></td>
                         </tr>
                          <tr>
                           <td>Status</td>
                           <td>:</td>
                           <td id="status"></td>
                         </tr>
                         <tr>
                           <td>Bukti Pembayaran</td>
                           <td>:</td>
                           <td id="bukti"></td>
                         </tr>
                       </table>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                </div>
            </form>
              </div>
          </div>
        </div>






  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('/user/kassa/pengeluaran/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('/user/kassa/pengeluaran/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('/user/kassa/pengeluaran/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('/user/kassa/pengeluaran/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>







<script type="">
  
function detail(id_pengeluaran)
  {
    $('#detail_pengeluaran').modal('show');

    var status = ['Menunggu Verifikasi','Telah Di Verifikasi','Dibatalkan'];
    var approval = ['Pengeluaran Ditolak','Pengeluaran Di ACC'];
      $.ajax(
            {
              url     : baseUrl('/user/kassa/pengeluaran/detail_transaksi'),
              type    : 'POST',
              dataType: 'JSON',
              data    : { 
                id_pengeluaran : id_pengeluaran,
                
              },
              success : function(data)
              {
                console.log(data);
                $('#detail_pengeluaran').find('#waktu').html(data.transaksi.tgl_transaksi);
                $('#detail_pengeluaran').find('#keterangan').html(data.transaksi.keterangan);
                $('#detail_pengeluaran').find('#besar_pengeluaran').html('Rp. ' + number_format(data.transaksi.besar_pengeluaran));
                $('#detail_pengeluaran').find('#kasir').html(data.transaksi.kasir);
                if (data.transaksi.status!=1) {
                  $('#detail_pengeluaran').find('#status').html(status[data.transaksi.status]);

                }else{
                  $('#detail_pengeluaran').find('#status').html(status[data.transaksi.status] + " - " + approval[data.transaksi.approval] + '<br>' + data.transaksi.keterangan_approval);

                }
                $('#detail_pengeluaran').find('#bukti').html('<img src="'+baseUrl('file/pengeluaran/')+ data.transaksi.file + '" width="100%">');
                // window.location.href=baseUrl('user/kassa/pengeluaran');
              },
              error : function(){
                alert('ee');
                
              }
            });
  }

  
function hapus(id_kartu, file)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Hapus Kartu.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/kassa/pengeluaran/hapus'),
              type    : 'POST',
              data    : { 
                id_kartu : id_kartu,
                file : file,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/kassa/pengeluaran');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }


function batal(id_pengeluaran, file)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Batalkan pengeluaran.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/kassa/pengeluaran/batal'),
              type    : 'POST',
              data    : { 
                id_pengeluaran : id_pengeluaran,
                file : file,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/kassa/pengeluaran');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }


</script>