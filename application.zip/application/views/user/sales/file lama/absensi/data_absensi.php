 <div class="row">






    <div class="col-md-4">
      <div class="box">
       
        <div class="box-header">
           <h3 class="box-title">Check In</h3>
        </div>
        <div class="box-body">
          <div class="form-group">
            <label>Member</label>
            <button class="btn btn-info btn-xs pull-right"  data-toggle="modal" data-target="#list_member"  ><i class="fa fa-search"></i></button>
            <input type="hidden" name="" class="form-control">
          </div>
          <div class="form-group" id="show_check_in" style="display:none; overflow-x: scroll">
            Hasil Pencarian
            <table class="table">
              <tr>
                <td>Kode</td>
                <td>:</td>
                <td id="show_kode"></td>
              </tr>
              <tr>
                <td>Nama</td>
                <td>:</td>
                <td id="show_nama"></td>
              </tr>
              <tr>
                <td>Alamat</td>
                <td>:</td>
                <td id="show_alamat"></td>
              </tr>
              <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td id="show_keterangan"></td>
              </tr>
              <tr id="terdaftar_kelas"  style="display:none;">
                <td>Juga mengikuti Kelas</td>
                <td>:</td>
                <td id="show_kelas"></td>
              </tr>
            </table>
           

        </div>
      </div>

    </div>
  </div>
    <div class="col-md-8">














      <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right">
              <li class="active"><a href="#tab_1-1" data-toggle="tab">Check In Active</a></li>
              <li><a href="#tab_2-2" data-toggle="tab">Telah Checkout</a></li>
              <li><a href="#tab_absen_kelas" data-toggle="tab">Absensi Kelas</a></li>
          
              <li class="pull-left header">Kehadiran member tanggal <?php echo $tgl ?></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1-1">
                <?php echo $this->session->flashdata('pesan') ?>
                  <table class="table table-striped table-bordered" id="tabel_check_in">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Check In</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2-2">
               
                <?php echo $this->session->flashdata('pesan') ?>
                  <table class="table table-striped table-bordered" id="tabel_check_out" width="100%">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Durasi</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_absen_kelas">
                  <table class="table table-striped table-bordered" id="tabel_absen_kelas" width="100%">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Kelas Diikuti</th>
                        <th>Check In</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>








    </div>
  </div>



  <div class="modal fade" id="list_member">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">List Member</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_member" id="id_member" >
                <div class="form-group">
                   <table class="table data_tabel" width="100%">
                     <thead>
                       <tr>
                         <td>No</td>
                         <td>Kode</td>
                         <td>Nama</td>
                         <td>Alamat</td>
                         <td>Akhir Masa Aktif</td>
                         <td>Option</td>
                       </tr>
                     </thead>
                     <?php 
                     $no1=1;
                     $tgls = date('Y-m-d');
                     foreach ($member as $d1) { 
                      $id_member = $d1['id_member'];
                       $q_anggota = $this->db->query("SELECT akhir_masa_aktif, id_keanggotaan_member, id_jenis_member
            from  keanggotaan_member where id_member = '$id_member' order by akhir_masa_aktif desc limit 1
            ")->row_array();
                       $absensi = $this->db->query("SELECT *
                      from  absensi where id_member = '$id_member'  and tgl_check_in='$tgl'
                      ")->num_rows();
                        ?>
                        <tr>
                          <td><?php echo $no1++ ?></td>

                          <td><?php echo $d1['kode_member'] ;?></td>
                          <td><?php echo $d1['nama'] ;?></td>
                          <td><?php echo $d1['alamat'] ;?></td>
                          <td><?php echo $q_anggota['akhir_masa_aktif'] ;?></td>
                          <td> 
                            <?php if ($tgls>$q_anggota['akhir_masa_aktif']) { ?>
                              <button class="btn btn-danger btn-xs" onclick="tidak_aktif('<?php echo $d1['nama'] ;?>','<?php echo $q_anggota['akhir_masa_aktif'] ;?>')">Check In</button>
                              
                            <?php }else{ 
                              if ($absensi>0) {
                                $btn = "btn btn-warning btn-xs";
                              }else{
                                $btn = "btn btn-success btn-xs";

                              }
                              ?>
                              <button class="<?php echo $btn ?>" onclick="preview_member('<?php echo $d1['kode_member'] ;?>','<?php echo $q_anggota['id_jenis_member'] ;?>','<?php echo $q_anggota['id_keanggotaan_member'] ;?>')">Check In</button>

                            <?php } ?>
                          </td>
                         
                        </tr>
                      <?php } ?>
                   </table>


             
               
              </div>
            </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>



  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/absensi') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="pilih_kelas">
    <form action="<?php echo base_url('user/kassa/absensi/rekap_kelas') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
          
              <div class="modal-body">
                <center>
                <h4 class="modal-title">Pilih Kelas</h4> <br>
                  
                <?php foreach ($kelas as $k => $v) { ?>
                  <a href="<?php echo base_url('/user/kassa/absensi/absensi_kelas/'.$v['id_kelas'].'?bulan='.$bulan.'&tahun='.$tahun) ?>" class="btn btn-info btn-sm"><?php echo $v['kelas'] ?></a>
                <?php } ?>
               
                </center>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
    </form>
  </div>
<script>
  

function preview_member(kode_member, id_jenis_member, id_keanggotaan_member){
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/absensi/detail_member',
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                kode_member : kode_member,
                id_jenis_member : id_jenis_member,
                id_keanggotaan_member : id_keanggotaan_member,
                 },
              success : function(data)
              {
                console.log(data);
                $('#show_check_in').show();
                $('#show_kode').html(data.data.kode_member);
                $('#show_nama').html(data.data.nama);
                $('#show_alamat').html(data.data.alamat);
                $('#show_keterangan').html("Telah melakukan check in pada <br>"+data.waktu_check_in);
                $('#list_member').modal('hide');

                if (data.cek_kelas == 0 ) {
                  $('#terdaftar_kelas').hide();
                $('#show_nama').html('');

                }else{
                  $('#terdaftar_kelas').show();
                  var tombol_checkin_kelas = '<button type="button" class="btn btn-info btn-xs" onclick="checkin_kelas(`'+data.data.id_member+'`,`'+id_keanggotaan_member+'`,`'+data.kelas.id_kelas+'`,`'+data.kelas.id_detail_kelas+'`,`'+data.kelas.kelas+'`,`'+data.kelas.nama_paket_kelas+'`,`'+data.kelas.id_keanggotaan_member+'`)" id="tombol_checkin_kelas">Check in Kelas '+data.kelas.kelas+'</button>'
                $('#show_kelas').html(data.kelas.kelas + ' - ' + data.kelas.nama_paket_kelas+'<br>Aktif sampai '+data.kelas.akhir_masa_aktif+'<br>' + tombol_checkin_kelas);
                $('#tombol_checkin_kelas').show();

                }

                  $('#tabel_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_check_out').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                  // laporan_check_in();
              },
              error : function(){
                console.log('error');
              }
            });
          

}


function tidak_aktif(nama, expired){
   Swal.fire('Expired','Member '+ nama + " sudah tidak aktif. silahkan melakukan perpanjangan terlebih dahulu",'warning');
}



laporan_check_in();
laporan_check_out();
laporan_absen_kelas();
function laporan_check_in()
  {
    $('#tabel_check_in').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }


function laporan_check_out()
  {
    $('#tabel_check_out').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi_checkout?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }



function laporan_absen_kelas()
  {
    $('#tabel_absen_kelas').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi_kelas?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }



function checkout(id_absensi, member, tgl_check_in, jam_check_in)
  {
    Swal.fire({
        title: 'Checkout',
        html: 'Apakah member '+member+' sudah selesai melakukan gym.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
             $.ajax(
              {
                url     :'<?php echo base_url() ?>user/kassa/absensi/checkout/' + id_absensi + "/" + tgl_check_in + "/" + jam_check_in + "/ manual",
                dataType: 'JSON',
                type    : 'POST',
                data    : { 
                  // id_absensi : id_absensi,
                  // tgl_check_in : tgl_check_in,
                  // jam_check_in : jam_check_in,
                   },
                success : function(data)
                {
                
                console.log(data);
                 Swal.fire('Sudah Checkout','Member '+ member + " sudah checkout pada.",'success');
                 
                  $('#tabel_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_check_out').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                },
                error : function(){
                  console.log('error');
                }
              });
      

        
        }
      }); 
  }
function checkin_kelas(id_member, id_keanggotaan_member, id_kelas, id_detail_kelas, kelas, nama_paket_kelas, id_keanggotaan_member_kelas)
  {
    Swal.fire({
        title: 'Check in Kelas',
        html: 'Check in kelas '+kelas+'.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
             $.ajax(
              {
                url     :'<?php echo base_url() ?>user/kassa/absensi/checkin_kelas',
                dataType: 'JSON',
                type    : 'POST',
                data    : { 
                  id_member : id_member,
                  id_keanggotaan_member : id_keanggotaan_member_kelas,
                  id_kelas : id_kelas,
                  id_detail_kelas : id_detail_kelas,
                   },
                success : function(data)
                {
                
                console.log(data);
                 Swal.fire('Sudah Check In Kelas','Member '+ '' + " sudah melakukan checkin kelas "+kelas+" - "+nama_paket_kelas+".",'success');

                $('#tombol_checkin_kelas').hide();
                 
                  $('#tabel_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_check_out').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                },
                error : function(){
                  console.log('error');
                }
              });
      

        
        }
      }); 
  }
</script>









