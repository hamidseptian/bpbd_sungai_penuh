 <div class="row">






    <div class="col-md-12">














      <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right">
              <li ><a href="#tab_1-1" data-toggle="tab">Absensi Gym</a></li>
          
              <li class="pull-left header">Kehadiran member  <?php echo $caption ?> </li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1-1">
                <?php echo $this->session->flashdata('pesan') ?>
                  <table class="table table-striped table-bordered data_tabel">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Banyak Kehadiran</th>
                        <th>Jumlah Jam</th>
                     
                      
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($absensi as $k => $v) { ?>
                        <tr>
                          <td><?php echo $k+1 ?></td>
                          <td><?php echo $v['nama'] ?></td>
                          <td><?php echo $v['alamat'] ?></td>
                          <td><?php echo $v['kehadiran'] ?></td>
                          <td><?php echo str_replace('.000000', '', $v['durasi_kehadiran']) ?></td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2-2">
               
                <?php echo $this->session->flashdata('pesan') ?>
                  <table class="table table-striped table-bordered" id="tabel_check_out" width="100%">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Durasi</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_absen_kelas">
                  <table class="table table-striped table-bordered" id="tabel_absen_kelas" width="100%">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Kelas Diikuti</th>
                        <th>Check In</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>








    </div>
  </div>







  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

<script>
  

function preview_member(kode_member, id_jenis_member, id_keanggotaan_member){
  console.log(id_jenis_member);
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/absensi/detail_member',
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                kode_member : kode_member,
                id_jenis_member : id_jenis_member,
                id_keanggotaan_member : id_keanggotaan_member,
                 },
              success : function(data)
              {
                console.log(data);
                $('#show_check_in').show();
                $('#show_kode').html(data.data.kode_member);
                $('#show_nama').html(data.data.nama);
                $('#show_alamat').html(data.data.alamat);
                $('#show_keterangan').html("Telah melakukan check in pada <br>"+data.waktu_check_in);
                $('#list_member').modal('hide');

                if (data.cek_kelas == 0 ) {
                  $('#terdaftar_kelas').hide();
                $('#show_nama').html('');

                }else{
                  $('#terdaftar_kelas').show();
                  var tombol_checkin_kelas = '<button type="button" class="btn btn-info btn-xs" onclick="checkin_kelas(`'+data.data.id_member+'`,`'+id_keanggotaan_member+'`,`'+data.kelas.id_kelas+'`,`'+data.kelas.id_detail_kelas+'`,`'+data.kelas.kelas+'`,`'+data.kelas.nama_paket_kelas+'`)" id="tombol_checkin_kelas">Check in Kelas</button>'
                $('#show_kelas').html(data.kelas.kelas + ' - ' + data.kelas.nama_paket_kelas+'<br>Aktif sampai '+data.kelas.akhir_masa_aktif+'<br>' + tombol_checkin_kelas);
                $('#tombol_checkin_kelas').show();

                }

                  $('#tabel_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_check_out').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                  // laporan_check_in();
              },
              error : function(){
                console.log('error');
              }
            });
          

}


function tidak_aktif(nama, expired){
   Swal.fire('Expired','Member '+ nama + " sudah tidak aktif. silahkan melakukan perpanjangan terlebih dahulu",'warning');
}



laporan_check_in();
laporan_check_out();
laporan_absen_kelas();
function laporan_check_in()
  {
    $('#tabel_check_in').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }


function laporan_check_out()
  {
    $('#tabel_check_out').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi_checkout?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }



function laporan_absen_kelas()
  {
    $('#tabel_absen_kelas').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi_kelas?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }



function checkout(id_absensi, member)
  {
    Swal.fire({
        title: 'Checkout',
        html: 'Apakah member '+member+' sudah selesai melakukan gym.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
             $.ajax(
              {
                url     :'<?php echo base_url() ?>user/kassa/absensi/checkout',
                dataType: 'JSON',
                type    : 'POST',
                data    : { id_absensi : id_absensi },
                success : function(data)
                {
                
                console.log(data);
                 Swal.fire('Sudah Checkout','Member '+ member + " sudah checkout pada.",'success');
                 
                  $('#tabel_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_check_out').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                },
                error : function(){
                  console.log('error');
                }
              });
      

        
        }
      }); 
  }
function checkin_kelas(id_member, id_keanggotaan_member, id_kelas, id_detail_kelas, kelas, nama_paket_kelas)
  {
    Swal.fire({
        title: 'Check in Kelas',
        html: 'Check in kelas '+kelas+'.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
             $.ajax(
              {
                url     :'<?php echo base_url() ?>user/kassa/absensi/checkin_kelas',
                dataType: 'JSON',
                type    : 'POST',
                data    : { 
                  id_member : id_member,
                  id_keanggotaan_member : id_keanggotaan_member,
                  id_kelas : id_kelas,
                  id_detail_kelas : id_detail_kelas,
                   },
                success : function(data)
                {
                
                console.log(data);
                 Swal.fire('Sudah Checkout','Member '+ '' + " sudah checkout pada.",'success');

                $('#tombol_checkin_kelas').hide();
                 
                  $('#tabel_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_check_out').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                },
                error : function(){
                  console.log('error');
                }
              });
      

        
        }
      }); 
  }
</script>









