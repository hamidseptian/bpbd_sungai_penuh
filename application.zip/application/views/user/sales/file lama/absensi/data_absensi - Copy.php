 <div class="row">
    <div class="col-md-4">
      <div class="box">
       
        <div class="box-header">
           <h3 class="box-title">Check In</h3>
        </div>
        <div class="box-body">
          <div class="form-group">
            <label>Member</label>
            <button class="btn btn-info btn-xs pull-right"  data-toggle="modal" data-target="#list_member"  ><i class="fa fa-search"></i></button>
            <input type="hidden" name="" class="form-control">
          </div>
          <div class="form-group" id="show_check_in" style="display:none; overflow-x: scroll">
            Hasil Pencarian
            <table class="table">
              <tr>
                <td>Kode</td>
                <td>:</td>
                <td id="show_kode"></td>
              </tr>
              <tr>
                <td>Nama</td>
                <td>:</td>
                <td id="show_nama"></td>
              </tr>
              <tr>
                <td>Alamat</td>
                <td>:</td>
                <td id="show_alamat"></td>
              </tr>
              <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td id="show_keterangan"></td>
              </tr>
            </table>
        </div>
      </div>

    </div>
  </div>
    <div class="col-md-8">
      <div class="box">
        <div class="box-header">
           <h3 class="box-title">Kehadiran member tanggal <?php echo $tgl ?></h3>
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel_absensi">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Jam Check In</th>
             
              
              </tr>
            </thead>
          
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="list_member">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">List Member</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_member" id="id_member" >
                <div class="form-group">
                   <table class="table data_tabel" width="100%">
                     <thead>
                       <tr>
                         <td>No</td>
                         <td>Kode</td>
                         <td>Nama</td>
                         <td>Alamat</td>
                         <td>Akhir Masa Aktif</td>
                         <td>Option</td>
                       </tr>
                     </thead>
                     <?php 
                     $no1=1;
                     $tgls = date('Y-m-d');
                     foreach ($member as $d1) { 
                      $id_member = $d1['id_member'];
                       $q_anggota = $this->db->query("SELECT akhir_masa_aktif
            from  keanggotaan_member where id_member = '$id_member' order by akhir_masa_aktif desc limit 1
            ")->row_array();
                       $absensi = $this->db->query("SELECT *
                      from  absensi where id_member = '$id_member'  and tgl_check_in='$tgl'
                      ")->num_rows();
                        ?>
                        <tr>
                          <td><?php echo $no1++ ?></td>

                          <td><?php echo $d1['kode_member'] ;?></td>
                          <td><?php echo $d1['nama'] ;?></td>
                          <td><?php echo $d1['alamat'] ;?></td>
                          <td><?php echo $q_anggota['akhir_masa_aktif'] ;?></td>
                          <td> 
                            <?php if ($tgls>$q_anggota['akhir_masa_aktif']) { ?>
                              <button class="btn btn-danger btn-xs" onclick="tidak_aktif('<?php echo $d1['nama'] ;?>','<?php echo $q_anggota['akhir_masa_aktif'] ;?>')">Check In</button>
                              
                            <?php }else{ 
                              if ($absensi>0) {
                                $btn = "btn btn-warning btn-xs";
                              }else{
                                $btn = "btn btn-success btn-xs";

                              }
                              ?>
                              <button class="<?php echo $btn ?>" onclick="preview_member('<?php echo $d1['kode_member'] ;?>')">Check In</button>

                            <?php } ?>
                          </td>
                         
                        </tr>
                      <?php } ?>
                   </table>


             
               
              </div>
            </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>



  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/absensi') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>
<script>
  

function preview_member(kode_member){
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/absensi/detail_member',
              dataType: 'JSON',
              type    : 'POST',
              data    : { kode_member : kode_member },
              success : function(data)
              {
                $('#show_check_in').show();
                $('#show_kode').html(data.data.kode_member);
                $('#show_nama').html(data.data.nama);
                $('#show_alamat').html(data.data.alamat);
                $('#show_keterangan').html("Telah melakukan check in pada <br>"+data.waktu_check_in);
                $('#list_member').modal('hide');

                  // $('#tabel_absensi').DataTable().ajax.reload(null, false);
                  laporan_absensi();
              },
              error : function(){
                console.log('error');
              }
            });
          

}


function tidak_aktif(nama, expired){
   Swal.fire('Expired','Member '+ nama + " sudah tidak aktif. silahkan melakukan perpanjangan terlebih dahulu",'warning');
}



laporan_absensi();
function laporan_absensi()
  {
    $('#tabel_absensi').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi?tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }

</script>









