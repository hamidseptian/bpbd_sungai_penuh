  <div class="row">






    <div class="col-md-6">
      <div class="box">
       
        <div class="box-header">
           <h3 class="box-title">Data member yang belum check in hari ini <br>Kelas <?php echo $kelas['kelas'] ?></h3>
        </div>
        <div class="box-body">
         
          <div class="form-group" id="show_check_in" style="overflow-x: scroll">
             <table class="table table-striped table-bordered" id="member_belum_check_in">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Paket</th>
                        <th>Check In</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
           

        </div>
      </div>

    </div>
  </div>
    <div class="col-md-6">














      <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right">
              <li class="active"><a href="#tab_absen_kelas_hari_ini" data-toggle="tab">Check In Hari ini</a></li>
          
              <li class="pull-left header">Kehadiran member kelas <?php echo $kelas['kelas'] ?></li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane" id="tab_1-1">
                <?php echo $this->session->flashdata('pesan') ?>
                  <table class="table table-striped table-bordered" id="tabel_check_in">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Check In</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <div class="tab-pane active" id="tab_absen_kelas_hari_ini">
                
                  <table class="table table-striped table-bordered" id="tabel_absen_kelas" width="100%">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Check In</th>
                     
                      
                      </tr>
                    </thead>
                  
                  </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>








    </div>
  </div>









  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/absensi/rekap/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>
<script type="text/javascript">
  member_kelas_belum_checkin();
function member_kelas_belum_checkin()
  {
    $('#member_belum_check_in').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_member_kelas_belum_checkin?id_kelas=<?php echo $kelas['id_kelas'] ?>&tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }
</script>



<script>
  
function tidak_aktif(nama, expired){
   Swal.fire('Expired','Member '+ nama + " sudah tidak aktif. silahkan melakukan perpanjangan terlebih dahulu",'warning');
}



laporan_absen_kelas();



function laporan_absen_kelas()
  {
    $('#tabel_absen_kelas').DataTable(
    {
          processing  : true,
          serverSide  : true,
          bDestroy  : true,
          responsive  : true,
          ajax    : {
                    url   : '<?php echo base_url() ?>user/kassa/absensi/dt_absensi_kelas_terkait?id_kelas=<?php echo $kelas['id_kelas'] ?>&tgl=<?php echo $tgl ?>',
                    type  : "POST",
                    data  : {
                      // tgl : '<?php echo $tgl ?>'
                    },
                  },
       
      });
  }

function checkin_kelas(id_member, id_keanggotaan_member, id_kelas, id_detail_kelas, kelas, nama_paket_kelas)
  {
    Swal.fire({
        title: 'Check in Kelas',
        html: 'Check in kelas '+kelas+'.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
             $.ajax(
              {
                url     :'<?php echo base_url() ?>user/kassa/absensi/checkin_kelas',
                dataType: 'JSON',
                type    : 'POST',
                data    : { 
                  id_member : id_member,
                  id_keanggotaan_member : id_keanggotaan_member,
                  id_kelas : id_kelas,
                  id_detail_kelas : id_detail_kelas,
                   },
                success : function(data)
                {
                
                 Swal.fire('Sudah Checkin','Member '+ '' + " sudah check in pada.",'success');

                 
                  $('#member_belum_check_in').DataTable().ajax.reload(null, false);
                  $('#tabel_absen_kelas').DataTable().ajax.reload(null, false);
                },
                error : function(){
                  console.log('error');
                }
              });
      

        
        }
      }); 
  }
</script>









