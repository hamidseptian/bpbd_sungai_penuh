 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Jenis Produk</td>
                <td>Produk</td>
                <td>Stok</td>
              
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            foreach ($fnb as $d1) { 
              $stok_tersedia = $d1['qty_masuk']-$d1['qty_keluar'] ; 
              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis'] ?></td>
                <td><?php echo $d1['produk'] ?></td>
                <td><?php echo $stok_tersedia == '' ? 0 : $stok_tersedia   ?></td>
               
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/kassa/fnb/simpan_stok') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Stok FnB</h4>
              </div>
              <div class="modal-body">
               
                <div class="form-group">
                  <label>Jenis FnB</label>
                  

                  <select class="form-control" name="id_fnb" id="id_fnb">
                        <?php foreach ($fnb as $v) { ?>
                          <option value="<?php echo $v['id_fnb'] ?>"><?php echo $v['jenis'] .' - '.$v['produk'] ?></option>
                        <?php } ?>
                      </select>



                </div>
                 <div class="form-group">
                  <label>Jumlah</label>
                  <input type="number" class="form-control" name="qty" required onkeypress="return isNumber(event)" >
                </div>
                 <div class="form-group">
                  <label>Tgl Masuk Produk</label>
                  <input type="date" class="form-control" name="tgl" required value="<?php echo date('Y-m-d') ?>">
                </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>



<script>
  

function hapus(id_fnb, metode_pembayaran)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Hapus FnB '+metode_pembayaran+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/fnb/hapus'),
              type    : 'POST',
              data    : { 
                id_fnb : id_fnb,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/fnb');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_fnb)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/fnb/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_fnb : id_fnb,
                
              },
              success : function(data)
              {
                  $('#edit_metode').find('#id_fnb').val(data.id_fnb);
                  $('#edit_metode').find('#fnb').val(data.produk);
                  $('#edit_metode').find('#jenis').val(data.jenis).change();
                  $('#edit_metode').find('#harga').val(data.harga);
                  $('#edit_metode').find('#status').val(data.status).change();
              },
              error : function(){
              }
            });
          }
      

</script>









