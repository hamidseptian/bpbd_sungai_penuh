 


 <div class="row">
    <div class="col-md-8">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">FnB</h3>
         
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <table class="table data_tabel table-striped table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Option</th>
              </tr>
            </thead>
            <tbody>
               <?php 
               $no=1;foreach ($fnb as $k => $v) { 

              $stok_tersedia = $v['qty_masuk']-$v['qty_keluar'] ; 
              ?>
              <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $v['jenis'] ?></td>
                <td><?php echo $v['produk'] ?></td>
                <td>Rp. <?php echo number_format($v['harga']) ?></td>
                <td id="stok_tersedia_<?php echo $v['id_fnb'] ?>"><?php echo $stok_tersedia ?></td>
                <td>
                  <?php if ($stok_tersedia>0) { ?>
                    <a href="javascript:void(0)" onclick="catat_order('<?php echo $v['id_fnb'] ?>')" class="btn btn-info btn-xs">Order</a>
                  <?php }else{ ?>
                    <a href="javascript:void(0)" onclick="Swal.fire('Tidak bisa order','Stok <?php echo $v['produk'] ?> saat ini sedang kosong','error')" class="btn btn-danger btn-xs">Order</a>
                  <?php } ?>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>

          <div class="row"  style="max-height:600px; overflow-y: scroll; display:none">
            <?php foreach ($fnb as $k => $v) { 

              $stok_tersedia = $v['qty_masuk']-$v['qty_keluar'] ; 
              ?>
            <a href="javascript:void(0)" onclick="catat_order('<?php echo $v['id_fnb'] ?>')">
              
              <div class="col-md-4">

                  <div class="info-box bg-aqua" style="padding:7px">
                   
                <h4>
                      <?php echo $v['produk'] ?>
                    </h4>
                    <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                    <span class="pull-left"><?php echo $v['jenis'] ?> <br>Stok : <?php echo $stok_tersedia ?> </span> <h4 class="info-box-number pull-right">Rp. <?php echo number_format($v['harga']) ?></h4>
                    <div class="clearfix"></div> 
                  </div>
              </div>
            </a>
          <?php } ?>
          </div>





        
        </div>


      </div>
    </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">List Order</h3>
         
        </div>
        <div class="box-body" id="show_list_order_keranjang" style="max-height:500px; overflow-y: scroll">
          

         





        
        </div>


      </div>
      <div id="total_belanja">
    
      </div>
    </div>
  </div>


  <div class="modal fade" id="detail_fnb">
    <form action="<?php echo base_url('user/kassa/fnb/simpan_stok') ?>" method='post' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Produk</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_fnb" id="id_fnb" >
               <input type="hidden" class="form-control" name="id_order_fnb" id="id_order_fnb" >
                <div class="form-group">
                   <table class="table">
                     <tr>
                       <td>Produk</td>
                       <td>:</td>
                       <td id="produk"></td>
                     </tr>
                     <tr>
                       <td>Harga</td>
                       <td>:</td>
                       <td id="harga"></td>
                     </tr>
                     <tr>
                       <td>Tersedia</td>
                       <td>:</td>
                       <td class="stok_tersedia"></td>
                     </tr>
                    
                   </table>
                </div>
                 <div class="form-group">
                  <label>Jumlah Order</label>
                  <input type="number" class="form-control" name="qty" required onkeypress="return isNumber(event)" id="qty" >
                  <input type="hidden" class="form-control" name="stok_tersedia" required onkeypress="return isNumber(event)" id="stok_tersedia" >
                  <input type="hidden" class="form-control" name="harga_satuan"  id="harga_satuan" >
                  <input type="hidden" class="form-control" name="modal_satuan"  id="modal_satuan" >
                </div>
                 <div class="form-group">
                  <label>Catatan</label>
                  <textarea class="form-control" name="catatan" rows="4" id="catatan"></textarea>
                </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="simpan_order()" id="save_order">Simpan</button>
                <button type="button" class="btn btn-primary" onclick="simpanedit_order()" id="saveedit_order">Simpan Perubahan</button>
              </div>
            </div>
          </div>
    </form>
        </div>



  <div class="modal fade" id="konfirmasi_pembayaran">
    <form action="" method='post' id="">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Konfirmasi Pembayaran</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_fnb" id="id_fnb" >
                <div class="form-group" id="total_konfirmasi_pembayaran">
                  
                </div>
              
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="simpan_transaksi()">Simpan</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="print_order_fnb">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_fnb">
              
              </div>
              <div class="modal-footer">

                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
                <button type="button" class="btn btn-primary" onclick="close_order_fnb()">Kembali ke Menu Order</button>
              </div>
            </div>
          </div>
        </div>



  <div class="modal fade" id="entertain">
    <form action="#" method='post' id="">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Entartain FnB</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_fnb" id="id_fnb" >
                <div class="form-group" id="form_entertain">
                  
                </div>
              
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="simpan_entertain()">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>

<
<script>
list_order();
function catat_order(id_fnb)
  {
    $('#detail_fnb').modal('show');
    $('#detail_fnb').find('#save_order').show();
    $('#detail_fnb').find('#saveedit_order').hide();
            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/detail_fnb'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_fnb : id_fnb,
                
              },
              success : function(data)
              {
                // console.log(data);
                var stok_tersedia = data.qty_masuk - data.qty_keluar;
                  $('#detail_fnb').find('#id_fnb').val(data.id_fnb);
                  $('#detail_fnb').find('#produk').html(data.produk);
                  $('#detail_fnb').find('#harga').html(number_format(data.harga));
                  $('#detail_fnb').find('#harga_satuan').val(data.harga);
                  $('#detail_fnb').find('#modal_satuan').val(data.modal);
                  $('#detail_fnb').find('#qty').val('1');
                  $('#detail_fnb').find('#stok_tersedia').val(stok_tersedia);
                  $('#detail_fnb').find('.stok_tersedia').html(stok_tersedia);
                  $('#detail_fnb').find('#catatan').val('');


              },
              error : function(){
                console.log('e');
              }
            });
          }
      
function edit_keranjang(id_order_fnb)
  {
    $('#detail_fnb').modal('show');

    $('#detail_fnb').find('#save_order').hide();
    $('#detail_fnb').find('#saveedit_order').show();
            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/edit_keranjang'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_order_fnb : id_order_fnb,
                
              },
              success : function(data)
              {
                console.log(data);
                var stok_tersedia = data.qty_masuk - data.qty_keluar;
                var catatan = data.catatan.replaceAll("<br />", "");
                  $('#detail_fnb').find('#id_order_fnb').val(data.id_order_fnb);
                  $('#detail_fnb').find('#id_fnb').val(data.id_fnb);
                  $('#detail_fnb').find('#produk').html(data.produk);
                  $('#detail_fnb').find('#harga').html(number_format(data.harga));
                  $('#detail_fnb').find('#qty').val(data.qty);
                  $('#detail_fnb').find('#stok_tersedia').val(stok_tersedia);
                  $('#detail_fnb').find('.stok_tersedia').html(stok_tersedia);
                  $('#detail_fnb').find('#catatan').val(catatan);
              },
              error : function(){
                console.log('e');
              }
            });
          }
      
function simpan_order()
  {
    var form_data = $('#form_catat_order').serialize();
    var qty = parseInt($('#detail_fnb').find('#qty').val());
    var id_fnb = parseInt($('#detail_fnb').find('#id_fnb').val());
    var stok = parseInt($('#detail_fnb').find('#stok_tersedia').val());
    if (qty=='' || qty=='0') {
      Swal.fire('Error','Harap masukan jumlah pesanan','error');
    }
    else if (qty>stok) {
      
      Swal.fire('Error','Pesanan melebihi stok. Stok tersedia : ' + stok,'error');
    }else{

            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/masuk_keranjang'),
              // dataType: 'JSON',
              type    : 'POST',
              data    : form_data,
              success : function(data)
              {
                $('#detail_fnb').modal('hide');
                var sisa_stok = stok - qty;
                  $('#stok_tersedia_'+ id_fnb ).html(sisa_stok);
                list_order();
                 
              },
              error : function(){
                console.log('error');
              }
            });
          }
    }
function simpanedit_order()
  {
    var form_data = $('#form_catat_order').serialize();
    var qty = parseInt($('#detail_fnb').find('#qty').val());
    var id_fnb = parseInt($('#detail_fnb').find('#id_fnb').val());
    var stok = parseInt($('#detail_fnb').find('#stok_tersedia').val());
    if (qty=='' || qty=='0') {
      Swal.fire('Error','Harap masukan jumlah pesanan','error');
    }
    else if (qty>stok) {
      
      Swal.fire('Error','Pesanan melebihi stok. Stok tersedia : ' + stok,'error');
    }else{

            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/simpanedit_keranjang'),
              // dataType: 'JSON',
              type    : 'POST',
              data    : form_data,
              success : function(data)
              {
                $('#detail_fnb').modal('hide');
                  var sisa_stok = stok - qty;
                  $('#stok_tersedia_'+ id_fnb ).html(sisa_stok);
                list_order();
                 
              },
              error : function(){
                console.log('error');
              }
            });
          }
    }
function simpan_transaksi()
  {

    var jumlah = $('#total_konfirmasi_pembayaran').find('#total_transaksi').val();
    var metode_pembayaran = $('#total_konfirmasi_pembayaran').find('#metode_pembayaran').val();
    var simpan_kembalian_pembayaran = $('#total_konfirmasi_pembayaran').find('#simpan_kembalian_pembayaran').val();
    var simpan_dibayar = $('#total_konfirmasi_pembayaran').find('#simpan_dibayar').val();
            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/simpan_transaksi'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                jumlah : jumlah,
                metode_pembayaran : metode_pembayaran,
                simpan_kembalian_pembayaran : simpan_kembalian_pembayaran,
                simpan_dibayar : simpan_dibayar,
              },
              success : function(data)
              {
                console.log(data.id_transaksi);
               print_order_fnb(data.id_transaksi);
                 
              },
              error : function(){
                alert('error');
              }
            });
          }
function close_order_fnb()
  {
    window.location.href = baseUrl('user/kassa/fnb/order');
}
function print_order_fnb(id_transaksi)
  {

    $('#konfirmasi_pembayaran').modal('hide');
    $('#print_order_fnb').modal('show');
    $('#print_order_fnb').find('#struk_order_fnb').html(`
      <iframe src="`+ baseUrl('user/kassa/fnb/print_order_fnb/') + id_transaksi +`/?status_print=settlement&action=Lunas" width="100%" height="400px"></iframe>
      `);
            // $.ajax(
            // {
            //   url     : baseUrl('/user/kassa/fnb/simpan_transaksi'),
            //   dataType: 'JSON',
            //   type    : 'POST',
            //   data    : { 
            //     jumlah : jumlah,
            //     metode_pembayaran : metode_pembayaran,
            //   },
            //   success : function(data)
            //   {
            //     console.log(data.id_transaksi);
            //    print_order_fnb(data.id_transaksi);
                 
            //   },
            //   error : function(){
            //     alert('error');
            //   }
            // });

             $('#show_list_order_keranjang').html(`

                  <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Transaksi Disimpan <br>Belum ada order baru</h4>
                                </div>
                              </div>
              `);

                       $('#total_belanja').html(``);


          }
function simpan_entertain()
  {
    var jumlah = $('#entertain').find('#total_transaksi').val();
    var f_entertain = $('#entertain').find('#f_entertain').val();
    var keterangan = $('#entertain').find('#keterangan').val();
            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/simpan_entertain'),
              // dataType: 'JSON',
              type    : 'POST',
              data    : { 
                jumlah : jumlah,
                f_entertain : f_entertain,
                keterangan : keterangan,
              },
              success : function(data)
              {
               window.location.href= baseUrl('/user/kassa/fnb/order');
                 
              },
              error : function(){
                alert('error');
              }
            });
          }
      
function hapus_keranjang(id_order, id_fnb, nama_item, qty)
  {


    Swal.fire({
      title: "Hapus Item " + nama_item +".?",
        showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText: "Hapus"
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        
           $.ajax(
              {
                url     : baseUrl('/user/kassa/fnb/hapus_keranjang'),
                // dataType: 'JSON',
                type    : 'POST',
                data    : { id_order : id_order},
                success : function(data)
                {
                 list_order();

                 var stok_awal = $('#stok_tersedia_' + id_fnb).html();
                 var tambah_stok = parseInt(stok_awal) + parseInt(qty);
                 $('#stok_tersedia_' + id_fnb).html(tambah_stok);
                 // alert(id_fnb);
                },
                error : function(){
                  alert('error');
                }
              });



      } else if (result.isDenied) {
        // Swal.fire("Changes are not saved", "", "info");
      }
    });





           
          }
      
function list_order(){
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/fnb/list_order_keranjang',
              dataType: 'JSON',
              type    : 'POST',
              data    : {},
              success : function(data)
              {
                if (data.jml_item > 0 ) {
                  $('#show_list_order_keranjang').html(`

                    <ul class="list-group list-group-unbordered" id="daftar_item">
              
              </ul>

              `);
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                     <a href="javascript:void(0)" class="btn btn-info btn-xs" onclick="edit_keranjang('` +v.id_order_fnb +`')"><i class="fa fa-pencil"></i></a>
                     <a href="javascript:void(0)" class="btn btn-info btn-xs" onclick="hapus_keranjang('` +v.id_order_fnb +`','` +v.id_fnb +`','` +v.produk +`','` +v.qty +`')"><i class="fa fa-times"></i></a>
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });


                  $('#total_belanja').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3>Rp. `+number_format(total_belanja)+`</h3>
                                </div>
                              </div>
                                 <div  class="btn btn-block btn-group" >
                              <center>
                                <button class="btn btn-info" onclick="konfirmasi_pembayaran('`+total_belanja+`')">Pembayaran</button>
                                <button class="btn btn-default" onclick="entertain('`+total_belanja+`')">Entertain</button>
                              </center>
                              </div>
        </div>
        </div>

              `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada order</h4>
                                </div>
                              </div>
              `);

                       $('#total_belanja').html(``);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}


function konfirmasi_pembayaran(total){


    $('#konfirmasi_pembayaran').modal('show');
    $('#total_konfirmasi_pembayaran').html(`

    <input type="hidden" class="form-control" name="total_transaksi" id="total_transaksi" value="`+total+`" >
      <div class="form-group">
        <div class="row">
          <div class="col-md-12">
            <div class="small-box bg-gray">
              <div class="inner">
                <p>Total</p>
                <h3>Rp. `+number_format(total)+`</h3>
              </div>
            </div>
          </div>
        </div>
       
      </div>
      <div class="form-group">
        <div class="row">
          <div class="col-md-6">
            <label>Metode Pembayaran</label>
            <select class="form-control" name="metode_pembayaran" id="metode_pembayaran"></select>
          </div>
          <div class="col-md-6">
           <label>Pembayaran</label>
            <input type="number" class="form-control" name="pembayaran_plg" id="pembayaran_plg" onkeypress="return isNumber(event)">
            <input type="hidden" class="form-control" name="simpan_kembalian_pembayaran" id="simpan_kembalian_pembayaran" value="0" >
            <input type="hidden" class="form-control" name="simpan_dibayar" id="simpan_dibayar" value="`+total+`" >
          </div>
           
        </div>
      </div>

<br>





      <div class="form-group">
        <div class="row">
          <div class="col-md-6">
            <div class="small-box bg-gray">
              <div class="inner">
                <p>Dibayar</p>
                <h3>Rp. <span id="show_dibayar">`+number_format(total)+`</span></h3>
              </div>
            </div>
          </div>
          <div class="col-md-6">
          <div class="small-box bg-gray">
            <div class="inner">
              <p>Kembalian</p>
              <h3>Rp. <span id="show_kembalian">0</span></h3>
            </div>
          </div>
          </div>
         
        </div>
       
      </div>






      

      `);
var metode_pembayaran = <?php echo $metode_pembayaran ?>;
    $('#total_konfirmasi_pembayaran').find('#metode_pembayaran').html('');
$.each(metode_pembayaran, function(k,v){

    $('#total_konfirmasi_pembayaran').find('#metode_pembayaran').append('<option value="'+v.id_metode_pembayaran+'">'+v.metode_pembayaran+'</option>');
  // console.log(v);

})



$('#total_konfirmasi_pembayaran').find('#pembayaran_plg').keyup(function(){
  var harus_dibayar = $('#total_konfirmasi_pembayaran').find('#total_transaksi').val();
  var dibayar = $('#total_konfirmasi_pembayaran').find('#pembayaran_plg').val();
  var sisa =parseInt(dibayar) -  parseInt(harus_dibayar); 
  if (dibayar =='') {
  $('#total_konfirmasi_pembayaran').find('#show_dibayar').html(number_format(harus_dibayar));
  $('#total_konfirmasi_pembayaran').find('#show_kembalian').html(0);
  $('#total_konfirmasi_pembayaran').find('#simpan_kembalian_pembayaran').val(0);
  $('#total_konfirmasi_pembayaran').find('#simpan_dibayar').val(harus_dibayar);

  }else{
  $('#total_konfirmasi_pembayaran').find('#show_dibayar').html(number_format(dibayar));
  $('#total_konfirmasi_pembayaran').find('#show_kembalian').html(number_format(sisa));
  $('#total_konfirmasi_pembayaran').find('#simpan_kembalian_pembayaran').val(sisa);
  $('#total_konfirmasi_pembayaran').find('#simpan_dibayar').val(dibayar);

  }
  // $('#total_konfirmasi_pembayaran').find('#kembalian').val(number_format(sisa));
});

}

function entertain(total){

    $('#entertain').modal('show');
    $('#form_entertain').html(`

    <input type="hidden" class="form-control" name="total_transaksi" id="total_transaksi" value="`+total+`" >
      <div class="form-group">
        <div class="row">
          <div class="col-md-12">
            <div class="small-box bg-gray">
              <div class="inner">
                <p>Total</p>
                <h3>Rp. `+number_format(total)+`</h3>
              </div>
            </div>
          </div>
        </div>
       
      </div>
      <div class="form-group">
        <div class="row">
          <div class="col-md-12">
            <label>Entertain</label>
            <select class="form-control" name="f_entertain" id="f_entertain">
              <option>Instruktur</option>
              <option>Office</option>
              <option>Event</option>
            </select>
          </div>
      
        </div>
      </div>

      <div class="form-group">
        <div class="row">
          <div class="col-md-12">
           <label>Keterangan</label>
            <textarea class="form-control" name="keterangan" id="keterangan" rows="4"></textarea>
          </div>
           
        </div>
      </div>

<br>
      `);




}



</script>









