 <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title"><?php echo $caption ?></h3>
        </div>
       <input type="hidden" name="" id="id_transaksi_terakhir">
       <input type="hidden" name="" id="status_fnb">
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Waktu Transaksi</th>
                <th>Total Transaksi</th>
                <th>Status</th>
                <th>Kasir</th>
                <th>Action</th>
              
              </tr>
            </thead>
            <tbody>
              
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            $total_transaksi = 0 ;
            foreach ($fnb as $d1) { 
              if ($d1['status']=='Lunas') {
                $css = "";
                $total_transaksi +=$d1['total'];
              }else{
                $css = "style='color:red'";

              }
              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['tgl_transaksi'].'<br>'.$d1['jam_transaksi'] ?></td>
                <td align="right" <?php echo $css ?>><?php echo number_format($d1['total']) ?></td>
                <td><?php echo $d1['status'] ?></td>
                <td><?php echo $d1['kasir'] ?></td>
                <td> 
                  <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#detail_transaksi" onclick="detail_transaksi('<?php echo $d1['id_transaksi_fnb'] ?>','<?php echo $d1['tgl_transaksi'] ?>','<?php echo $d1['jam_transaksi'] ?>','<?php echo $d1['status'] ?>')">Detail</button>
                </td>
               
              </tr>
            <?php } ?>
            </tbody>
            <tfoot>
              <th colspan="2">Total</th>
              <th align="right" style="text-align:right"><?php echo number_format($total_transaksi) ?></th>
              <td ></td>
              <td ></td>
              <td ></td>
            </tfoot>
          </table>
        </div>


      </div>
    </div>
  </div>




  <div class="modal fade" id="detail_transaksi">
    <form action="<?php echo base_url('user/kassa/sourvenir/simpan_stok') ?>" method='post' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_sourvenir" id="id_sourvenir" >
             
                 <div class="form-group">
                  <ul class="list-group list-group-unbordered" id="daftar_item">
                  </ul>
              
                </div>

                <div class="form-group">
                   <table class="table">
                     <tr>
                       <td>Status</td>
                       <td>:</td>
                       <td id="status"></td>
                     </tr>
                     <tr>
                       <td id="tindakan">Metode Pembayaran</td>
                       <td>:</td>
                       <td id="detail_tindakan"></td>
                     </tr>
                     <tr>
                       <td>Waktu Transaksi</td>
                       <td>:</td>
                       <td id="waktu"></td>
                     </tr>
                  
                     <tr>
                       <td>Kasir</td>
                       <td>:</td>
                       <td id="kasir"></td>
                     </tr>
                    
                   </table>


                </div>


                 <div id="total_belanja">
    
                  </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-default" onclick="print_order_fnb()">Print</button>
              </div>
            </div>
          </div>
    </form>
        </div>




  <div class="modal fade" id="print_order_fnb">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_fnb">
              
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Tutup</button>
              </div>
            </div>
          </div>
        </div>



<script>




function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/fnb/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
                console.log(data.transaksi);
              if (data.transaksi.status=='Entertain') {
                $('#tindakan').html("Entertain");
                $('#detail_tindakan').html(data.transaksi.entertain + '<br>' + data.transaksi.keterangan);

              }else{
                $('#detail_tindakan').html(data.transaksi.metode_pembayaran);
                $('#tindakan').html("Metode Pembayaran");

              }

              $('#waktu').html(data.transaksi.tgl_transaksi + '<br>'+data.transaksi.jam_transaksi);
              $('#kasir').html(data.transaksi.kasir + ' - '+data.transaksi.jabatan);
              $('#status').html(data.transaksi.status);
              $('#id_transaksi_terakhir').val(data.id_transaksi);
              $('#status_fnb').val(data.transaksi.status);
                // console.log(data.transaksi);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });

                $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>Total</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(total_belanja)+`</b> <br>
                    
                     </span>
                 
                  </li>
                `);



        //           $('#total_belanja').html(`
        // <div class="box-body" >
        //     <div class="small-box bg-gray">
        //                         <div class="inner">

        //                           <p>Total</p>
        //                           <h3>Rp. `+number_format(total_belanja)+`</h3>
        //                         </div>
        //                       </div>
        // </div>

        //       `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}



function print_order_fnb()
  {
    var id_transaksi = $('#id_transaksi_terakhir').val();
    var action = $('#status_fnb').val();
    var status_print = action == 'Lunas' ? 'reprint' : 'preview';
    $('#detail_transaksi').modal('hide');
    $('#print_order_fnb').modal('show');
    $('#print_order_fnb').find('#struk_order_fnb').html(`
      <iframe src="`+ baseUrl('user/kassa/fnb/print_order_fnb/') + id_transaksi +`/?status_print=`+status_print+`&action=`+action+`" width="100%" height="400px"></iframe>
      `);
            // $.ajax(
            // {
            //   url     : baseUrl('/user/kassa/fnb/simpan_transaksi'),
            //   dataType: 'JSON',
            //   type    : 'POST',
            //   data    : { 
            //     jumlah : jumlah,
            //     metode_pembayaran : metode_pembayaran,
            //   },
            //   success : function(data)
            //   {
            //     console.log(data.id_transaksi);
            //    print_order_fnb(data.id_transaksi);
                 
            //   },
            //   error : function(){
            //     alert('error');
            //   }
            // });
          }

</script>









