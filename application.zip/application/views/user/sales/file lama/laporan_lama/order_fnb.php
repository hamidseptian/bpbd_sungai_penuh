 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Waktu Transaksi</th>
                <th>Total Transaksi</th>
                <th>Action</th>
              
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            $total_transaksi = 0 ;
            foreach ($fnb as $d1) { 
              $total_transaksi +=$d1['total'];
              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['tgl_transaksi'].'<br>'.$d1['jam_transaksi'] ?></td>
                <td align="right"><?php echo number_format($d1['total']) ?></td>
                <td> 
                  <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#detail_transaksi" onclick="detail_transaksi('<?php echo $d1['id_transaksi_fnb'] ?>','<?php echo $d1['tgl_transaksi'] ?>','<?php echo $d1['jam_transaksi'] ?>')">Detail</button>
                </td>
               
              </tr>
            <?php } ?>
            <tfoot>
              <th colspan="2">Total</th>
              <th align="right" style="text-align:right"><?php echo number_format($total_transaksi) ?></th>
              <td ></td>
            </tfoot>
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="detail_transaksi">
    <form action="<?php echo base_url('user/kassa/fnb/simpan_stok') ?>" method='post' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_fnb" id="id_fnb" >
                <div class="form-group">
                   <table class="table">
                     <tr>
                       <td>Waktu Transaksi</td>
                       <td>:</td>
                       <td id="waktu"></td>
                     </tr>
                    
                   </table>


                </div>
                 <div class="form-group">
                  <ul class="list-group list-group-unbordered" id="daftar_item">
                  </ul>
              
                </div>
                 <div id="total_belanja">
    
                  </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
    </form>
        </div>

<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
  $('#waktu').html(tgl_transaksi + '<br>'+jam_transaksi);
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/fnb/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
                console.log(data.jml_item);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });


                  $('#total_belanja').html(`
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3>Rp. `+number_format(total_belanja)+`</h3>
                                </div>
                              </div>
        </div>

              `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}

</script>









