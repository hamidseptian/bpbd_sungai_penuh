 <div class="row">
    <div class="col-md-12">
      <div class="box">
       
        <div class="box-body">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <td width="20px">No</td>
                <td>Jenis Produk</td>
                <td>Produk</td>
                <td>Option</td>
              
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            foreach ($fnb as $d1) { 
              $stok_tersedia = $d1['qty_masuk']-$d1['qty_keluar'] ; 
              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis'] ?></td>
                <td><?php echo $d1['produk'] ?></td>
                <td>
                  <a href="javascript:void(0)"  data-toggle="modal" data-target="#tambah">Lihat Rekap</a>
                </td>
               
              </tr>
            <?php } ?>
            
          </table>
        </div>


      </div>
    </div>
  </div>


  <div class="modal fade" id="tambah">
    <form action="<?php echo base_url('user/kassa/fnb/simpan_stok') ?>" method='post'>  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Rekap Fnb </h4>
              </div>
              <div class="modal-body">
               <table class="table ">
                 <tr>
                   <td>Kategori</td>
                   <td>:</td>
                   <td></td>
                 </tr>
                 <tr>
                   <td>Produk</td>
                   <td>:</td>
                   <td></td>
                 </tr>
               </table>
               <table class="table data_tabel" width="100%">
                 <thead>
                   <tr>
                     <td>No</td>
                     <td>Tgl Masuk</td>
                     <td>Qty</td>
                   </tr>
                 </thead>
                 <tr>
                   <td>1</td>
                   <td>2022-12-12</td>
                   <td>3</td>
                 </tr>
               </table>
                













            </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
    </form>
        </div>



<script>
  

function hapus(id_fnb, metode_pembayaran)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Hapus FnB '+metode_pembayaran+' .?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/admin/fnb/hapus'),
              type    : 'POST',
              data    : { 
                id_fnb : id_fnb,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/admin/fnb');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }



 


function edit(id_fnb)
  {
    
            $.ajax(
            {
              url     : baseUrl('/user/admin/fnb/edit'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_fnb : id_fnb,
                
              },
              success : function(data)
              {
                  $('#edit_metode').find('#id_fnb').val(data.id_fnb);
                  $('#edit_metode').find('#fnb').val(data.produk);
                  $('#edit_metode').find('#jenis').val(data.jenis).change();
                  $('#edit_metode').find('#harga').val(data.harga);
                  $('#edit_metode').find('#status').val(data.status).change();
              },
              error : function(){
              }
            });
          }
      

</script>









