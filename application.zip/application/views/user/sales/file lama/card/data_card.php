 <?php 
              $no=1;
                foreach($card as $v){ 
                $src_foto = base_url('file/kartu/'.$v['file']);  
                  ?>

                     <style>
  .example_<?php echo $v['id_kartu_member'] ?> {
  border: 2px solid black;
  background: url(<?php echo $src_foto ?>);
  background-repeat: no-repeat;
    background-size: 100% 100%;
    width : 100%;
    height : auto;
    /*opacity: 0.5;*/
}
</style>

<?php   } ?>


<div class="row">

   
    <div class="col-md-12">
      <div class="box" style="overflow-x: scroll">
    
        <div class="box-body">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Card</th>
                <th>Jenis Member</th>
                <th>Status</th>
                <th>Option</th>
             
              
              </tr>
            </thead>
            <tbody> 
              <?php 
              $no=1;
                foreach($card as $v){ 
                $src_foto = base_url('file/kartu/'.$v['file']);  
                  ?>
              <tr>  
                <td><?php echo $no++ ?></td>
                <td width="400px">














                <div id="get_capture" class="example_<?php echo $v['id_kartu_member'] ?>" width="100%">
                  <div class="header" style="margin:5px; border-bottom:  solid; height:30px">
                  <div style="float:right; font-family:'calibri';color:white; font-size:16px">
                    Gym Membership Card 
                  </div>
                <!--   <div  style="float:right">
                    <img src="<?php echo base_url('assets/gambar/logo.png') ?>" width="50px">     
                  </div> -->
                  <div  style="clear:both">
                        
                  </div>
                 </div>




                 <div class="body">
                  <div style="float:left; margin-left : 1%; margin-right : 2%; width:32%;">
                    <img src="<?php echo $src_foto  ?>" width="100%" style="border:solid; border-color:white">     
                  </div>
                  <div  style="float:left; width:65%;  font-family:'calibri'; color:white">
                    <span style="font-size: 20px; text-align: justify; text-justify: inter-word;"><b>Nama Member</b></span> <br>
                    <span style="font-size: 16px; ">No HP</span> <br>
                    <span style="font-size: 16px; "><?php echo $v['jenis_member'] ?></span> <br>
                  </div>
                  <div  style="clear:both">
                        
                  </div>

                 </div>



          
                  <div class="footer">

                    <div style="float:left; font-family:'calibri';background:white; margin-top:5px">
                    <img src="<?php echo base_url('assets/gambar/barcode.png') ?>" width="130px" height="25px">
                  </div>
                <div  style="float:right">
                    <div style=" text-align: right; margin-bottom:30px; color:white;font-size: 16px;">Masa aktif <?php echo date('Y-m-d') ?></div>    
                  </div>
                  <div  style="clear:both">
                        
                  </div>
                 </div>



              </div>













            </td>
                <td><?php echo $v['jenis_member'] ?></td>
                <td><?php echo $status[$v['status']] ?></td>
                <td>
                  <?php if ($v['status']==0) { ?>
                    <a href="javascript:void(0)" class="btn btn-info btn-xs"  onclick="aktifkan('<?php echo $v['id_kartu_member'] ?>','<?php echo $v['id_jenis_member'] ?>')">Aktifkan</a>
                    <a href="javascript:void(0)" class="btn btn-info btn-xs"  onclick="hapus('<?php echo $v['id_kartu_member'] ?>','<?php echo $v['file'] ?>')">Hapus</a>
                  <?php }else{ ?>
                    <a href="javascript:void(0)" class="btn btn-info btn-xs"  onclick="hapus('<?php echo $v['id_kartu_member'] ?>','<?php echo $v['file'] ?>')">Hapus</a>
                </td>
              <?php   } ?>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="tambah_kartu">
          <div class="modal-dialog">
            <div class="modal-content">
            <form action="<?php echo base_url('/user/kassa/card/simpan_kartu') ?>" enctype="multipart/form-data" method="post">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Tambah kartu Member</h4>
                </div>
                <div class="modal-body">
                     <div class="form-group">
                    <label>Jenis Member</label>
                     <select name="id_jenis_member" id="id_jenis_member" class="form-control">
                      <?php foreach ($jenis_member as $k => $v) { ?>
                        <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Gambar Kartu</label>
                    <input type="file" name="berkas" class="form-control" required>
                  </div>
               
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-info pull-right">Upload</button>
                </div>
            </form>
              </div>
          </div>
        </div>


  <div class="modal fade" id="kartu_aktif">
          <div class="modal-dialog">
            <div class="modal-content">
            <form action="<?php echo base_url('/user/kassa/card/simpan_kartu') ?>" enctype="multipart/form-data" method="post">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Kartu Member Aktif</h4>
                </div>
                <div class="modal-body">
                    







                     <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th>Card</th>
             
              
              </tr>
            </thead>
            <tbody> 
              <?php 
              $no=1;
                foreach($card_active as $v){ 
                $src_foto = base_url('file/kartu/'.$v['file']);  
                  ?>
              <tr>  

                <td width="400px">


<b><?php echo $v['jenis_member'] ?></b>











                <div id="get_capture" class="example_<?php echo $v['id_kartu_member'] ?>" width="100%">
                 <div class="header" style="margin:5px; border-bottom:  solid">
                  <div style="float:left; font-family:'calibri'; color:white">
                    Gym Membership Card 
                  </div>
                  <div  style="float:right">
                    <img src="<?php echo base_url('assets/gambar/logo.png') ?>" width="50px">     
                  </div>
                  <div  style="clear:both">
                        
                  </div>
                 </div>


                 <div class="body">
                  <div style="float:left; margin-left : 1%; margin-right : 2%; width:32%;">
                    <img src="<?php echo $src_foto  ?>" width="100%" style="border:solid; border-color:white">     
                  </div>
                  <div  style="float:left; width:65%;  font-family:'calibri'">
                    <span style="font-size: 20px; text-align: justify; text-justify: inter-word;"><b>Nama Member</b></span> <br>
                    <span style="font-size: 12px; ">No HP</span> <br>
                    <span style="font-size: 12px; "><?php echo $v['jenis_member'] ?></span> <br>
                  </div>
                  <div  style="clear:both">
                        
                  </div>

                 </div>
                 <div class="footer">
                  <table style="margin-left : 1%; margin-right : 1%; width:98%; margin-bottom:5px; "> 
                    <tr>
                      <td style="width:35%;"><center> <img src="<?php echo base_url('assets/gambar/barcode.png') ?>" width="100%" height="25px"></center></td>
                      <td style="border-right: solid; border-left : solid" ><center> Kode Member</center></td>
                      <td style="width:30%; text-align: right">Masa Aktif</td>
                    </tr>
                  </table>
                 

                 </div>
              </div>


<br>










            </td>

              </tr>
            <?php } ?>
            </tbody>
          </table>




                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                </div>
            </form>
              </div>
          </div>
        </div>


<script type="">
  
function aktifkan(id_kartu, id_jenis_member)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Ganti Kartu Aktif.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/kassa/card/aktifkan'),
              type    : 'POST',
              data    : { 
                id_kartu : id_kartu,
                id_jenis_member : id_jenis_member,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/kassa/card');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }

  
function hapus(id_kartu, file)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Hapus Kartu.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/kassa/card/hapus'),
              type    : 'POST',
              data    : { 
                id_kartu : id_kartu,
                file : file,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/kassa/card');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }


</script>