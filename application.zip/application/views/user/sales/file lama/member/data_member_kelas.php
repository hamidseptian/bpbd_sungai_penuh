 <div class="row">
<div class="col-md-3">
  <div class="row">
      <div class="col-lg-12 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo count($member_aktif) ?></h3>

              <p>member Aktif</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="#member_aktif" data-toggle="tab" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
      <div class="col-lg-12 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo count($member_dormant) ?></h3>

              <p>Member Expired</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="#member_expired" data-toggle="tab" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
  </div>
</div>

  <div class="col-md-9">
          <!-- Custom Tabs -->

          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#member_aktif" data-toggle="tab">Aktif</a></li>
              <li><a href="#member_expired" data-toggle="tab">Expired</a></li>
              <li><a href="#member_dormant" data-toggle="tab">Dormant</a></li>
        
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="member_aktif" style="overflow-x: scroll">
                <table class="table table-striped table-bordered data_tabel">
                  <thead>
                    <tr>
                      <th width="20px">No</th>
                      <th>Nama</th>
                      <th>Alamat</th>
                      <th>No HP</th>
                      <th>Email</th>
                      <th>Waktu Register</th>
                      <th>Masa Aktif</th>
                      <th>Action</th>
                    
                    </tr>
                  </thead>
                  <?php 
                  $no=1;
                  foreach ($member_aktif as $d1) { 

                            $id_member = $d1['id_member'];
                             $q_anggota = $this->db->query("SELECT akhir_masa_aktif
                  from  keanggotaan_member where id_member = '$id_member' order by akhir_masa_aktif desc limit 1
                  ")->row_array();

                    ?>
                    <tr>
                      <td><?php echo $no++ ?></td>

                      <td><?php echo $d1['nama'] ;?></td>
                   
                      <td><?php echo $d1['alamat'] ;?></td>
                      <td><?php echo $d1['no_hp'] ;?></td>
                      <td><?php echo $d1['email'] ;?></td>
                      <td><?php echo $d1['tgl_register'].'<br>'.$d1['jam_register'] ?></td>
                      <td><?php echo $d1['akhir_masa_aktif'] ;?></td>
                      <td> 
                        <a href="<?php echo base_url('user/kassa/member/detail/'.enkripsi($d1['id_member'])) ?>" class="btn btn-warning btn-xs" >Detail</a>
                      </td>
                     
                    </tr>
                  <?php } ?>
         
                </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="member_expired">
                <table class="table table-striped table-bordered data_tabel">
                  <thead>
                    <tr>
                      <th width="20px">No</th>
                      <th>Nama</th>
                      <th>Alamat</th>
                      <th>No HP</th>
                      <th>Email</th>
                      <th>Waktu Register</th>
                      <th>Masa Aktif</th>
                      <th>Action</th>
                    
                    </tr>
                  </thead>
                  <?php 
                  $no=1;
                  foreach ($member_dormant as $d1) { 

                         
                    ?>
                    <tr>
                      <td><?php echo $no++ ?></td>

                      <td><?php echo $d1['nama'] ;?></td>
                   
                      <td><?php echo $d1['alamat'] ;?></td>
                      <td><?php echo $d1['no_hp'] ;?></td>
                      <td><?php echo $d1['email'] ;?></td>
                      <td><?php echo $d1['tgl_register'].'<br>'.$d1['jam_register'] ?></td>
                      <td><?php echo $d1['akhir_masa_aktif'] ;?></td>
                      <td> 
                        <a href="<?php echo base_url('user/kassa/member/detail/'.enkripsi($d1['id_member'])) ?>" class="btn btn-warning btn-xs" >Detail</a>
                      </td>
                     
                    </tr>
                  <?php } ?>
         
                </table>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="member_dormant">
                <table class="table table-striped table-bordered data_tabel">
                  <thead>
                    <tr>
                      <th width="20px">No</th>
                      <th>Nama</th>
                      <th>Alamat</th>
                      <th>No HP</th>
                      <th>Email</th>
                      <th>Waktu Register</th>
                      <th>Masa Aktif</th>
                      <th>Action</th>
                    
                    </tr>
                  </thead>
                  <?php 
                  $no=1;
                  foreach ($member_expired as $d1) { 

                         
                    ?>
                    <tr>
                      <td><?php echo $no++ ?></td>

                      <td><?php echo $d1['nama'] ;?></td>
                   
                      <td><?php echo $d1['alamat'] ;?></td>
                      <td><?php echo $d1['no_hp'] ;?></td>
                      <td><?php echo $d1['email'] ;?></td>
                      <td><?php echo $d1['tgl_register'].'<br>'.$d1['jam_register'] ?></td>
                      <td><?php echo $d1['akhir_masa_aktif'] ;?></td>
                      <td> 
                        <a href="<?php echo base_url('user/kassa/member/detail/'.enkripsi($d1['id_member'])) ?>" class="btn btn-warning btn-xs" >Detail</a>
                      </td>
                     
                    </tr>
                  <?php } ?>
         
                </table>
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->





  <div class="modal fade" id="detail_transaksi">
    <form action="<?php echo base_url('user/kassa/member/simpan_stok') ?>" method='post' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_member" id="id_member" >
                <div class="form-group">
                   <table class="table">
                     <tr>
                       <td>Waktu Transaksi</td>
                       <td>:</td>
                       <td id="waktu"></td>
                     </tr>
                    
                   </table>


                </div>
                 <div class="form-group">
                  <ul class="list-group list-group-unbordered" id="daftar_item">
                  </ul>
              
                </div>
                 <div id="total_belanja">
    
                  </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
    </form>
        </div>






  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/member/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/member/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/member/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/member/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>




<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
  $('#waktu').html(tgl_transaksi + '<br>'+jam_transaksi);
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/member/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
                console.log(data.jml_item);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });


                  $('#total_belanja').html(`
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3>Rp. `+number_format(total_belanja)+`</h3>
                                </div>
                              </div>
        </div>

              `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}

</script>









