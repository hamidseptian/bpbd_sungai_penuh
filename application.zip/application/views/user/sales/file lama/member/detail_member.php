
  <script type="text/javascript" src="<?php echo base_url('assets/html2canvas/') ?>html2canvas.js"></script> 

  <style>
  .example1 {
  border: 2px  black;
  background: url(<?php echo $bg_card ?>);
  background-repeat: no-repeat;
    background-size: 100% 100%;
    width : 100%;
    height : auto;
    /*opacity: 0.5;*/
}
</style>


  <div class="row">
  <div class="col-md-12">
  <?php 
  if ($this->session->flashdata('id_transaksi')) { ?>
      <script type="text/javascript">
        $(document).ready(function(){
  print_order_member("<?php echo $this->session->flashdata('id_transaksi') ?>");
});
      </script>
   <?php } else{
   }

   echo $this->session->flashdata('pesan');
  ?>
</div>
        <div class="col-md-4">


          <div class="box box-primary">
            <div class="box-body box-profile">
              <?php if ($member['foto']=='') { 
                $src_foto = base_url('assets/gambar/user.webp');  
                ?>
              <?php }else{ 
                $src_foto = base_url('file/member/'.$member['foto']);  
                ?>

              <?php } ?>

                <img class=" img-responsive " src="<?php echo $src_foto  ?>" alt="User profile picture" width="100%">
              <h3 class="profile-username text-center"><?php echo $member['nama'] ?></h3>

                <?php echo $register ?>
              
              <hr>
                <strong>No Identitas</strong>
              <p class="text-muted">
               <?php echo $member['jenis_identitas'].' / '.$member['no_identitas'] ?>
              </p>
               <strong>Nama</strong>
              <p class="text-muted">
               <?php echo $member['nama'] ?>
              </p>
               <strong>Jenis kelamin</strong>
              <p class="text-muted">
               <?php echo $member['jk'] ?>
              </p>
                <strong>Tempat / Tgl Lahir</strong>
              <p class="text-muted">
               <?php echo $member['tmpl'].' / '.$member['tgll'] ?>
              </p>
               <strong>Alamat</strong>
              <p class="text-muted">
               <?php echo $member['alamat'] ?>
              </p>
               <strong>No HP</strong>
              <p class="text-muted">
               <?php echo $member['no_hp'] ?>
              </p>
                <strong>Pekerjaan</strong>
              <p class="text-muted">
               <?php echo $member['pekerjaan'] ?>
              </p>
               <strong>Email</strong>
              <p class="text-muted">
               <?php echo $member['email'] ?>
              </p>
             
               <strong>Instagram</strong>
              <p class="text-muted">
               <?php echo $member['ig'] ?>
              </p>
             
             



            </div>
            
          </div>
          

          <?php if ($terdaftar>0) { ?>
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Kartu Member</h3>
            </div>
            
            <div class="box-body">
              





                <div id="get_capture" class="example1" width="100%">
                 <div class="header" style="margin:5px; border-bottom:  solid; height:30px">
                  <div style="float:right; font-family:'calibri';color:white; font-size:16px">
                    Gym Membership Card 
                  </div>
                <!--   <div  style="float:right">
                    <img src="<?php echo base_url('assets/gambar/logo.png') ?>" width="50px">     
                  </div> -->
                  <div  style="clear:both">
                        
                  </div>
                 </div>


                 <div class="body">
                  <div style="float:left; margin-left : 1%; margin-right : 2%; width:32%;">
                    <img src="<?php echo $src_foto  ?>" width="100%" style="border:solid; border-color:white">     
                  </div>
                  <div  style="float:left; width:65%;  font-family:'calibri'; color:white">
                    <span style="font-size: 20px; text-align: justify; text-justify: inter-word;"><b> <?php echo $member['nama'] ?></b></span> <br>
                    <span style="font-size: 16px; "><?php echo $member['no_hp'] ?></span> <br>
                    <span style="font-size: 16px; "><?php echo $jenis_member ?></span> <br>
                  </div>
                  <div  style="clear:both">
                        
                  </div>

                 </div>
                 <div class="footer">

                    <div style="float:left; font-family:'calibri';background:white; margin-top:5px">
                    <?php echo $barcode ?>
                  </div>
                <div  style="float:right">
                    <div style=" text-align: right; margin-bottom:30px; color:white;font-size: 16px;"><?php echo $masa_aktif_terakhir ?></div>    
                  </div>
                  <div  style="clear:both">
                        
                  </div>
                 </div>
              </div>
              <div id="result"></div>
              <a href="#" class="download btn btn-info btn-sm btn-block" style="margin-top:5px">Download</a>





            </div>
            
          </div>
        <?php } ?>
          
        </div>
        
        <div class="col-md-8">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">Keanggotaan Membership</a></li>
              <li><a href="#timeline" data-toggle="tab">Absensi</a></li>
              <li><a href="#kelas" data-toggle="tab">Keanggotaan Kelas</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity" style="overflow-x: scroll">
                
              <table class="table table-striped table-bordered" id="tabel1">
                <thead>
                  <tr>
                    <th width="20px">No</th>
                    <th>Jenis Paket</th>
                    <th>Masa Aktif</th>
                    <th>Akhir masa aktif</th>
                    <th>Biaya</th>
                   
                    <th>metode pembayaran</th>
                    <th>Tanggal Register</th>
                    <th>Action</th>
                  
                  </tr>
                </thead>
                <?php 
                $no=1;
                foreach ($keanggotaan_member as $d1) { 
                  if ($d1['id_jenis_member']=='Pendaftaran') { ?>
                      <tr>
                        <td><?php echo $no++ ?></td>

                        <td>Registrasi Member</td>
                        <td >-</td>
                        <td>-</td>
                        <td align="right">100.000</td>
                        <td><?php echo $d1['metode_pembayaran'] ;?></td>
                    <td><?php echo $d1['tgl_register'] ;?></td>
                     
                        <td> 
                          <button  class="btn btn-info btn-xs" onclick="print_order_member('<?php echo enkripsi($d1['id_transaksi_member']) ?>')" id="tesss">
                Print Struk
              </button>  
                        </td>
                       
                      </tr>
                  <?php }else{ ?>
                  <tr>
                    <td><?php echo $no++ ?></td>

                    <td ><?php 
                      echo $d1['jenis_member'];
                   
                     ;?></td>
                    <td><?php echo $d1['masa_aktif'].' '.$d1['satuan_masa_aktif'] ;?></td>
                    <td><?php echo $d1['akhir_masa_aktif'] ;?></td>
                    <td align="right"><?php echo number_format($d1['biaya']) ;?></td>
                 
                    <td><?php echo $d1['metode_pembayaran'] ;?></td>
                    <td><?php echo $d1['tgl_register'] ;?></td>
                    <td> 
                          <button  class="btn btn-info btn-xs" onclick="print_order_member('<?php echo enkripsi($d1['id_transaksi_member']) ?>')">
                Print Struk
              </button>  
                        </td>
                   
                  </tr>
                <?php 
                }
              } ?>
       
              </table>

                
                
                

                
                
                
              </div>
              
              <div class="tab-pane" id="timeline" style="overflow-x: scroll">
                
                


                  <table class="table table-striped table-bordered data_tabel">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Durasi</th>
                     
                      
                      </tr>
                    </thead>
                    <tbody>
                      <?php 
                      $no=1;
                      foreach ($absensi as $d1) { ?>
                        <tr>
                          <td><?php echo $no++ ?></td>
                          <td><?php echo $d1['tgl_check_in'].'<br>'.$d1['jam_check_in'] ?></td>
                          <td><?php echo $d1['tgl_check_out'].'<br>'.$d1['jam_check_out'] ?></td>
                          <td><?php echo $d1['durasi'] ?></td>
                        </tr>
                      <?php } ?>
                    </tbody>
          
          </table>



              </div>
              
              <div class="tab-pane" id="kelas" style="overflow-x: scroll">
                
                


                       
              <table class="table table-striped table-bordered data_tabel" id="data_tabel">
                <thead>
                  <tr>
                    <th width="20px">No</th>
                    <th>Nama Kelas</th>
                    <th>Instruktur</th>
                    <th>Masa Aktif</th>
                    <th>Akhir masa aktif</th>
                    <th>Biaya</th>
                   
                    <th>metode pembayaran</th>
                    <th>Tanggal Register</th>
                    <th>Action</th>
                  
                  </tr>
                </thead>
                <?php 
                $no=1;
                foreach ($keanggotaan_kelas as $d1) { 
                  ?>
                  <tr>
                    <td><?php echo $no++ ?></td>

                    <td ><?php 
                      echo $d1['kelas'];
                   
                     ;?></td>
                    <td><?php echo $d1['instruktur'] ;?></td>
                    <td><?php echo $d1['pertemuan'].' kali pertemuan' ;?></td>
                    <td><?php echo $d1['akhir_masa_aktif'] ;?></td>
                    <td align="right"><?php echo number_format($d1['biaya']) ;?></td>
                 
                    <td><?php echo $d1['metode_pembayaran'] ;?></td>
                    <td><?php echo $d1['tgl_register'] ;?></td>
                    <td> 
                          <button  class="btn btn-info btn-xs" onclick="print_order_member('<?php echo enkripsi($d1['id_transaksi_member']) ?>')">
                Print Struk
              </button>  
                        </td>
                   
                  </tr>
                <?php 
               
              } ?>
       
              </table>




              </div>
              

            
              
            </div>
            
          </div>
          
        </div>
        
      </div>





  <div class="modal fade" id="edit_member">
    <form action="<?php echo base_url('user/kassa/member/simpanedit_member') ?>" method='post' id="" enctype="multipart/form-data" style="overflow-x:  scroll; height: 600px">  
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Edit Data Member</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_member" id="id_member" value="<?php echo $member['id_member'] ?>">
               

                <div class="row">
                  <div class="col-md-6">
                  
                   <div class="form-group">
                    <label>No Identitas</label>
                    <div class="row">
                      <div class="col-md-4">
                        <select class="form-control" name="jenis_identitas" id="input_jenis_identitas">
                          <option <?php if($member['jenis_identitas']=='KTP'){ echo "selected";} ?>>KTP</option>
                          <option <?php if($member['jenis_identitas']=='SIM'){ echo "selected";} ?>>SIM</option>
                        </select>
                      </div>
                      <div class="col-md-8">

                <input type="hidden" name="file_foto_webcam" class="image-tag">
                        <input type="text" name="no_identitas" id="input_no_identitas" class="form-control" value="<?php echo $member['no_identitas'] ?>">
                        
                      </div>
                    </div>
                  </div>


                  <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" id="input_nama" class="form-control" value="<?php echo $member['nama'] ?>" required>
                  </div>
                  <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="jk" id="input_jk" class="form-control">
                      <option <?php if($member['jk']=='Laki laki'){echo 'selected';} ?>>Laki laki</option>
                      <option <?php if($member['jk']=='Perempuan'){echo 'selected';} ?>>Perempuan</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" name="tmpl" id="input_email" class="form-control" value="<?php echo $member['tmpl'] ?>">
                  </div>

                  <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <?php 
                    $pecah_tgll  = explode('-', $member['tgll']); ?>
                    <div class="row">
                      <div class="col-md-3">
                        <select class="form-control" name="input_tgll" id="input_tgll">
                          <?php for ($i=1; $i <= 31 ; $i++) { ?>
                          <option  <?php if($i==$pecah_tgll[2]){echo "selected";} ?>><?php echo $i ?></option>
                          <?php } ?>
                        </select>
                        
                      </div>
                      <div class="col-md-6">
                        <select class="form-control" name="input_blll" id="input_blll">
                          <?php for ($i=1; $i <= 12 ; $i++) { ?>
                          <option value="<?php echo $i ?>" <?php if($i==$pecah_tgll[1]){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                          <?php } ?>
                        </select>
                      </div>
                      <div class="col-md-3">
                        <select class="form-control" name="input_thll" id="input_thll">
                          <?php for ($i=date('Y'); $i >= 1945 ; $i--) { ?>
                          <option  <?php if($i==$pecah_tgll[0]){echo "selected";} ?>><?php echo $i ?></option>
                          <?php } ?>
                        </select>
                        
                      </div>
                      
                    </div>
                  </div>

                  <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" id="input_alamat" class="form-control" value="<?php echo $member['alamat'] ?>">
                  </div>


                </div>
                <div class="col-md-6">

                  <div class="form-group">
                    <label>No HP</label>
                    <input type="text" name="nohp" id="input_nohp" class="form-control" value="<?php echo $member['no_hp'] ?>">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" name="email" id="input_email" class="form-control" value="<?php echo $member['email'] ?>">
                  </div>
                  <div class="form-group">
                    <label>Pekerjaan</label>
                    <input type="text" name="pekerjaan" id="input_email" class="form-control" value="<?php echo $member['pekerjaan'] ?>">
                  </div>

                  <div class="form-group">
                    <label>Instagram</label>
                    <input type="text" name="ig" id="input_email" class="form-control" value="<?php echo $member['ig'] ?>">
                    <input type="hidden" name="foto_lama" id="" class="form-control" value="<?php echo $member['foto'] ?>">
                  </div>


                   <div class="form-group">
                      <label>Foto</label>

                      <button class="btn btn-danger btn-xs" onclick="ambil_foto()" type="button">Ambil Foto</button>
                      <input type="file" name="berkas" id="berkas" accept="image/*" > <br>
                      <img src="" class="show_foto" width="100%">
                      <input type="hidden" name="mode_foto" id="mode_foto">

                    </div>


                </div>
                </div>


               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>




  <div class="modal fade" id="print_order_member">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_member">
              
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Tutup</button>
              </div>
            </div>
          </div>
        </div>



  <div class="modal fade" id="ambil_foto">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Ambil Foto</h4>
              </div>
              <div class="modal-body" id="struk_order_member">



 <div class="row">
            <div class="col-md-6">
              <center>
                
                <div id="my_camera" style=""></div> <br>
              </center>
                <input type=button value="Screenshoot" onclick="take_snapshot()" class="btn btn-info btn-block">
            </div>
            <div class="col-md-6">
              <center>
                
                <div id="results">Your captured image will appear here...</div> <br>
              </center>
                <button type="button" class="btn btn-success btn-block" onclick="gunakan_foto()" id="tombol_gunakan_foto" style="display:none">Gunakan foto ini</button>
            </div>
            
        </div>



              
              </div>
            </div>
          </div>
        </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>


<script type="text/javascript">
  
var  elemen = document.querySelector("#get_capture");
// html2canvas(elemen).then(canvas => {
//     document.body.appendChild(canvas)
// });
html2canvas(elemen).then(function(canvas){
  document.querySelector("#result").append(canvas);
  var cvs = document.querySelector("canvas");
  var unduh = document.querySelector(".download");
  unduh.href = cvs.toDataURL();
  unduh.download="Membercard_<?php echo $member['nama'] ?>.jpg";
  $('#get_capture').attr('style','display:none');
})



 function ambil_foto(){
    $('#ambil_foto').modal('show');
     Webcam.set({
        width: 400,
        height: 300,
        image_format: 'jpeg',
        jpeg_quality: 100
    });
  
    Webcam.attach( '#my_camera' );
  }

    function take_snapshot() {
        Webcam.snap( function(data_uri) {
            $(".image-tag").val(data_uri);
            document.getElementById('results').innerHTML = '<img src="'+data_uri+'" />';
            $('#tombol_gunakan_foto').show();
        console.log(data_uri);
        } );

    }
    function gunakan_foto() {
            var fotonya = $(".image-tag").val();
            $('.show_foto').attr('src', fotonya);
            $('#ambil_foto').modal('hide');
            $('#mode_foto').val('webcam');
          

    }



function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.show_foto').attr('src', e.target.result);
            $('#src_foto').val(e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#berkas").change(function(){
    readURL(this);
});

function print_order_member(id_transaksi)
  {

    $('#print_order_member').modal('show');
    $('#print_order_member').find('#struk_order_member').html(`
      <iframe src="`+ baseUrl('user/kassa/member/print_order_member/') + id_transaksi +`/?status_print=reprint&action=Lunas" width="100%" height="400px"></iframe>
      `);
          }




function perpanjangan(link)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Member ini sudah expirex lebih 2 tahun dan harus melakukan pendaftaran member baru.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            window.location.href=link
      

        
        }
      }); 
  }



function daftar_baru(link)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Data ini tidak terdaftar sebagai member. melakukan pendaftaran member baru.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Lanjutkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            window.location.href=link
      

        
        }
      }); 
  }






</script>