 


 <div class="row">
    <div class="col-md-12">
    <?php echo $this->session->flashdata('pesan') ?>
  </div>

    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title" style="color:red">Layanan</h3>
         
        </div>
        <div class="box-body">
          
          <div class="form-group">
            <select name="layanan" id="layanan" class="form-control">
              <option value="">Pilih Layanan</option>
              <option value="">Membership</option>
              <option value="">Kelas</option>
              <option value="">Membership + Kelas</option>
            
            </select>
          </div>
          <div class="form-group" id="detail_jenis_member">
            
          </div>

        
        </div>


      </div>
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Paket Gym</h3>
         
        </div>
        <div class="box-body">
          
          <div class="form-group">
            <label>Paket</label>
            <select name="id_jenis_member" id="id_jenis_member" class="form-control">
              <option value=""></option>
              <?php foreach ($jenis_member as $k => $v) { ?>
                <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group" id="detail_jenis_member">
            
          </div>

        
        </div>


      </div>
    </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Identitas Member</h3>
         
        </div>
        <div class="box-body">
          
          <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" id="input_nama" class="form-control">
          </div>
          <div id="form_identitas_member_input" hidden="true">
          <div class="form-group">
            <label>No Identitas</label>
            <div class="row">
            	<div class="col-md-4">
            		<select class="form-control" name="input_jenis_identitas" id="input_jenis_identitas">
            			<option>KTP</option>
            			<option>SIM</option>
            		</select>
            	</div>
            	<div class="col-md-8">
		            <input type="text" name="input_no_identitas" id="input_no_identitas" class="form-control">
            		
            	</div>
            </div>
          </div>
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jk" id="input_jk" class="form-control">
              <option>Laki laki</option>
              <option>Perempuan</option>
            </select>
          </div>
           <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" name="nama" id="input_tmpl" class="form-control">
          </div>
          <div class="form-group">
            <label>Tanggal Lahir</label>
            <div class="row">
            	<div class="col-md-3">
            		<select class="form-control" name="input_tgll" id="input_tgll">
            			<?php for ($i=1; $i <= 31 ; $i++) { ?>
            			<option><?php echo $i ?></option>
            			<?php } ?>
            		</select>
            		
            	</div>
            	<div class="col-md-6">
            		<select class="form-control" name="input_blll" id="input_blll">
            			<?php for ($i=1; $i <= 12 ; $i++) { ?>
            			<option value="<?php echo $i ?>"><?php echo bulan_global($i) ?></option>
            			<?php } ?>
            		</select>
            	</div>
            	<div class="col-md-3">
            		<select class="form-control" name="input_thll" id="input_thll">
            			<?php for ($i=date('Y'); $i >= 1945 ; $i--) { ?>
            			<option><?php echo $i ?></option>
            			<?php } ?>
            		</select>
            		
            	</div>
            	
            </div>
          </div>

          <div class="form-group">
            <label>Pekerjaan</label>
            <input type="text" name="nohp" id="input_pekerjaan" class="form-control">
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" name="alamat" id="input_alamat" class="form-control">
          </div>
          <div class="form-group">
            <label>No HP</label>
            <input type="text" name="nohp" id="input_nohp" class="form-control">
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" id="input_email" class="form-control">
          </div>
          <div class="form-group">
            <label>Instagram</label>
            <input type="text" name="email" id="input_ig" class="form-control">
          </div>
         

        
        </div>
      </div>

      </div>
    </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Transaksi</h3>
         
        </div>
        <div class="box-body" id="show_list_order_keranjang" style="max-height:500px; overflow-y: scroll">
          <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada Transaksi</h4>
                                </div>
                              </div>
        </div>
        <div class="box-body" id="total_biaya" style="display:none; margin-top:-40px">
         
        </div>
        <input type="hidden" name="" id="total_biaya_register">
        <div class="box-body" id="diskon" style="display:none; margin-top:-20px">
          <table class="table">
                      <tr>
                        <td>Berikan Diskon</td>
                        <td>:</td>
                        <td>
                          <select class="form-control" id="diskon_member">
                              <option value="">Tanpa Diskon</option>
                            <?php foreach ($diskon as $k => $v) { ?>
                              <option value="<?php echo $v['id_diskon'] ?>"><?php echo $v['nama_diskon'] ?></option>
                            <?php } ?>
                          </select>
                        </td>
                      </tr>
                      <tbody id="detail_diskon">
                        
                    
                      </tbody>
                    
                  <input type="hidden" id="nilai_besar_diskon" value="0">
                    </table>
        </div>
          

         





        


      </div>
      <div id="total_belanja">
    
      </div>
      <div id="show_input_simpan_diskon">
    
      </div>
    </div>
  </div>


  <div class="modal fade" id="konfirmasi_member">
    <form  id="form_pendaftaran_member" enctype="multipart/form-data">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Konfirmasi</h4>
              </div>
              <div class="modal-body">
            <input type="hidden" name="nama" id="simpan_nama" class="form-control">
            <input type="hidden" name="jk" id="simpan_jk" class="form-control">
            <input type="hidden" name="alamat" id="simpan_alamat" class="form-control">
            <input type="hidden" name="nohp" id="simpan_nohp" class="form-control">
            <input type="hidden" name="email" id="simpan_email" class="form-control">
            <input type="hidden" name="ig" id="simpan_ig" class="form-control">
            <input type="hidden" name="tmpl" id="simpan_tmpl" class="form-control">
            <input type="hidden" name="tgll" id="simpan_tgll" class="form-control">
            <input type="hidden" name="jenis_identitas" id="simpan_jenis_identitas" class="form-control">
            <input type="hidden" name="no_identitas" id="simpan_no_identitas" class="form-control">
            <input type="hidden" name="pekerjaan" id="simpan_pekerjaan" class="form-control">
            <input type="hidden" name="total_biaya" id="simpan_total_biaya" class="form-control">
            <!-- <input type="file" name="email" id="simpan_berkas" class="form-control"> -->


               <div class="row form_konfirmasi_member">
                
                 <div class="col-md-7">
                   <table class="table">
                     <tr>
                       <td>Nama</td>
                       <td>:</td>
                       <td id="show_nama"></td>
                     </tr>
                     <tr>
                       <td>No Identitas</td>
                       <td>:</td>
                       <td id="show_identitas"></td>
                     </tr>
                     <tr>
                       <td>Jenis Kelamin</td>
                       <td>:</td>
                       <td  id="show_jk"></td>
                     </tr>
                     <tr>
                       <td>Tempat / Tgl Lahir</td>
                       <td>:</td>
                       <td  id="show_lahir"></td>
                     </tr>
                     <tr>
                       <td>Alamat</td>
                       <td>:</td>
                       <td  id="show_alamat"></td>
                     </tr>
                     <tr>
                       <td>No HP</td>
                       <td>:</td>
                       <td  id="show_nohp"></td>
                     </tr>
                     <tr>
                       <td>Email</td>
                       <td>:</td>
                       <td  id="show_email"></td>
                     </tr>
                     <tr>
                       <td>Pekerjaan</td>
                       <td>:</td>
                       <td  id="show_pekerjaan"></td>
                     </tr>
                     <tr>
                       <td>Instagram</td>
                       <td>:</td>
                       <td  id="show_ig"></td>
                     </tr>
                   </table>
                 </div>
                  <div class="col-md-5">
                    <div class="form-group">
                      <label>Upload Foto</label>
                      <input type="file" name="berkas" id="berkas" accept="image/*" > <br>
                      <img src="" class="show_foto" width="100%">

                    </div>
                 </div>
               </div>
               <div class="row">
                 <div class="col-md-6">
                   <table class="table">
                     <tr  id="show_member_harian">
                       <td>Nama</td>
                       <td>:</td>
                       <td id="nama_member_harian"></td>
                     </tr>
                     <tr>
                       <td>Jenis Member</td>
                       <td>:</td>
                       <td id="show_jenis_member"></td>
                     </tr>
                     <tr class="form_konfirmasi_member">
                       <td>Masa Aktif</td>
                       <td>:</td>
                       <td  id="show_masa_aktif"></td>
                     </tr>
                     <tr class="form_konfirmasi_member">
                       <td>Perkiraan Berakhir</td>
                       <td>:</td>
                       <!-- <td  id="show_perkiraan_berakhir"></td> -->
                       <td>
                        <input type="date" name="simpan_berakhir" id="simpan_berakhir" class="form-control">
                       </td>
                     </tr>
                     <tr  class="form_konfirmasi_member">
                         <td>Biaya Registrasi</td>
                         <td>:</td>
                         <td id="show_biaya_registrasi"></td>
                       </tr>
                       <tr>
                         <td>Biaya Paket</td>
                         <td>:</td>
                         <td  id="show_biaya_paket"></td>
                       </tr>
                   
                   </table>
                 </div>
                 <div class="col-md-6">
                   <table class="table" id="show_konfirmasi_diskon" style="display:none">
                  
                     <tr>
                       <td>Total</td>
                       <td>:</td>
                       <td  id="show_total"></td>
                     </tr>
                     <tr>
                       <td>Diskon</td>
                       <td>:</td>
                       <td  id="show_diskon"></td>
                     </tr>
                     <tr>
                       <td>Nilai Diskon</td>
                       <td>:</td>
                       <td  id="show_nilai_diskon"></td>
                     </tr>
                    
                   </table>
                     <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3 id="show_total_semua"></h3>
                                </div>
                              </div>

                 </div>
               </div>
               <!--  -->
                 <div class="row">
                   
                 <div class="col-md-6">
                   <div class="form-group">
                     <label>Metode Pembayaran</label>
                     <select class="form-control" name="id_pembayaran">
                         <?php 
                         foreach ($metode_pembayaran as $k => $v) { ?>
                              <option value="<?php echo $v['id_metode_pembayaran'] ?>"><?php echo $v['metode_pembayaran'] ?></option>
                            <?php } ?>
                     </select>
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                     <label>Pembayaran</label>
                     <input class="form-control" name="input_dibayar" id="input_dibayar"  onkeypress="return isNumber(event)">

                      <input type="hidden" class="form-control" name="simpan_kembalian_pembayaran" id="simpan_kembalian_pembayaran" value="0" >
                      <input type="hidden" class="form-control" name="simpan_dibayar" id="simpan_dibayar">
                       
                   </div>
                 </div>
                 </div>
                 <div class="row">
                 <div class="col-md-6">
                   <div class="form-group">
                      <div class="small-box bg-gray">
                        <div class="inner">

                          <p>Dibayar</p>
                          <h3 id="show_dibayar"></h3>
                        </div>
                      </div>
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                      <div class="small-box bg-gray">
                        <div class="inner">

                          <p>Kembalian</p>
                          <h3 id="show_kembalian">0</h3>
                        </div>
                      </div>
                   </div>
                 </div>
                 </div>

            <input type="hidden" name="simpan_id_jenis_member" id="simpan_id_jenis_member" class="form-control">
            <!-- <input type="hidden" name="simpan_berakhir" id="simpan_berakhir" class="form-control"> -->
            <input type="hidden" name="simpan_biaya_pendaftaran" id="simpan_biaya_pendaftaran" class="form-control">
            <input type="hidden" name="simpan_id_diskon" id="simpan_id_diskon" class="form-control">
               </div> 
               
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="save_order" onclick="simpan_member()">Simpan</button>
              </div>
            </div>
          </div>
    
</form>
</div>

      



  <div class="modal fade" id="print_order_member">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_member">
              
              </div>
              <div class="modal-footer">
                <a href="<?php echo base_url('user/kassa/member') ?>" class="btn btn-primary" onclick="close_order_member()">Tutup</a>
              </div>
            </div>
          </div>
        </div>



<script>
  
$('#id_jenis_member').change(function(){
  var id_jenis_member = $('#id_jenis_member').val();
  if (id_jenis_member=='') {
    $('#detail_jenis_member').html(``);
    $('#show_list_order_keranjang').html(`<div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada Transaksi</h4>
                                </div>
                              </div>`);
    $('#total_biaya').html('');
    $('#diskon').hide();
    $('#total_belanja').html('');
  }else{
    detail_jenis_member(id_jenis_member);

  }
});

$('#diskon_member').change(function(){
    var id_diskon = $('#diskon_member').val();
    var biaya = $('#total_biaya_register').val();

  if (id_diskon=='') {
    $('#detail_diskon').html('');
    $('#total_pembayaran').html("Rp. "+number_format(biaya));
  }else{

    detail_diskon(id_diskon);
  }
});


// list_order();
function detail_jenis_member(id_jenis_member)
  {
    var y_n = ['Tidak','Ya'];

    var tgl_aktif_terakhir = '<?php echo date('Y-m-d') ?>';
    if (id_jenis_member==1) {
        $('#input_nama').val('Gym Harian');
        
        $('#form_identitas_member_input').attr('hidden','true');
        $('.form_konfirmasi_member').attr('hidden','true');
                $('#show_member_harian').removeAttr('hidden');
        

    }else{
        $('#input_nama').val('');
        $('#show_member_harian').attr('hidden','true');
        $('#nama_member_harian').attr('hidden','true');
        $('#form_identitas_member_input').removeAttr('hidden');
        $('.form_konfirmasi_member').removeAttr('hidden');
   
    }

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_jenis_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_jenis_member : id_jenis_member,
                tgl_aktif_terakhir : tgl_aktif_terakhir,
                
              },
              success : function(data)
              {
                var biaya_register = data.data.wajib_register == 0 ? 0 : 100000;
                var total = parseInt(biaya_register) + parseInt(data.data.biaya);


                $('#detail_jenis_member').html(`

                <table class="table">
                  <tr>
                    <td>Jenis Member</td>
                    <td>:</td>
                    <td id="get_jenis_member">`+data.data.jenis_member+`</td>
                  </tr>
                  <tr>
                    <td>Masa Aktif</td>
                    <td>:</td>
                    <td id="get_masa_aktif">`+data.data.masa_aktif + ` `+ data.data.satuan_masa_aktif+`</td>
                  </tr>
                  <tr>
                    <td>Perkiraan Berakhir</td>
                    <td>:</td>
                    <td id="get_perkiraan_berakhir">`+data.perkiraan_masa_aktif+`</td>
                  </tr>
                  <tr>
                    <td>Biaya</td>
                    <td>:</td>
                    <td>`+number_format(data.data.biaya)+`</td>
                  </tr>
                  <tr>
                    <td>Wajib Registrasi</td>
                    <td>:</td>
                    <td>`+y_n[data.data.wajib_register]+`</td>
                  </tr>
                </table>


                <input type="hidden" id="get_biaya_register" class="form-control" value="`+biaya_register+`">
                <input type="hidden" id="get_biaya_paket" class="form-control" value="`+data.data.biaya+`">
                <input type="hidden" id="get_biaya_semua" class="form-control" value="`+total+`">
                `);


                if (data.data.wajib_register==1) {

                 $('#show_list_order_keranjang').html(`
                    <ul class="list-group list-group-unbordered" id="daftar_item">
                     <li class="list-group-item">
                          <b>Biaya Registrasi</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(biaya_register)+`</b> <br>
                           </span>
                      </li>
                     <li class="list-group-item">
                          <b>Biaya Paket</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(data.data.biaya)+`</b> <br>
                           </span>
                     </li>
                   
                    </ul>

                    `);
                }else{
                 $('#show_list_order_keranjang').html(`
                    <ul class="list-group list-group-unbordered" id="daftar_item">
                    
                     <li class="list-group-item">
                          <b>Biaya Paket</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b id="get_biaya_paket">`+ number_format(data.data.biaya)+`</b> <br>
                           </span>
                     </li>
                    </ul>

                    `);

                }



                 $('#diskon').show();
                  $('#detail_diskon').html('');
                  $('#diskon_member').val('').change();
                 $('#total_biaya').show();
                 $('#total_biaya_register').val(total);
                 $('#total_biaya').html(`
                  <h4 class="pull-left" >Total</h4>
           <h4 class="pull-right" style="color:purple; text-align:right"><b>`+number_format(total)+`</b> <br>
                           </h4>
                           <div class="clearfix"></div>

                           <hr>`);


                  $('#total_belanja').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3 id="total_pembayaran">Rp. `+number_format(total)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()">Konfirmasi Member</button>
        </div>
        </div>

              `);

              },
              error : function(){
                console.log('e');
              }
            });
          }
      
function detail_diskon(id_diskon)
  {
    var biaya_register = $('#total_biaya_register').val();
    console.log(biaya_register);
    var y_n = ['Tidak','Ya'];

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_diskon'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_diskon : id_diskon,
                
              },
              success : function(data)
              {
                if (data.data.jenis =='Persentase') {
                  nilai_diskon = (data.data.besar_diskon / 100) *biaya_register;
                  show_besar_diskon = data.data.besar_diskon+'% [Rp. '+number_format(nilai_diskon)+']';
                }
                else{
                  show_besar_diskon =  "Rp. "+number_format(data.data.besar_diskon);
                  nilai_diskon = data.data.besar_diskon;

                }
                  dibayar = biaya_register - nilai_diskon ; 
                $('#detail_diskon').html(`

                  <tr>
                    <td>Jenis Diskon</td>
                    <td>:</td>
                    <td id="get_jenis_diskon">`+data.data.jenis+`</td>
                  </tr>
                  <tr>
                    <td>Besar Diskon</td>
                    <td >:</td>
                    <td id="get_besar_diskon">`+show_besar_diskon+`</td>
                  </tr>
                  <tr>
                    <td>Total</td>
                    <td>:</td>
                    <td id="get_dibayar">`+number_format(dibayar)+`</td>
                  </tr>

                 `);




                 $('#nilai_besar_diskon').val(nilai_diskon);


                 $('#total_belanja').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3  id="total_pembayaran">Rp. `+number_format(dibayar)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()">Konfirmasi Member</button>






        </div>
        </div>

              `);

                 $('#show_input_simpan_diskon').html(`
                     
            
              `);



              },
              error : function(){
                console.log('e');
              }
            });
          }
      


function klik_konfirmasi(){
    var input_nama = $('#input_nama').val();
    var input_jk = $('#input_jk').val();
    var input_alamat = $('#input_alamat').val();
    var input_nohp = $('#input_nohp').val();
    var input_email = $('#input_email').val();
    var id_jenis_member = $('#id_jenis_member').val();

var nama_member = $('#input_nama').val() ;
$('#nama_member_harian').html(nama_member);

    if (input_nama=='') {

      Swal.fire('Error','Harap masukan nama','error');
    }
    else if (input_jk=='') {
      Swal.fire('Error','Harap masukan jenis kelamin','error');

    }
    else if (id_jenis_member=='') {
      Swal.fire('Error','Harap masukan pilih paket','error');

    }else{
      konfirmasi();

    }
    



}

function konfirmasi()
  {
    $('#konfirmasi_member').modal('show');
    var link_foto = $('#src_foto').val();
    var nama = $('#input_nama').val();
    var jk = $('#input_jk').val();
    var alamat = $('#input_alamat').val();
    var nohp = $('#input_nohp').val();
    var email = $('#input_email').val();

    var ig = $('#input_ig').val();
    var tmpl = $('#input_tmpl').val();
    var tgll = $('#input_tgll').val();
    var blll = $('#input_blll').val();
    var thll = $('#input_thll').val();
    var jenis_identitas = $('#input_jenis_identitas').val();
    var no_identitas = $('#input_no_identitas').val();
    var pekerjaan = $('#input_pekerjaan').val();

    var jenis_member = $('#get_jenis_member').html();
    var masa_aktif = $('#get_masa_aktif').html();
    var perkiraan_berakhir = $('#get_perkiraan_berakhir').html();
    var biaya_register = $('#get_biaya_register').val();
    var biaya_paket = $('#get_biaya_paket').val();
    var biaya_semua = $('#get_biaya_semua').val();
    var id_jenis_diskon = $('#diskon_member').val();
    var jenis_diskon = $('#get_jenis_diskon').html();
    var besar_diskon = $('#get_besar_diskon').html();
    var nilai_besar_diskon = $('#nilai_besar_diskon').val();
    var dibayar = $('#total_pembayaran').html();
    

  var id_jenis_member = $('#id_jenis_member').val();

    if (link_foto=='') {
      $('#konfirmasi_member').find('.show_foto').html(`<img src="<?php echo base_url('assets/gambar/user.webp') ?>" class="show_foto" width="100%">`);

    }else{
      $('#konfirmasi_member').find('.show_foto').html(`<img src="`+link_foto+`" class="show_foto" width="100%">`);

    }

    if (id_jenis_diskon=='') {
        $('#konfirmasi_member').find('#show_konfirmasi_diskon').hide();
    }
      else{
        $('#konfirmasi_member').find('#show_konfirmasi_diskon').show();
      }
    $('#konfirmasi_member').find('#show_nama').html(nama);
    $('#konfirmasi_member').find('#show_jk').html(jk);
    $('#konfirmasi_member').find('#show_alamat').html(alamat);
    $('#konfirmasi_member').find('#show_nohp').html(nohp);
    $('#konfirmasi_member').find('#show_email').html(email);

    $('#konfirmasi_member').find('#show_jenis_member').html(jenis_member);
    $('#konfirmasi_member').find('#show_masa_aktif').html(masa_aktif);
    $('#konfirmasi_member').find('#show_perkiraan_berakhir').html(perkiraan_berakhir);

    $('#konfirmasi_member').find('#show_identitas').html(jenis_identitas +" / "+ no_identitas);
    $('#konfirmasi_member').find('#show_lahir').html(tmpl + '/ '+ thll+'-'+blll+'-'+tgll);
    $('#konfirmasi_member').find('#show_pekerjaan').html(pekerjaan);
    $('#konfirmasi_member').find('#show_ig').html(ig);
    $('#konfirmasi_member').find('#show_biaya_registrasi').html(number_format(biaya_register));
    $('#konfirmasi_member').find('#show_biaya_paket').html(number_format(biaya_paket));
    $('#konfirmasi_member').find('#show_total').html(number_format(biaya_semua));
    $('#simpan_dibayar').val(biaya_semua);
    $('#konfirmasi_member').find('#show_diskon').html(jenis_diskon);
    $('#konfirmasi_member').find('#show_nilai_diskon').html(besar_diskon);
    $('#konfirmasi_member').find('#show_total_semua').html(dibayar);

    $('#konfirmasi_member').find('#simpan_nama').val(nama);
    $('#konfirmasi_member').find('#simpan_jk').val(jk);
    $('#konfirmasi_member').find('#simpan_alamat').val(alamat);
    $('#konfirmasi_member').find('#simpan_nohp').val(nohp);
    $('#konfirmasi_member').find('#simpan_email').val(email);

    $('#konfirmasi_member').find('#simpan_ig').val(ig);
    $('#konfirmasi_member').find('#simpan_tmpl').val(tmpl);
    $('#konfirmasi_member').find('#simpan_tgll').val(thll+'-'+blll+'-'+tgll);

    $('#konfirmasi_member').find('#simpan_jenis_identitas').val(jenis_identitas);
    $('#konfirmasi_member').find('#simpan_no_identitas').val(no_identitas);
    $('#konfirmasi_member').find('#simpan_pekerjaan').val(pekerjaan);
    $('#konfirmasi_member').find('#simpan_total_biaya').val(biaya_semua);


    $('#konfirmasi_member').find('#simpan_id_jenis_member').val(id_jenis_member);
    $('#konfirmasi_member').find('#simpan_berakhir').val(perkiraan_berakhir);
    $('#konfirmasi_member').find('#simpan_biaya_pendaftaran').val(biaya_register);
    $('#konfirmasi_member').find('#simpan_id_diskon').val(id_jenis_diskon);

    if ($('#diskon_member').val()=='') {
      var harus_dibayar = parseInt(biaya_semua);
    }else{
      var harus_dibayar = parseInt(biaya_semua) - parseInt(nilai_besar_diskon);
    }
      $('#konfirmasi_member').find('#show_kembalian').html("Rp. 0");

      $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+number_format(harus_dibayar));
      $('#konfirmasi_member').find('#simpan_dibayar').val(harus_dibayar);
      $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(0);



    $('#konfirmasi_member').find('#input_dibayar').keyup(function(){
      var dibayar_pelanggan = $('#konfirmasi_member').find('#input_dibayar').val();
      var sisa = dibayar_pelanggan - harus_dibayar;

       if (dibayar_pelanggan =='') {
        $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+ number_format(harus_dibayar));
        $('#konfirmasi_member').find('#show_kembalian').html('Rp. 0');
        $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(0);
        $('#konfirmasi_member').find('#simpan_dibayar').val(harus_dibayar);
        }else{

            $('#konfirmasi_member').find('#show_kembalian').html("Rp. "+number_format(sisa));
            $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+number_format(dibayar_pelanggan));
            $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(sisa);
            $('#konfirmasi_member').find('#simpan_dibayar').val(dibayar_pelanggan);
        }




    });

    
          }
      



function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.show_foto').attr('src', e.target.result);
            $('#src_foto').val(e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$("#berkas").change(function(){
    readURL(this);
});

function simpan_member()
  {
     var form = $('#form_pendaftaran_member')[0];

    var form_data = new FormData(form);

    // var form_data = $('#form_pendaftaran_member').serialize();

   
            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/simpan_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : form_data,
              mimeType: "multipart/form-data",
              cache: false,
              contentType: false,
              processData: false,


              success : function(data)
              {
                print_order_member(data.id_transaksi);
                 
              },
              error : function(){
                console.log('error');
              }
            });
          
    }



function print_order_member(id_transaksi)
  {

    $('#konfirmasi_member').modal('hide');
    $('#print_order_member').modal('show');
    $('#print_order_member').find('#struk_order_member').html(`
      <iframe src="`+ baseUrl('user/kassa/member/print_order_member/') + id_transaksi +`/?status_print=settlement&action=Lunas" width="100%" height="400px"></iframe>
      `);
            // $.ajax(
            // {
            //   url     : baseUrl('/user/kassa/member/simpan_transaksi'),
            //   dataType: 'JSON',
            //   type    : 'POST',
            //   data    : { 
            //     jumlah : jumlah,
            //     metode_pembayaran : metode_pembayaran,
            //   },
            //   success : function(data)
            //   {
            //     console.log(data.id_transaksi);
            //    print_order_member(data.id_transaksi);
                 
            //   },
            //   error : function(){
            //     alert('error');
            //   }
            // });


                       $('#total_biaya').html(``);
                       $('#total_belanja').html(``);
                       $('#id_jenis_member').val(``).change();
             $('#show_list_order_keranjang').html(`

                  <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Transaksi Disimpan <br>Belum ada order baru</h4>
                                </div>
                              </div>
              `);
                       $('#input_nama').val(``);
                       $('#input_no_identitas').val(``);
                       $('#input_tmpl').val(``);
                       $('#input_pekerjaan').val(``);
                       $('#input_alamat').val(``);
                       $('#input_nohp').val(``);
                       $('#input_email').val(``);
                       $('#input_ig').val(``);


          }
</script>









