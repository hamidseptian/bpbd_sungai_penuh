 

<form action="<?php echo base_url('user/kassa/member/simpan_perpanjangan_member_gym') ?>" method='post' id="form_pendaftaran_member" enctype="multipart/form-data">  

 <div class="row">
    <div class="col-md-12">
    <?php echo $this->session->flashdata('pesan') ?>
  </div>
  <div class="col-md-12" id="form_identitas_member_input">
        <div class="box">
           <div class="box-header with-border">
          <h3 class="box-title">Identitas Member</h3>
         
        </div>

        <div class="box-body">

            <div class="col-md-4">
           
              <?php if ($member['foto']=='') { 
                $src_foto = base_url('assets/gambar/user.webp');  
                ?>
              <?php }else{ 
                $src_foto = base_url('file/member/'.$member['foto']);  
                ?>

              <?php } ?>
                <img class=" img-responsive " src="<?php echo $src_foto  ?>" alt="User profile picture" width="100%">

                  
          <?php echo $register ?>
          </div>
          <div class="col-md-4">

                  <input type="hidden" id="id_member" name="id_member" class="form-control" value="<?php echo $member['id_member'] ?>">
                  <input type="hidden" id="session_biaya_paket_kelas" name="session_biaya_paket_kelas" class="form-control">
                  <input type="hidden" id="get_biaya_paket_kelas" name="get_biaya_paket_kelas" class="form-control">
                  <input type="hidden" id="id_paket_kelas" name="id_paket_kelas" class="form-control">
                  <input type="hidden" id="nama_paket_kelas" name="nama_paket_kelas" class="form-control">
                  <input type="hidden" id="masa_aktif_kelas" name="masa_aktif_kelas" class="form-control">



                <input type="hidden" id="id_potongan" name="id_potongan" class="form-control">
                <input type="hidden" id="nilai_potongan" name="nilai_potongan" class="form-control">
                <input type="hidden" id="nama_potongan" name="nama_potongan" class="form-control">

             <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" id="input_nama" class="form-control" value="<?php echo $member['nama'] ?>" readonly>
          </div>
          <div >
          <div class="form-group">
            <label>No Identitas</label>
            <input type="text" name="nama" id="input_nama" class="form-control" value="<?php echo $member['jenis_identitas'].' / '.$member['no_identitas'] ?>" readonly>
            
          </div>
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <input type="text" name="jk" id="jk" class="form-control" readonly="" value="<?php echo $member['jk'] ?>" readonly>
          </div>
           <div class="form-group">
            <label>Tempat Lahir</label>
            <input type="text" name="tmpl" id="input_tmpl" class="form-control" value="<?php echo  $member['tmpl'] ?>" readonly>
          </div>
          <div class="form-group">
            <label>Tanggal Lahir</label>
            <input type="text" name="tmpl" id="input_tmpl" class="form-control" value="<?php echo $member['tgll'] ?>" readonly>
            
          </div>





          </div>
        </div>
          <div class="col-md-4">
          <div class="form-group">
            <label>Pekerjaan</label>
            <input type="text" name="pekerjaan" id="input_pekerjaan" class="form-control" readonly value="<?php echo $member['pekerjaan'] ?>">
          </div>

          <div class="form-group">
            <label>Alamat</label>
            <input type="text" name="alamat" id="input_alamat" class="form-control" readonly value="<?php echo $member['alamat'] ?>">
          </div>
          <div class="form-group">
            <label>No HP</label>
            <input type="text" name="nohp" id="input_nohp" class="form-control" readonly value="<?php echo $member['no_hp'] ?>">
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" id="input_email" class="form-control" readonly value="<?php echo $member['email'] ?>">
          </div>
          <div class="form-group">
            <label>Instagram</label>
            <input type="text" name="ig" id="input_ig" class="form-control" readonly value="<?php echo $member['ig'] ?>">
          </div>
         
          </div>
        </div>
    </div>
  </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Transaksi</h3>
        </div>
        <div class="box-body" id="show_list_order_keranjang" style="max-height:500px; overflow-y: scroll">
          <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada Transaksi</h4>
                                </div>
                              </div>
        </div>
        <div class="box-body" id="total_biaya" style="display:none; margin-top:-40px">
         
        </div>
        <input type="hidden" name="" id="total_biaya_register">
     
         





        


      </div>
    
      <div id="show_input_simpan_diskon">
    
      </div>
    </div>

    <div class="col-md-4">

      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Paket Gym</h3>

                <input type="hidden" id="dengan_paket_kelas" name="dengan_paket_kelas" class="form-control">
         
        </div>
        <div class="box-body">
          
          <div class="form-group">
            <label>Paket</label>
            <select name="id_jenis_member" id="id_jenis_member" class="form-control">
              <option value=""></option>
              <?php foreach ($jenis_member as $k => $v) { ?>
                <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group" id="detail_jenis_member">
            
          </div>

        
        </div>


      </div>
    
    </div>
    <div class="col-md-4" id="form_kelas" hidden="true">
        <div class="box">
          <div class="box-header with-border">
            <h3 class="box-title">Kelas</h3>
           
          </div>
          <div class="box-body">
            
            <div class="form-group">
              <label>Pilih Kelas</label>
              <select name="id_kelas" id="id_kelas" class="form-control">
                <option value="">--Pilih Kelas--</option>
                <?php foreach ($kelas as $k => $v) { ?>
                  <option value="<?php echo $v['id_kelas'] ?>"><?php echo $v['kelas'] ?></option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group" id="pilih_detail_kelas">
              
            </div>
            <div class="form-group" id="detail_paket_kelas">
              
            </div>

          
          </div>



        </div>
    </div>

      


    <div class="clearfix"></div>

        <div class="col-md-4"  id="form_total_belanja"></div>
        <div class="col-md-4"  id="form_diskon" hidden="true">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Potongan harga</h3>
             
            </div>
         
        
            <div class="box-body" id="diskon">
              <div class="form-group">
                <label>Jenis Potongan </label>
                <select class="form-control" name="jenis_potongan" id="jenis_potongan">
                    <option value="">Tidak ada potongan</option>
                    <option value="diskon">Diskon</option>
                    <option value="voucher">Voucher</option>
                
                </select>
                
              </div>
              <table class="table" id="tabel_diskon" hidden="true">
                        
                          <tr>
                            <td>Diskon</td>
                            <td>:</td>
                            <td>
                              <select class="form-control" id="diskon_member">
                                <?php 
                                $id_diskon_pertama = 0;
                                foreach ($diskon as $k => $v) { 
                                  if ($k==0) {
                                      $id_diskon_pertama = $v['id_diskon'];
                                    $selected = 'selected';
                                  }else{
                                    $selected = '';
                                  }
                                  ?>
                                  <option value="<?php echo $v['id_diskon'] ?>" ><?php echo $v['nama_diskon'] ?></option>
                                <?php } ?>
                              </select>
                            </td>
                          </tr>
                          <tbody id="detail_diskon">
                            
                        
                          </tbody>
                        
                        </table>


              <table class="table" id="tabel_voucher" hidden="true">
                        
                          <tr>
                            <td>Voucher</td>
                            <td>:</td>
                            <td>
                              <select class="form-control" id="voucher_member">
                                 
                              </select>
                            </td>
                          </tr>
                          <tbody id="detail_voucher">
                            
                        
                          </tbody>
                        
                        </table>
            </div>
              

             





            


          </div>



        </div>
        <div class="col-md-4"  id="form_total_semua"></div>
      </div>



  
<div class="modal fade" id="konfirmasi_member">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Konfirmasi Perpanjangan Member <br>  <span id="show_nama"></span></h4>
              </div>
              <div class="modal-body">
       


               
               <div class="row">
                 <div class="col-md-6">
                   <table class="table">
                     <tr>
                       <td>Jenis Member</td>
                       <td>:</td>
                       <td id="show_jenis_member"></td>
                     </tr>
                     <tr>
                       <td>Masa Aktif</td>
                       <td>:</td>
                       <td  id="show_masa_aktif"></td>
                     </tr>
                     <tr>
                       <td>Perkiraan Berakhir</td>
                       <td>:</td>
                       <td  id="show_perkiraan_berakhir"></td>
                     </tr>
                     <tr>
                         <td>Biaya Registrasi</td>
                         <td>:</td>
                         <td id="show_biaya_registrasi"></td>
                       </tr>
                       <tr>
                         <td>Biaya Paket</td>
                         <td>:</td>
                         <td  id="show_biaya_paket"></td>
                       </tr>
                   
                   </table>
                 </div>
                 <div class="col-md-6">
                   <table class="table">
                  
                     <tr>
                       <td>Dengan Kelas</td>
                       <td>:</td>
                       <td  id="show_dengan_kelas"></td>
                     </tr>
                     <tr class="show_identitas_kelas" hidden="true">
                       <td>Nama paket Kelas</td>
                       <td>:</td>
                       <td  id="show_nama_paket_kelas"></td>
                     </tr>
                     <tr  class="show_identitas_kelas" hidden="true">
                       <td>Biaya</td>
                       <td>:</td>
                       <td  id="show_biaya_kelas"></td>
                     </tr>
                    
                   </table>
                   

                 </div>
               </div>
               <div class="row">
                 <div class="col-md-6">
                   <table class="table" id="show_konfirmasi_diskon" style="display:none">
                  
                     <tr>
                       <td>Total</td>
                       <td>:</td>
                       <td  id="show_total"></td>
                     </tr>
                     <tr>
                       <td>Potongan Harga</td>
                       <td>:</td>
                       <td  class="show_jenis_potongan"></td>
                     </tr>
                     <tr class="detail_potongan_harga">
                       <td class="show_jenis_potongan">Diskon</td>
                       <td>:</td>
                       <td  id="show_nama_potongan"></td>
                     </tr>
                     <tr class="detail_potongan_harga">
                       <td>Nilai Potongan Harga</td>
                       <td>:</td>
                       <td  id="show_nilai_potongan"></td>
                     </tr>
                    
                   </table>
                 </div>
                 <div class="col-md-6">
                     <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3 id="show_total_semua"> ??? </h3>
                                </div>
                              </div>

                 </div>
               </div>
               <!--  -->
                 <div class="row">
                   
                 <div class="col-md-6">
                   <div class="form-group">
                     <label>Metode Pembayaran</label>
                     <select class="form-control" name="id_pembayaran">
                         <?php 
                         foreach ($metode_pembayaran as $k => $v) { ?>
                              <option value="<?php echo $v['id_metode_pembayaran'] ?>"><?php echo $v['metode_pembayaran'] ?></option>
                            <?php } ?>
                     </select>
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                     <label>Pembayaran</label>
                     <input class="form-control" name="input_dibayar" id="input_dibayar"  onkeypress="return isNumber(event)">
                       
                   </div>
                 </div>
                 </div>
                 <div class="row">
                 <div class="col-md-6">
                   <div class="form-group">
                      <div class="small-box bg-gray">
                        <div class="inner">

                          <p>Dibayar</p>
                          <h3 id="show_dibayar"> ??/ x</h3>
                        </div>
                      </div>
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                      <div class="small-box bg-gray">
                        <div class="inner">

                          <p>Kembalian</p>
                          <h3 id="show_kembalian">0</h3>
                        </div>
                      </div>
                   </div>

                     <input class="form-control" name="kembalian_pembayaran" id="kembalian_pembayaran"  type="hidden">
                 </div>
                 </div>

            <input type="hidden" name="simpan_id_jenis_member" id="simpan_id_jenis_member" class="form-control">
            <input type="hidden" name="simpan_biaya_pendaftaran" id="simpan_biaya_pendaftaran" class="form-control">
            <input type="hidden" name="simpan_grand_total" id="simpan_grand_total" class="form-control">

               </div> 
               
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="save_order">Simpan</button>
              </div>
            </div>
          </div>
      

    </form>


  <div class="modal fade" id="print_order_member">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_member">
              
              </div>
              <div class="modal-footer">
                <a href="<?php echo base_url('user/kassa/member') ?>" class="btn btn-primary" onclick="close_order_member()">Tutup</a>
              </div>
            </div>
          </div>
        </div>



<script>
  
$('#jenis_potongan').change(function(){
  var jenis_potongan = $('#jenis_potongan').val();
  if (jenis_potongan=='') {
      $('#tabel_voucher').hide();
      $('#tabel_diskon').hide();
      var total_biaya_semua = $('#get_biaya_semua').val();
      $('#form_total_semua').find('#total_pembayaran').html('Rp. ' + number_format(total_biaya_semua));
   
  }else{
    if (jenis_potongan=='diskon') {
      var id_diskon_pertama = <?php echo $id_diskon_pertama ?>;
      detail_diskon(id_diskon_pertama);
      $('#tabel_diskon').show();
      $('#tabel_voucher').hide();
    }else{

      $('#tabel_diskon').hide();
      $('#tabel_voucher').show();

      var id_jenis_member = $('#id_jenis_member').val();
      pilihan_voucher(id_jenis_member);
    }

  }
});



$('#id_jenis_member').change(function(){
  var id_jenis_member = $('#id_jenis_member').val();
  if (id_jenis_member=='') {
    $('#detail_jenis_member').html(``);
    $('#show_list_order_keranjang').html(`<div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada Transaksi</h4>
                                </div>
                              </div>`);
    $('#total_biaya').html('');
    $('#form_diskon').hide();
    $('#form_kelas').hide();
    $('#form_total_belanja').html('');
    $('#form_total_semua').html('');

        $('#form_identitas_member_input').attr('hidden','true');
  }else{
    detail_jenis_member(id_jenis_member);

  }
});
$('#id_kelas').change(function(){
  var id_kelas = $('#id_kelas').val();
  if (id_kelas=='') {
    $('#detail_kelas').html(``);
    $('#detail_paket_kelas').hide();
    $('#pilih_detail_kelas').html('<span style="color:blue">Anda belum memilih kelas</span>');

      var total_biaya_semua = $('#get_biaya_semua').val();
      $('#form_total_belanja').find('#total_pembayaran').html('Rp. ' + number_format(total_biaya_semua));
      $('#form_total_semua').find('#total_pembayaran').html('Rp. ' + number_format(total_biaya_semua));

      
      
    $('#daftar_item').find('#item_transaksi_kelas').remove();
        $('#total_biaya').html(`
                  <h4 class="pull-left" >Total</h4>
           <h4 class="pull-right" style="color:purple; text-align:right"><b id="total_biaya_semua">`+number_format(total_biaya_semua)+`</b> <br>
                           </h4>
                           <div class="clearfix"></div>

                           <hr>`);
  }else{
    $('#detail_paket_kelas').show();
    detail_kelas(id_kelas);

  }
});

$('#diskon_member').change(function(){
    var id_diskon = $('#diskon_member').val();
    var biaya = $('#total_biaya_register').val();

  if (id_diskon=='') {
    $('#detail_diskon').html('');
    $('#total_pembayaran').html("Rp. " + number_format(biaya));
  }else{

    detail_diskon(id_diskon);
  }
});


// list_order();
function detail_jenis_member(id_jenis_member)
  {
     pilihan_voucher(id_jenis_member);
    var y_n = ['Tidak','Ya'];

    var tgl_aktif_terakhir = '<?php echo $tgl_aktif_terakhir ?>';
    if (id_jenis_member==1 || id_jenis_member=='') {
        // $('#input_nama').val('Gym Harian');
        
        $('#form_identitas_member_input').attr('hidden','true');
        $('.form_konfirmasi_member').attr('hidden','true');
                $('#show_member_harian').removeAttr('hidden');
        

    }else{
        // $('#input_nama').val('');
        $('#show_member_harian').attr('hidden','true');
        $('#nama_member_harian').attr('hidden','true');
        $('#form_identitas_member_input').removeAttr('hidden');
        $('.form_konfirmasi_member').removeAttr('hidden');
   
    }

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_jenis_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_jenis_member : id_jenis_member,
                tgl_aktif_terakhir : tgl_aktif_terakhir,
                
              },
              success : function(data)
              {
                var biaya_register = 0;
                var biaya_kelas = $('#get_biaya_paket_kelas').val();

                if (data.data.wajib_register==1) {

                  if (biaya_kelas=='') {
                    var total = parseInt(biaya_register) + parseInt(data.data.biaya);
                  }else{
                    var total = parseInt(biaya_register) + parseInt(data.data.biaya) + parseInt(biaya_kelas);
                  }
                  var biaya_gym = parseInt(biaya_register) + parseInt(data.data.biaya);

                 $('#show_list_order_keranjang').html(`
                    <ul class="list-group list-group-unbordered" id="daftar_item">
                  
                     <li class="list-group-item">
                          <b>Biaya Paket</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(data.data.biaya)+`</b> <br>
                           </span>
                     </li>
                   
                    </ul>

                    `);

                   var dengan_paket_kelas = $('#dengan_paket_kelas').val();
                   var id_paket_kelas = $('#id_paket_kelas').val()
                   if (dengan_paket_kelas=='') {
                     var dengan_kelas = ` <tr>
                        <td>Tambah paket Kelas</td>
                        <td>:</td>
                        <td> 
                          <a href="javascript:void(0)" onclick="member_with_kelas()" class="btn btn-info btn-xs" id="member_with_kelas"> Ikuti Kelas </a>
                          <a href="javascript:void(0)" onclick="batal_member_with_kelas()" class="btn btn-info btn-xs" style="display:none" id="batal_member_with_kelas"><i class="fa fa-check"></i> Ikuti Kelas </a>
                        </td>
                      </tr>`;

                   }else{
                     var dengan_kelas = ` <tr>
                        <td>Tambah paket Kelas</td>
                        <td>:</td>
                        <td> 
                          <a href="javascript:void(0)" onclick="member_with_kelas()" class="btn btn-info btn-xs" id="member_with_kelas" style="display:none"> Ikuti Kelas </a>
                          <a href="javascript:void(0)" onclick="batal_member_with_kelas()" class="btn btn-info btn-xs" id="batal_member_with_kelas"><i class="fa fa-check"></i> Ikuti Kelas </a>
                        </td>
                      </tr>`;
                      $('#form_kelas').show();
                    if (id_paket_kelas=='') {

                    }else{

                      detail_paket_kelas(id_paket_kelas);
                    }

                   }




                }
                else{

                  var biaya_gym = parseInt(biaya_register) + parseInt(data.data.biaya);
                  var total = parseInt(biaya_register) + parseInt(data.data.biaya);
              



                 $('#show_list_order_keranjang').html(`
                    <ul class="list-group list-group-unbordered" id="daftar_item">
                    
                     <li class="list-group-item">
                          <b>Biaya Paket</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b id="">`+ number_format(data.data.biaya)+`</b> <br>
                           </span>
                     </li>
                    </ul>

                    `);
                    // $('#form_total_semua').find('#total_pembayaran').html('Rp. ' + number_format(data.data.biaya));





                 var dengan_kelas = ``;
                 $('#form_kelas').hide();

                }



                $('#detail_jenis_member').html(`

                <table class="table">
                  <tr>
                    <td>Jenis Member</td>
                    <td>:</td>
                    <td id="get_jenis_member">`+data.data.jenis_member+`</td>
                  </tr>
                  <tr>
                    <td>Masa Aktif</td>
                    <td>:</td>
                    <td id="get_masa_aktif">`+data.data.masa_aktif + ` `+ data.data.satuan_masa_aktif+`</td>
                  </tr>
                  <tr>
                    <td>Perkiraan Berakhir</td>
                    <td>:</td>
                    <td id="get_perkiraan_berakhir">`+data.perkiraan_masa_aktif+`</td>
                  </tr>
                  <tr>
                    <td>Biaya</td>
                    <td>:</td>
                    <td>`+number_format(data.data.biaya)+`</td>
                  </tr>
                  <tr>
                    <td>Wajib Registrasi</td>
                    <td>:</td>
                    <td>`+y_n[data.data.wajib_register]+`</td>
                  </tr>
                  `+dengan_kelas+`
                </table>
               

                <input type="hidden" id="get_biaya_register" class="form-control" value="`+biaya_register+`">
                <input type="hidden" id="get_biaya_paket" class="form-control" value="`+data.data.biaya+`">
                <input type="hidden" name="get_biaya_semua" id="get_biaya_semua" class="form-control" value="`+total+`">
                <input type="hidden" name="berakhir_gym" id="berakhir_gym" class="form-control" value="`+data.perkiraan_masa_aktif+`">
                `);


              
                 $('#simpan_id_jenis_member').val(id_jenis_member);

                 $('#form_diskon').show();
                 $('#total_biaya').show();
                 $('#total_biaya_register').val(biaya_gym);
                 $('#simpan_biaya_pendaftaran').val(biaya_register);
                 $('#total_biaya').html(`
                  <h4 class="pull-left" >Total</h4>
           <h4 class="pull-right" style="color:purple; text-align:right"><b id="total_biaya_semua">`+number_format(total)+`</b> <br>
                           </h4>
                           <div class="clearfix"></div>

                           <hr>`);


                  $('#form_total_belanja').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Sub Total</p>
                                  <h3 id="total_pembayaran">Rp. `+number_format(total)+`</h3>
                                </div>
                              </div>
        </div>
        </div>

              `);
                  $('#form_total_semua').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Grand Total</p>
                                  <h3 id="total_pembayaran">Rp. `+number_format(total)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()" type="button">Konfirmasi Member</button>
        </div>
        </div>

              `);


                  var jenis_potongan = $('#jenis_potongan').val();
                  if (jenis_potongan=='diskon') {
                    var id_diskon_terpilih = $('#diskon_member').val();
                    detail_diskon(id_diskon_terpilih);
                  }else if(jenis_potongan=='voucher'){
                    var id_voucher_terpilih = $('#voucher_member').val();
                    detail_voucher(id_voucher_terpilih);

                  }

              },
              error : function(){
                console.log('e');
              }
            });




          }
 

//  $('.member_with_kelas').click(function(){
//   alert(32);
 
// });

 
function member_with_kelas(){
  $('#member_with_kelas').hide();
  $('#batal_member_with_kelas').show();
  $('#form_kelas').show();
  var id_paket_kelas_terpilih = $('#id_paket_kelas').val();
  var session_biaya_paket_kelas = $('#session_biaya_paket_kelas').val();
  $('#dengan_paket_kelas').val(1);
  detail_paket_kelas(id_paket_kelas_terpilih);

  $('#get_biaya_paket_kelas').val(session_biaya_paket_kelas);

}

 
function batal_member_with_kelas(){
  $('#dengan_paket_kelas').val('');
  $('#form_kelas').hide();
  $('#member_with_kelas').show();
  $('#batal_member_with_kelas').hide();
  $('#daftar_item').find('#item_transaksi_kelas').remove();

                  var total_biaya_member = $('#total_biaya_register').val();
                // var total_biaya_kelas = data.data.biaya;
                var total_biaya_semua = parseInt(total_biaya_member) ;//+ parseInt(total_biaya_kelas);

                $('#get_biaya_semua').val(total_biaya_semua);
                $('#total_biaya_semua').html(number_format(total_biaya_semua));
                $('#form_total_belanja').find('#total_pembayaran').html('Rp. '+number_format(total_biaya_semua));
                $('#form_total_semua').find('#total_pembayaran').html('Rp. '+number_format(total_biaya_semua));


    $('#get_biaya_paket_kelas').val('');
  // alert(nilai);

}


function detail_kelas(id_kelas)
  {

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/pilihan_detail_kelas'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_kelas : id_kelas,
                
              },
              success : function(data)
              {
               
                $('#pilih_detail_kelas').html(`
                    <div class="form-group">
            <label>Pilih Paket Kelas</label>
            <select name="id_detail_kelas" id="id_detail_kelas" class="form-control">
          `);

                $.each(data.data, function(k,v){
                   $('#id_detail_kelas').append(`
                      <option value="`+v.id_detail_kelas+`">`+v.nama_paket_kelas+` [`+v.banyak_pertemuan+` kali pertemuan]</option>
                    `);
                   if (k==0) {
                        detail_paket_kelas(v.id_detail_kelas);

                   }
                // console.log(v);
                })

                $('#pilih_detail_kelas').append(`
                   
            </select>
          </div>
          `);





$('#id_detail_kelas').change(function(){
    var id_detail_kelas = $('#id_detail_kelas').val();
   

  if (id_detail_kelas=='') {
    $('#detail_diskon').html('');
   
  }else{

    detail_paket_kelas(id_detail_kelas)
  }
});




              },
              error : function(){
                console.log('e');
              }
            });
          }
   

function pilihan_voucher(id_jenis_member)
  {

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/pilihan_voucher_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_jenis_member : id_jenis_member,
                
              },
              success : function(data)
              {
               
                $('#voucher_member').html(`
                   
          `);
                var jenis_potongan = $('#jenis_potongan').val();
                $.each(data.data, function(k,v){
                   $('#voucher_member').append(`
                      <option value="`+v.id_voucher+`">`+v.nama_voucher+`</option>
                    `);
                   if (k==0) {
                        if (jenis_potongan=='voucher') {
                          detail_voucher(v.id_voucher);
                        }

                   }
                // console.log(v);
                })

              





$('#voucher_member').change(function(){
    var voucher_member = $('#voucher_member').val();
   

  if (voucher_member=='') {
    $('#detail_diskon').html('');
   
  }else{

    detail_voucher(voucher_member);
  }
});




              },
              error : function(){
                console.log('e');
              }
            });
          }
   
function detail_paket_kelas(id_detail_kelas)
  {

    var tgl_aktif_terakhir = '<?php echo $tgl_aktif_terakhir ?>';
            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_paket_kelas'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_detail_kelas : id_detail_kelas,
                tgl_aktif_terakhir : tgl_aktif_terakhir,
                // id_detail_kelas : id_detail_kelas,
                
              },
              success : function(data)
              {
                var id_jenis_member = $('#id_jenis_member').val();
               
                $('#detail_paket_kelas').html(`
                   


                <table class="table">
                  <tr>
                    <td>Kelas</td>
                    <td>:</td>
                    <td id="get_kelas">`+data.data.kelas+`</td>
                  </tr>
                  <tr>
                    <td>Paket Kelas</td>
                    <td>:</td>
                    <td id="get_paket_kelas">`+data.data.nama_paket_kelas+`</td>
                  </tr>
                  <tr>
                    <td>Banyak pertemuan</td>
                    <td>:</td>
                    <td id="get_banyak_pertemuan">`+data.data.banyak_pertemuan+` Kali Pertemuan</td>
                  </tr>
                
                  <tr>
                    <td>Masa Berlaku</td>
                    <td>:</td>
                    <td id="get_masa_aktif"> ` +data.data.masa_aktif+ ` `+ data.data.satuan_masa_aktif+` <br>Berakhir pada : `+data.perkiraan_masa_aktif+ ` </td>
                  </tr>
                  <tr>
                    <td>Biaya</td>
                    <td>:</td>
                    <td>`+number_format(data.data.biaya)+`</td>
                  </tr>
                
                </table>
               

          `);

              if (id_jenis_member!=1) {
                
                $('#daftar_item').find('#item_transaksi_kelas').remove();
                $('#daftar_item').append(`
                   <li class="list-group-item" id="item_transaksi_kelas">
                            <b>Kelas `+ data.data.kelas+` <br>Paket `+ data.data.nama_paket_kelas+`</b> 
                             <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(data.data.biaya)+`</b> <br>
                             </span>
                        </li>
                        `);

                var total_biaya_member = $('#total_biaya_register').val();
                var total_biaya_kelas = data.data.biaya;
                var total_biaya_semua = parseInt(total_biaya_member) + parseInt(total_biaya_kelas);
                $('#total_biaya_semua').html(number_format(total_biaya_semua));
                $('#total_pembayaran').html('Rp. '+number_format(total_biaya_semua));

              $('#form_total_semua').find('#total_pembayaran').html('Rp. ' + number_format(total_biaya_semua));


                $('#session_biaya_paket_kelas').val(total_biaya_kelas);
                $('#get_biaya_paket_kelas').val(total_biaya_kelas);
                $('#id_paket_kelas').val(id_detail_kelas);
                $('#masa_aktif_kelas').val(data.perkiraan_masa_aktif);
                $('#nama_paket_kelas').val(`Kelas `+ data.data.kelas+` [Paket `+ data.data.nama_paket_kelas+ `]`);
                $('#get_biaya_semua').val(total_biaya_semua);


                  var jenis_potongan = $('#jenis_potongan').val();
                  if (jenis_potongan=='diskon') {
                    var id_diskon_terpilih = $('#diskon_member').val();
                    detail_diskon(id_diskon_terpilih);
                  }else if(jenis_potongan=='voucher'){
                    var id_voucher_terpilih = $('#voucher_member').val();
                    detail_voucher(id_voucher_terpilih);

                  }


              }

              },
              error : function(){
                console.log('e');
              }
            });
          }
      
function detail_diskon(id_diskon)
  {
    var biaya_register = $('#total_biaya_register').val();
    var get_biaya_paket = $('#get_biaya_paket').val();
    var total_biaya_semua = $('#get_biaya_semua').val();

    var y_n = ['Tidak','Ya'];

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_diskon'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_diskon : id_diskon,
                
              },
              success : function(data)
              {
                if (data.data.jenis =='Persentase') {
                  nilai_diskon = (data.data.besar_diskon / 100) *biaya_register;
                  show_besar_diskon = data.data.besar_diskon+'% [Rp. '+number_format(nilai_diskon)+']';
                }
                else{
                  show_besar_diskon =  "Rp. "+number_format(data.data.besar_diskon);
                  nilai_diskon = data.data.besar_diskon;

                }

                  if (biaya_kelas=='') {
                    dibayar = total_biaya_semua - nilai_diskon; 

                  }else{
                    var biaya_kelas = $('#get_biaya_paket_kelas').val();
                    dibayar = (total_biaya_semua - nilai_diskon); 
                  }
                $('#detail_diskon').html(`

                  <tr>
                    <td>Jenis Diskon</td>
                    <td>:</td>
                    <td id="get_jenis_diskon">`+data.data.jenis+`</td>
                  </tr>
                  <tr>
                    <td>Besar Diskon</td>
                    <td >:</td>
                    <td id="get_besar_diskon">`+show_besar_diskon+`</td>
                  </tr>
                  <tr>
                    <td>Total</td>
                    <td>:</td>
                    <td id="get_dibayar">`+number_format(dibayar)+`</td>
                  </tr>

                 `);




                 $('#id_potongan').val(id_diskon);
                 $('#nilai_potongan').val(nilai_diskon);
                 $('#nama_potongan').val(data.data.nama_diskon);
                 $('#simpan_grand_total').val(dibayar);


                 $('#form_total_semua').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Grand Total</p>
                                  <h3  id="total_pembayaran">Rp. `+number_format(dibayar)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()" type="button">Konfirmasi Member</button>






        </div>
        </div>

              `);

              


              },
              error : function(){
                console.log('e');
              }
            });
          }
function detail_voucher(id_voucher)
  {
    var biaya_semua = $('#get_biaya_semua').val();
    var y_n = ['Tidak','Ya'];

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_voucher'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_voucher : id_voucher,
                
              },
              success : function(data)
              {
                if (data.data.jenis =='Persentase') {
                  nilai_voucher = (data.data.besar_voucher / 100) *biaya_semua;
                  show_besar_voucher = data.data.besar_voucher+'% [Rp. '+number_format(nilai_voucher)+']';
                }
                else{
                  show_besar_voucher =  "Rp. "+number_format(data.data.besar_voucher);
                  nilai_voucher = data.data.besar_voucher;

                }
                  dibayar = biaya_semua - nilai_voucher ; 
                $('#detail_voucher').html(`

                  <tr>
                    <td>Jenis Potongan Harga</td>
                    <td>:</td>
                    <td id="get_jenis_diskon">`+data.data.jenis+`</td>
                  </tr>
                  <tr>
                    <td>Besar Diskon</td>
                    <td >:</td>
                    <td id="get_besar_diskon">`+show_besar_voucher+`</td>
                  </tr>
                  <tr>
                    <td>Total</td>
                    <td>:</td>
                    <td id="get_dibayar">`+number_format(dibayar)+`</td>
                  </tr>

                 `);





                 $('#id_potongan').val(id_voucher);
                 $('#nilai_potongan').val(nilai_voucher);
                 $('#nama_potongan').val(data.data.nama_voucher);
                 $('#simpan_grand_total').val(dibayar);


                 $('#form_total_semua').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Grand Total</p>
                                  <h3  id="total_pembayaran">Rp. `+number_format(dibayar)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()" type="button">Konfirmasi Member</button>






        </div>
        </div>

              `);

                 $('#show_input_simpan_diskon').html(`
                     
            
              `);



              },
              error : function(){
                console.log('e');
              }
            });
          }
      


function klik_konfirmasi(){
    var input_nama = $('#input_nama').val();
    var input_jk = $('#input_jk').val();
    var input_alamat = $('#input_alamat').val();
    var input_nohp = $('#input_nohp').val();
    var input_email = $('#input_email').val();
    var id_jenis_member = $('#id_jenis_member').val();

var nama_member = $('#input_nama').val() ;
$('#nama_member_harian').html(nama_member);

    if (id_jenis_member=='') {
      Swal.fire('Error','Harap masukan pilih paket','error');

    }else{
      konfirmasi();

    }
    



}

function konfirmasi()
  {
    $('#konfirmasi_member').modal('show');
    var link_foto = $('#src_foto').val();
    var nama = $('#input_nama').val();
    var jk = $('#input_jk').val();
    var alamat = $('#input_alamat').val();
    var nohp = $('#input_nohp').val();
    var email = $('#input_email').val();

    var ig = $('#input_ig').val();
    var tmpl = $('#input_tmpl').val();
    var tgll = $('#input_tgll').val();
    var blll = $('#input_blll').val();
    var thll = $('#input_thll').val();
    var jenis_identitas = $('#input_jenis_identitas').val();
    var no_identitas = $('#input_no_identitas').val();
    var pekerjaan = $('#input_pekerjaan').val();

    var jenis_member = $('#get_jenis_member').html();
    var masa_aktif = $('#get_masa_aktif').html();
    var perkiraan_berakhir = $('#get_perkiraan_berakhir').html();
    var biaya_register = $('#get_biaya_register').val();
    var biaya_paket = $('#get_biaya_paket').val();
    var biaya_semua = $('#get_biaya_semua').val();
    var id_jenis_diskon = $('#diskon_member').val();
    var jenis_diskon = $('#get_jenis_diskon').html();
    var besar_diskon = $('#get_besar_diskon').html();
    var nilai_besar_diskon = $('#nilai_besar_diskon').val();
    var dibayar = $('#total_pembayaran').html();
    


    var dengan_kelas = $('#dengan_paket_kelas').val() == 1 ? 'Ya' : 'Tidak';
    var nama_paket_kelas = $('#nama_paket_kelas').val();
    var biaya_kelas = $('#get_biaya_paket_kelas').val();

  var id_jenis_member = $('#id_jenis_member').val();

    if (link_foto=='') {
      $('#konfirmasi_member').find('.show_foto').html(`<img src="<?php echo base_url('assets/gambar/user.webp') ?>" class="show_foto" width="100%">`);

    }else{
      $('#konfirmasi_member').find('.show_foto').html(`<img src="`+link_foto+`" class="show_foto" width="100%">`);

    }

    if (id_jenis_diskon=='') {
        $('#konfirmasi_member').find('#show_konfirmasi_diskon').hide();
    }
      else{
        $('#konfirmasi_member').find('#show_konfirmasi_diskon').show();
      }
    $('#konfirmasi_member').find('#show_nama').html(nama);
    $('#konfirmasi_member').find('#show_jk').html(jk);
    $('#konfirmasi_member').find('#show_alamat').html(alamat);
    $('#konfirmasi_member').find('#show_nohp').html(nohp);
    $('#konfirmasi_member').find('#show_email').html(email);

    $('#konfirmasi_member').find('#show_jenis_member').html(jenis_member);
    $('#konfirmasi_member').find('#show_masa_aktif').html(masa_aktif);
    $('#konfirmasi_member').find('#show_perkiraan_berakhir').html(perkiraan_berakhir);

    $('#konfirmasi_member').find('#show_identitas').html(jenis_identitas +" / "+ no_identitas);
    $('#konfirmasi_member').find('#show_lahir').html(tmpl + '/ '+ thll+'-'+blll+'-'+tgll);
    $('#konfirmasi_member').find('#show_pekerjaan').html(pekerjaan);
    $('#konfirmasi_member').find('#show_ig').html(ig);
    $('#konfirmasi_member').find('#show_biaya_registrasi').html(number_format(biaya_register));
    $('#konfirmasi_member').find('#show_biaya_paket').html(number_format(biaya_paket));

    if ($('#dengan_paket_kelas').val()==1) {
    $('#konfirmasi_member').find('.show_identitas_kelas').removeAttr('hidden');

    }else{
    $('#konfirmasi_member').find('.show_identitas_kelas').attr('hidden','true');

    }

    $('#konfirmasi_member').find('#show_dengan_kelas').html(dengan_kelas);
    $('#konfirmasi_member').find('#show_nama_paket_kelas').html(nama_paket_kelas);
    $('#konfirmasi_member').find('#show_biaya_kelas').html(number_format(biaya_kelas));







    var potongan_harga = $('#jenis_potongan').val();
    var id_potongan = $('#id_potongan').val();
    var nilai_potongan = $('#nilai_potongan').val();
    var nama_potongan = $('#nama_potongan').val();
    if (potongan_harga=='') {

      var harus_dibayar = parseInt(biaya_semua);
      jenis_potongan = 'Tidak ada';
    $('#konfirmasi_member').find('.detail_potongan_harga').attr('hidden','true');

    }else{
      $('#konfirmasi_member').find('.detail_potongan_harga').removeAttr('hidden');

      var harus_dibayar = parseInt(biaya_semua) - parseInt(nilai_potongan);
      jenis_potongan = potongan_harga == 'voucher' ? 'Voucher' : 'Diskon';
    }

    $('#konfirmasi_member').find('#show_nilai_potongan').html(number_format(nilai_potongan));


    $('#konfirmasi_member').find('#show_total').html(number_format(biaya_semua));
    $('#konfirmasi_member').find('.show_jenis_potongan').html(jenis_potongan);
    $('#konfirmasi_member').find('#show_nama_potongan').html(nama_potongan);


    $('#konfirmasi_member').find('#show_total_semua').html(number_format(harus_dibayar));
      $('#konfirmasi_member').find('#show_kembalian').html("Rp. 0");

      $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+number_format(harus_dibayar));
      $('#konfirmasi_member').find('#simpan_dibayar').val(harus_dibayar);
      $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(0);



    $('#konfirmasi_member').find('#input_dibayar').keyup(function(){
      var dibayar_pelanggan = $('#konfirmasi_member').find('#input_dibayar').val();
      var sisa = dibayar_pelanggan - harus_dibayar;

       if (dibayar_pelanggan =='') {
        $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+ number_format(harus_dibayar));
        $('#konfirmasi_member').find('#show_kembalian').html('Rp. 0');
        $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(0);
        $('#konfirmasi_member').find('#kembalian_pembayaran').val(0);
        $('#konfirmasi_member').find('#simpan_dibayar').val(harus_dibayar);
        }else{

            $('#konfirmasi_member').find('#show_kembalian').html("Rp. "+number_format(sisa));
            $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+number_format(dibayar_pelanggan));
            $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(sisa);
            $('#konfirmasi_member').find('#kembalian_pembayaran').val(sisa);
            $('#konfirmasi_member').find('#simpan_dibayar').val(dibayar_pelanggan);
        }




    });

    
          }
      



function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.show_foto').attr('src', e.target.result);
            $('#src_foto').val(e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$("#berkas").change(function(){
    readURL(this);
});

function simpan_member()
  {
     var form = $('#form_pendaftaran_member')[0];

    var form_data = new FormData(form);

    // var form_data = $('#form_pendaftaran_member').serialize();

   
            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/simpan_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : form_data,
              mimeType: "multipart/form-data",
              cache: false,
              contentType: false,
              processData: false,


              success : function(data)
              {
                print_order_member(data.id_transaksi);
                 
              },
              error : function(){
                console.log('error');
              }
            });
          
    }



function print_order_member(id_transaksi)
  {

    $('#konfirmasi_member').modal('hide');
    $('#print_order_member').modal('show');
    $('#print_order_member').find('#struk_order_member').html(`
      <iframe src="`+ baseUrl('user/kassa/member/print_order_member/') + id_transaksi +`/?status_print=settlement&action=Lunas" width="100%" height="400px"></iframe>
      `);
            // $.ajax(
            // {
            //   url     : baseUrl('/user/kassa/member/simpan_transaksi'),
            //   dataType: 'JSON',
            //   type    : 'POST',
            //   data    : { 
            //     jumlah : jumlah,
            //     metode_pembayaran : metode_pembayaran,
            //   },
            //   success : function(data)
            //   {
            //     console.log(data.id_transaksi);
            //    print_order_member(data.id_transaksi);
                 
            //   },
            //   error : function(){
            //     alert('error');
            //   }
            // });


                       $('#total_biaya').html(``);
                       $('#form_total_belanja').html(``);
                       $('#id_jenis_member').val(``).change();
             $('#show_list_order_keranjang').html(`

                  <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Transaksi Disimpan <br>Belum ada order baru</h4>
                                </div>
                              </div>
              `);
                       // $('#input_nama').val(``);
                       $('#input_no_identitas').val(``);
                       $('#input_tmpl').val(``);
                       $('#input_pekerjaan').val(``);
                       $('#input_alamat').val(``);
                       $('#input_nohp').val(``);
                       $('#input_email').val(``);
                       $('#input_ig').val(``);


          }
</script>









