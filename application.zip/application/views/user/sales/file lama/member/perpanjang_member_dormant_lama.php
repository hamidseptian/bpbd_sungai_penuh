 


 <div class="row">
    <div class="col-md-12">
    <?php echo $this->session->flashdata('pesan') ?>
  </div>
    <div class="col-md-4">
       
          <div class="box box-primary">
            <div class="box-body box-profile">
              <?php if ($member['foto']=='') { 
                $src_foto = base_url('assets/gambar/user.webp');  
                ?>
              <?php }else{ 
                $src_foto = base_url('file/member/'.$member['foto']);  
                ?>

              <?php } ?>

                <img class=" img-responsive " src="<?php echo $src_foto  ?>" alt="User profile picture" width="100%">
              <h3 class="profile-username text-center"><?php echo $member['nama'] ?></h3>

                <?php echo $register ?>
              <hr>
                <strong>No Identitas</strong>
              <p class="text-muted">
               <?php echo $member['jenis_identitas'].' / '.$member['no_identitas'] ?>
              </p>
               <strong>Nama</strong>
              <p class="text-muted">
               <?php echo $member['nama'] ?>
              </p>
               <strong>Jenis kelamin</strong>
              <p class="text-muted">
               <?php echo $member['jk'] ?>
              </p>
                <strong>Tempat / Tgl Lahir</strong>
              <p class="text-muted">
               <?php echo $member['tmpl'].' / '.$member['tgll'] ?>
              </p>
               <strong>Alamat</strong>
              <p class="text-muted">
               <?php echo $member['alamat'] ?>
              </p>
               <strong>No HP</strong>
              <p class="text-muted">
               <?php echo $member['no_hp'] ?>
              </p>
                <strong>Pekerjaan</strong>
              <p class="text-muted">
               <?php echo $member['pekerjaan'] ?>
              </p>
               <strong>Email</strong>
              <p class="text-muted">
               <?php echo $member['email'] ?>
              </p>
             
               <strong>Instagram</strong>
              <p class="text-muted">
               <?php echo $member['ig'] ?>
              </p>
             
             



            </div>
            
          </div>
    </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Paket Gym</h3>
         
        </div>
        <div class="box-body">
          
          <div class="form-group">
            <label>Paket</label>
            <select name="id_jenis_member" id="id_jenis_member" class="form-control">
              <option value=""></option>
              <?php foreach ($jenis_member as $k => $v) { ?>
                <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group" id="detail_jenis_member">
            
          </div>

        
        </div>


      </div>
    </div>
    <div class="col-md-4">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Transaksi</h3>
         
        </div>
        <div class="box-body" id="show_list_order_keranjang" style="max-height:500px; overflow-y: scroll">
          <div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada Transaksi</h4>
                                </div>
                              </div>
        </div>
        <div class="box-body" id="total_biaya" style="display:none; margin-top:-40px">
         
        </div>
        <input type="hidden" name="" id="total_biaya_register">
        <div class="box-body" id="diskon" style="display:none; margin-top:-20px">
          <table class="table">
                      <tr>
                        <td>Berikan Diskon</td>
                        <td>:</td>
                        <td>
                          <select class="form-control" id="diskon_member">
                              <option value="">Tanpa Diskon</option>
                            <?php foreach ($diskon as $k => $v) { ?>
                              <option value="<?php echo $v['id_diskon'] ?>"><?php echo $v['nama_diskon'] ?></option>
                            <?php } ?>
                          </select>
                        </td>
                      </tr>
                      <tbody id="detail_diskon">
                        
                    
                      </tbody>
                   
                    </table>


                  <input type="hidden" id="nilai_besar_diskon" value="0">
        </div>
          

         





        


      </div>
      <div id="total_belanja">
    
      </div>
      <div id="show_input_simpan_diskon">
    
      </div>
    </div>
  </div>


  <div class="modal fade" id="konfirmasi_member">
    <form action="<?php echo base_url('user/kassa/member/simpan_perpanjang_member') ?>" method='post' id="form_pendaftaran_member" enctype="multipart/form-data">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Konfirmasi</h4>
              </div>
              <div class="modal-body">
            <input type="hidden" name="nama" id="simpan_nama" class="form-control">
            <input type="hidden" name="jk" id="simpan_jk" class="form-control">
            <input type="hidden" name="alamat" id="simpan_alamat" class="form-control">
            <input type="hidden" name="nohp" id="simpan_nohp" class="form-control">
            <input type="hidden" name="email" id="simpan_email" class="form-control">
            <!-- <input type="file" name="email" id="simpan_berkas" class="form-control"> -->


               <div class="row">
                
                 
                 <div class="col-md-6">
                   <table class="table">
                     <tr>
                       <td>Jenis Member</td>
                       <td>:</td>
                       <td id="show_jenis_member"></td>
                     </tr>
                     <tr>
                       <td>Masa Aktif</td>
                       <td>:</td>
                       <td  id="show_masa_aktif"></td>
                     </tr>
                     <tr>
                       <td>Perkiraan Berakhir</td>
                       <td>:</td>
                       <td  id="show_perkiraan_berakhir"></td>
                     </tr>
                     <tr>
                         <td>Biaya Registrasi</td>
                         <td>:</td>
                         <td id="show_biaya_registrasi"></td>
                       </tr>
                       <tr>
                         <td>Biaya Paket</td>
                         <td>:</td>
                         <td  id="show_biaya_paket"></td>
                       </tr>
                   
                   </table>
                 </div>
                 <div class="col-md-6">
                   <table class="table" id="show_konfirmasi_diskon" style="display:none">
                  
                     <tr>
                       <td>Total</td>
                       <td>:</td>
                       <td  id="show_total"></td>
                     </tr>
                     <tr>
                       <td>Diskon</td>
                       <td>:</td>
                       <td  id="show_diskon"></td>
                     </tr>
                     <tr>
                       <td>Nilai Diskon</td>
                       <td>:</td>
                       <td  id="show_nilai_diskon"></td>
                     </tr>
                    
                   </table>
                     <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3 id="show_total_semua"></h3>
                                </div>
                              </div>

                 </div>
               </div>
                 
                 <div class="row">
                   
                 <div class="col-md-6">
                   <div class="form-group">
                     <label>Metode Pembayaran</label>
                     <select class="form-control" name="id_pembayaran">
                         <?php 
                         foreach ($metode_pembayaran as $k => $v) { ?>
                              <option value="<?php echo $v['id_metode_pembayaran'] ?>"><?php echo $v['metode_pembayaran'] ?></option>
                            <?php } ?>
                     </select>
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                     <label>Pembayaran</label>
                     <input class="form-control" name="input_dibayar" id="input_dibayar"  onkeypress="return isNumber(event)">

                      <input type="hidden" class="form-control" name="simpan_kembalian_pembayaran" id="simpan_kembalian_pembayaran" value="0" >
                      <input type="hidden" class="form-control" name="simpan_dibayar" id="simpan_dibayar">
                      <input type="hidden" class="form-control" name="simpan_total" id="simpan_total">
                       
                   </div>
                 </div>
                 </div>
                 <div class="row">
                 <div class="col-md-6">
                   <div class="form-group">
                      <div class="small-box bg-gray">
                        <div class="inner">

                          <p>Dibayar</p>
                          <h3 id="show_dibayar"></h3>
                        </div>
                      </div>
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                      <div class="small-box bg-gray">
                        <div class="inner">

                          <p>Kembalian</p>
                          <h3 id="show_kembalian">0</h3>
                        </div>
                      </div>
                   </div>
                 </div>
                 </div>

            <input type="hidden" name="simpan_id_member" id="simpan_id_member" class="form-control" value="<?php echo $id_member ?>">
            <input type="hidden" name="simpan_id_jenis_member" id="simpan_id_jenis_member" class="form-control">
            <input type="hidden" name="simpan_berakhir" id="simpan_berakhir" class="form-control">
            <input type="hidden" name="simpan_biaya_pendaftaran" id="simpan_biaya_pendaftaran" class="form-control">
            <input type="hidden" name="simpan_id_diskon" id="simpan_id_diskon" class="form-control">
               </div> 
               
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="save_order">Simpan</button>
              </div>
            </div>
          </div>
    </form>
        </div>





<script>
  
$('#id_jenis_member').change(function(){
  var id_jenis_member = $('#id_jenis_member').val();
  if (id_jenis_member=='') {
    $('#detail_jenis_member').html(``);
    $('#show_list_order_keranjang').html(`<div class="small-box bg-gray">
                                <div class="inner">

                                  <h4>Belum ada Transaksi</h4>
                                </div>
                              </div>`);
    $('#total_biaya').html('');
    $('#diskon').hide();
    $('#total_belanja').html('');
  }else{
    detail_jenis_member(id_jenis_member);

  }
});

$('#diskon_member').change(function(){
    var id_diskon = $('#diskon_member').val();
    var biaya = $('#total_biaya_register').val();

  if (id_diskon=='') {
    $('#detail_diskon').html('');
    $('#total_pembayaran').html("Rp. "+number_format(biaya));
  }else{

    detail_diskon(id_diskon);
  }
});


// list_order();
function detail_jenis_member(id_jenis_member)
  {
    var y_n = ['Tidak','Ya'];
    var terdaftar = '<?php echo $terdaftar ?>';
    var tgl_aktif_terakhir = '<?php echo $tgl_aktif_terakhir ?>';
            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_jenis_member'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_jenis_member : id_jenis_member,
                tgl_aktif_terakhir : tgl_aktif_terakhir,
                
              },
              success : function(data)
              {
                
                var biaya_register = data.data.wajib_register == 0 ? 0 : 100000;
                var total = parseInt(biaya_register) + parseInt(data.data.biaya);

                $('#detail_jenis_member').html(`

                <table class="table">
                  <tr>
                    <td>Jenis Member</td>
                    <td>:</td>
                    <td id="get_jenis_member">`+data.data.jenis_member+`</td>
                  </tr>
                  <tr>
                    <td>Masa Aktif</td>
                    <td>:</td>
                    <td id="get_masa_aktif">`+data.data.masa_aktif + ` `+ data.data.satuan_masa_aktif+`</td>
                  </tr>
                  <tr>
                    <td>Perkiraan Berakhir</td>
                    <td>:</td>
                    <td id="get_perkiraan_berakhir">`+data.perkiraan_masa_aktif+`</td>
                  </tr>
                  <tr>
                    <td>Biaya</td>
                    <td>:</td>
                    <td>`+number_format(data.data.biaya)+`</td>
                  </tr>
                  <tr>
                    <td>Wajib Registrasi</td>
                    <td>:</td>
                    <td>`+y_n[data.data.wajib_register]+`</td>
                  </tr>
                </table>


                <input type="hidden" id="get_biaya_register" class="form-control" value="`+biaya_register+`">
                <input type="hidden" id="get_biaya_paket" class="form-control" value="`+data.data.biaya+`">
                <input type="hidden" id="get_biaya_semua" class="form-control" value="`+total+`">
                `);


                
                if (data.data.wajib_register==1) {

                 $('#show_list_order_keranjang').html(`
                    <ul class="list-group list-group-unbordered" id="daftar_item">
                     <li class="list-group-item">
                          <b>Biaya Registrasi</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(biaya_register)+`</b> <br>
                           </span>
                      </li>
                     <li class="list-group-item">
                          <b>Biaya Paket</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(data.data.biaya)+`</b> <br>
                           </span>
                     </li>
                   
                    </ul>

                    `);
                }else{
                 $('#show_list_order_keranjang').html(`
                    <ul class="list-group list-group-unbordered" id="daftar_item">
                    
                     <li class="list-group-item">
                          <b>Biaya Paket</b> 
                           <span class="pull-right" style="color:purple; text-align:right"><b id="get_biaya_paket">`+ number_format(data.data.biaya)+`</b> <br>
                           </span>
                     </li>
                    </ul>

                    `);

                }



                 $('#diskon').show();
                  $('#detail_diskon').html('');
                  $('#diskon_member').val('').change();
                 $('#total_biaya').show();
                 $('#total_biaya_register').val(total);
                 $('#total_biaya').html(`
                  <h4 class="pull-left" >Total</h4>
           <h4 class="pull-right" style="color:purple; text-align:right"><b>`+number_format(total)+`</b> <br>
                           </h4>
                           <div class="clearfix"></div>

                           <hr>`);


                  $('#total_belanja').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3 id="total_pembayaran">Rp. `+number_format(total)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()">Konfirmasi Member</button>
        </div>
        </div>

              `);

              },
              error : function(){
                console.log('e');
              }
            });
          }
      
function detail_diskon(id_diskon)
  {
    var biaya_register = $('#total_biaya_register').val();
    console.log(biaya_register);
    var y_n = ['Tidak','Ya'];

            $.ajax(
            {
              url     : baseUrl('/user/kassa/member/detail_diskon'),
              dataType: 'JSON',
              type    : 'POST',
              data    : { 
                id_diskon : id_diskon,
                
              },
              success : function(data)
              {
                if (data.data.jenis =='Persentase') {
                  nilai_diskon = (data.data.besar_diskon / 100) *biaya_register;
                  show_besar_diskon = data.data.besar_diskon+'% [Rp. '+number_format(nilai_diskon)+']';
                }
                else{
                  show_besar_diskon =  "Rp. "+number_format(data.data.besar_diskon);
                  nilai_diskon = data.data.besar_diskon;

                }
                  dibayar = biaya_register - nilai_diskon ; 
                $('#detail_diskon').html(`

                  <tr>
                    <td>Jenis Diskon</td>
                    <td>:</td>
                    <td id="get_jenis_diskon">`+data.data.jenis+`</td>
                  </tr>
                  <tr>
                    <td>Besar Diskon</td>
                    <td >:</td>
                    <td id="get_besar_diskon">`+show_besar_diskon+`</td>
                  </tr>
                  <tr>
                    <td>Total</td>
                    <td>:</td>
                    <td id="get_dibayar">`+number_format(dibayar)+`</td>
                  </tr>
                 `);



                 $('#nilai_besar_diskon').val(nilai_diskon);



                 $('#total_belanja').html(`
                      <div class="box">
        <div class="box-body" >
            <div class="small-box bg-gray">
                                <div class="inner">

                                  <p>Total</p>
                                  <h3  id="total_pembayaran">Rp. `+number_format(dibayar)+`</h3>
                                </div>
                              </div>
                              <button class="btn btn-default btn-block" onclick="klik_konfirmasi()">Konfirmasi Member</button>






        </div>
        </div>

              `);

                 $('#show_input_simpan_diskon').html(`
                     
            
              `);



              },
              error : function(){
                console.log('e');
              }
            });
          }
      


function klik_konfirmasi(){
    var input_nama = $('#input_nama').val();
    var input_jk = $('#input_jk').val();
    var input_alamat = $('#input_alamat').val();
    var input_nohp = $('#input_nohp').val();
    var input_email = $('#input_email').val();
    var id_jenis_member = $('#id_jenis_member').val();


    if (input_nama=='') {

      Swal.fire('Error','Harap masukan nama','error');
    }
    else if (input_jk=='') {
      Swal.fire('Error','Harap masukan jenis kelamin','error');

    }
    else if (id_jenis_member=='') {
      Swal.fire('Error','Harap masukan pilih paket','error');

    }else{
      konfirmasi();

    }
    



}

function konfirmasi()
  {
    $('#konfirmasi_member').modal('show');
    var link_foto = $('#src_foto').val();
    var nama = $('#input_nama').val();
    var jk = $('#input_jk').val();
    var alamat = $('#input_alamat').val();
    var nohp = $('#input_nohp').val();
    var email = $('#input_email').val();
    var jenis_member = $('#get_jenis_member').html();
    var masa_aktif = $('#get_masa_aktif').html();
    var perkiraan_berakhir = $('#get_perkiraan_berakhir').html();
    var biaya_register = $('#get_biaya_register').val();
    var biaya_paket = $('#get_biaya_paket').val();
    var biaya_semua = $('#get_biaya_semua').val();
    var id_jenis_diskon = $('#diskon_member').val();
    var jenis_diskon = $('#get_jenis_diskon').html();
    var besar_diskon = $('#get_besar_diskon').html();
    
    var nilai_besar_diskon = $('#nilai_besar_diskon').val();
    var dibayar = $('#total_pembayaran').html();

  var id_jenis_member = $('#id_jenis_member').val();
    console.log(biaya_register);

    if (link_foto=='') {
      $('#konfirmasi_member').find('.show_foto').html(`<img src="<?php echo base_url('assets/gambar/user.webp') ?>" class="show_foto" width="100%">`);

    }else{
      $('#konfirmasi_member').find('.show_foto').html(`<img src="`+link_foto+`" class="show_foto" width="100%">`);

    }

    if (id_jenis_diskon=='') {
        $('#konfirmasi_member').find('#show_konfirmasi_diskon').hide();
    }
      else{
        $('#konfirmasi_member').find('#show_konfirmasi_diskon').show();
      }
    $('#konfirmasi_member').find('#show_nama').html(nama);
    $('#konfirmasi_member').find('#show_jk').html(jk);
    $('#konfirmasi_member').find('#show_alamat').html(alamat);
    $('#konfirmasi_member').find('#show_nohp').html(nohp);
    $('#konfirmasi_member').find('#show_email').html(email);

    $('#konfirmasi_member').find('#show_jenis_member').html(jenis_member);
    $('#konfirmasi_member').find('#show_masa_aktif').html(masa_aktif);
    $('#konfirmasi_member').find('#show_perkiraan_berakhir').html(perkiraan_berakhir);
    $('#konfirmasi_member').find('#show_biaya_registrasi').html(number_format(biaya_register));
    $('#konfirmasi_member').find('#show_biaya_paket').html(number_format(biaya_paket));
    $('#konfirmasi_member').find('#show_total').html(number_format(biaya_semua));
    $('#konfirmasi_member').find('#show_diskon').html(jenis_diskon);
    $('#konfirmasi_member').find('#show_nilai_diskon').html(besar_diskon);
    $('#konfirmasi_member').find('#show_total_semua').html(dibayar);

    $('#konfirmasi_member').find('#simpan_nama').val(nama);
    $('#konfirmasi_member').find('#simpan_jk').val(jk);
    $('#konfirmasi_member').find('#simpan_alamat').val(alamat);
    $('#konfirmasi_member').find('#simpan_nohp').val(nohp);
    $('#konfirmasi_member').find('#simpan_email').val(email);

    $('#konfirmasi_member').find('#simpan_id_jenis_member').val(id_jenis_member);
    $('#konfirmasi_member').find('#simpan_berakhir').val(perkiraan_berakhir);
    $('#konfirmasi_member').find('#simpan_biaya_pendaftaran').val(biaya_register);
    $('#konfirmasi_member').find('#simpan_id_diskon').val(id_jenis_diskon);
    

        if ($('#diskon_member').val()=='') {
          var harus_dibayar = parseInt(biaya_semua);
        }else{
          var harus_dibayar = parseInt(biaya_semua) - parseInt(nilai_besar_diskon);
        }
          $('#konfirmasi_member').find('#show_kembalian').html("Rp. 0");

          $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+number_format(harus_dibayar));

        $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(0);
        $('#konfirmasi_member').find('#simpan_dibayar').val(harus_dibayar);
        $('#konfirmasi_member').find('#simpan_total').val(harus_dibayar);


        $('#konfirmasi_member').find('#input_dibayar').keyup(function(){
          var dibayar_pelanggan = $('#konfirmasi_member').find('#input_dibayar').val();
          var sisa = dibayar_pelanggan - harus_dibayar;

           if (dibayar_pelanggan =='') {
            $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+ number_format(harus_dibayar));
            $('#konfirmasi_member').find('#show_kembalian').html('Rp. 0');

        $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(0);
        $('#konfirmasi_member').find('#simpan_dibayar').val(harus_dibayar);

            }else{

                $('#konfirmasi_member').find('#show_kembalian').html("Rp. "+number_format(sisa));
                $('#konfirmasi_member').find('#show_dibayar').html("Rp. "+number_format(dibayar_pelanggan));

            $('#konfirmasi_member').find('#simpan_kembalian_pembayaran').val(sisa);
            $('#konfirmasi_member').find('#simpan_dibayar').val(dibayar_pelanggan);

            }




        });



          }
      



function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.show_foto').attr('src', e.target.result);
            $('#src_foto').val(e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
$("#berkas").change(function(){
    readURL(this);
});

function simpan_order()
  {
    var form_data = $('#form_catat_order').serialize();
    var qty = $('#detail_fnb').find('#qty').val();
    var stok = $('#detail_fnb').find('#stok_tersedia').val();
    if (qty=='') {
      Swal.fire('Error','Harap masukan jumlah pesanan','error');
    }
    else if (qty>stok) {
      
      Swal.fire('Error','Pesanan melebihi stok. Stok tersedia : ' + stok,'error');
    }else{

            $.ajax(
            {
              url     : baseUrl('/user/kassa/fnb/masuk_keranjang'),
              // dataType: 'JSON',
              type    : 'POST',
              data    : form_data,
              success : function(data)
              {
                $('#detail_fnb').modal('hide');
                list_order();
                 
              },
              error : function(){
                console.log('error');
              }
            });
          }
    }

</script>









