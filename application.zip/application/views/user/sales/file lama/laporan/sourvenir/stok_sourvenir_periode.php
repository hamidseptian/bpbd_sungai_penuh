 <div class="row">
    <div class="col-md-12">
      <div class="box">
         <div class="box-header with-border">
          <h3 class="box-title"><?php echo $caption ?></h3>
         <div class="pull-right">
           
         </div>
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th rowspan="2" width="20px">No</th>
                <th rowspan="2">Jenis Produk</th>
                <th rowspan="2">Produk</th>
                <th colspan="5">Stok</th>
              
              </tr>
              <tr>
                <th >Sisa Stok sebelumnya </th>
                  <th>Masuk periode Ini </th>
                  <th>Total stok sampai periode ini  </th>
                <th>Terjual periode Ini </th>
                <th >Sisa</th>
              </tr>
            
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            $total_qty_masuk = 0 ;
            $total_qty_keluar = 0 ;
            $total_qty_sisa = 0 ;


            $total_stok_sebelumnya = 0 ;
            $total_stok_semua = 0 ;
            $total_stok_sisa = 0 ;
            foreach ($sourvenir as $d1) { 
            
                $id_sourvenir = $d1['id_sourvenir'];

                $q_stok_sebelumnya = $this->db->query("SELECT sum(qty) as qty from stok_sourvenir
                where id_sourvenir='$id_sourvenir' 
                and tgl_masuk<='$tgl_awal'
                ")->row_array();
                $stok_sebelumnya = $q_stok_sebelumnya['qty'] == '' ? 0 : $q_stok_sebelumnya['qty'];

                $q_order_sebelumnya = $this->db->query("SELECT sum(qty) as qty from order_sourvenir
                where id_sourvenir='$id_sourvenir' 
                and tgl_order<='$tgl_awal'
                ")->row_array();
                $order_sebelumnya = $q_order_sebelumnya['qty'] == '' ? 0 : $q_order_sebelumnya['qty'];
                $sisa_stok_sebelumnya = $stok_sebelumnya - $order_sebelumnya;
                $total_stok_sebelumnya  += $sisa_stok_sebelumnya;





               $total_qty_masuk += $d1['qty_masuk'];
            $total_qty_keluar += $d1['qty_keluar'];
            $total_qty_sisa += $d1['qty_sisa'];
            $total_stok = $sisa_stok_sebelumnya + $d1['qty_masuk'];
            $total_stok_semua += $total_stok;
            $sisa_stok = $total_stok - $d1['qty_keluar'];
            $total_stok_sisa += $sisa_stok;
              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis']?></td>
                <td><?php echo $d1['produk']?></td>
                <td align="right"><?php echo $sisa_stok_sebelumnya; ?></td>
                <td align="right"><?php echo $d1['qty_masuk']?></td>
                <td align="right"><?php echo $total_stok; ?></td>
                <td align="right"><?php echo $d1['qty_keluar']?></td>
                <td align="right"><?php echo $sisa_stok; ?></td>
               
               
              </tr>
            <?php } ?>
            <tfoot>
              <th colspan="3">Total</th>
              <th style="text-align: right"><?php echo $total_stok_sebelumnya  ?></th>
              <th style="text-align: right"><?php echo $total_qty_masuk  ?></th>
              <th style="text-align: right"><?php echo $total_stok_semua  ?></th>
              <th style="text-align: right"><?php echo $total_qty_keluar  ?></th>
              <th style="text-align: right"><?php echo $total_stok_sisa   ?></th>
            </tfoot>
          </table>
        </div>


      </div>
    </div>
  </div>
<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
              $('#waktu').html(data.transaksi.tgl_transaksi + '<br>'+data.transaksi.jam_transaksi);
              $('#metode_pembayaran').html(data.transaksi.metode_pembayaran);
              $('#kasir').html(data.transaksi.kasir + ' - '+data.transaksi.jabatan);
              $('#status').html(data.transaksi.status);
                // console.log(data.transaksi);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });

                $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>Total</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(total_belanja)+`</b> <br>
                    
                     </span>
                 
                  </li>
                `);



        //           $('#total_belanja').html(`
        // <div class="box-body" >
        //     <div class="small-box bg-gray">
        //                         <div class="inner">

        //                           <p>Total</p>
        //                           <h3>Rp. `+number_format(total_belanja)+`</h3>
        //                         </div>
        //                       </div>
        // </div>

        //       `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}

</script>









