 <div class="row">
    <div class="col-md-12">
      <div class="box">
         <div class="box-header with-border">
          <h3 class="box-title"><?php echo $caption ?></h3>
         
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Jenis Produk</th>
                <th>Produk</th>
                <th>Harga</th>
                <th>Terjual</th>
                <th>Total</th>
              
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            $total_transaksi = 0 ;
            $total_terjual = 0 ;
            foreach ($sourvenir as $d1) { 
              $total_transaksi +=$d1['total'];
              $total_terjual +=$d1['terjual'];
              ?>
              <tr>
                <td><?php echo $no++ ?></td>

                <td><?php echo $d1['jenis']?></td>
                <td><?php echo $d1['produk']?></td>
                <td align="right"><?php echo number_format($d1['harga']) ?></td>
                <td align="right"><?php echo $d1['terjual']?></td>
                <td align="right"><?php echo number_format($d1['total']) ?></td>
               
               
              </tr>
            <?php } ?>
            <tfoot>
              <th colspan="4">Total</th>
              <th align="right" style="text-align:right"><?php echo number_format($total_terjual) ?></th>
              <th align="right" style="text-align:right"><?php echo number_format($total_transaksi) ?></th>
            </tfoot>
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/laporan/sourvenir/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/laporan/sourvenir/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/laporan/sourvenir/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
              $('#waktu').html(data.transaksi.tgl_transaksi + '<br>'+data.transaksi.jam_transaksi);
              $('#metode_pembayaran').html(data.transaksi.metode_pembayaran);
              $('#kasir').html(data.transaksi.kasir + ' - '+data.transaksi.jabatan);
              $('#status').html(data.transaksi.status);
                // console.log(data.transaksi);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });

                $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>Total</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(total_belanja)+`</b> <br>
                    
                     </span>
                 
                  </li>
                `);



        //           $('#total_belanja').html(`
        // <div class="box-body" >
        //     <div class="small-box bg-gray">
        //                         <div class="inner">

        //                           <p>Total</p>
        //                           <h3>Rp. `+number_format(total_belanja)+`</h3>
        //                         </div>
        //                       </div>
        // </div>

        //       `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}

</script>









