
 <div class="row">
    <div class="col-md-12">
      <div class="box">
         <div class="box-header with-border">
          <h3 class="box-title"><?php echo $caption ?></h3>
         
        </div>
        <div class="box-body">



<div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-user"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Membership</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_member']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   <?php echo $finance['qty_member'] ?>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-user"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Kelas</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_kelas']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   <?php echo $finance['qty_kelas'] ?>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-coffee"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">F & B</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_fnb']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   <?php echo $finance['qty_fnb'] ?>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-suitcase"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Sourvenir</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_sourvenir']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   <?php echo $finance['qty_sourvenir'] ?>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-download"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Pemasukan</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_pemasukan']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   Gabungan Member dan penjualan
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>

        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-upload"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Pengeluaran</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_pengeluaran']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   <?php echo $finance['qty_pengeluaran'] ?>
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Pendapatan</span>
              <span class="info-box-number"><?php echo number_format($finance['rp_pendapatan']) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                   Total Pendapatan
                  </span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>



        <!-- /.col -->
      </div>






              </div>


      </div>
    </div>
  </div>




<div class="row">
    <div class="col-md-12">
      <div class="box">
         <div class="box-header with-border">
          <h3 class="box-title">Pemasukan berdasarkan metode pembayaran</h3>
         
        </div>
        <div class="box-body">
<div class="row">
  <?php foreach ($berdasarkan_metode_pembayaran as $k => $v) { 
    $nilai = count($v['nilai']) == 0 ? 0 :  array_sum($v['nilai']);
    $member = count($v['member']) == 0 ? 0 :  array_sum($v['member']);
    $kelas = count($v['kelas']) == 0 ? 0 :  array_sum($v['kelas']);
    $fnb = count($v['fnb']) == 0 ? 0 :  array_sum($v['fnb']);
    $sourvenir = count($v['sourvenir']) == 0 ? 0 :  array_sum($v['sourvenir']);
    
    
    ?>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-user"></i></span>
            <div class="info-box-content">
              <span class="info-box-text"><?php echo $v['metode_pembayaran'] ?></span>
              <span class="info-box-number"><?php echo number_format($nilai) ?></span>
              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <a href="javascript:void(0)" onclick="lihat_detail_metode_pembayaran('<?php echo $v['metode_pembayaran'] ?>','<?php echo $nilai ?>','<?php echo $member ?>','<?php echo $kelas ?>','<?php echo $fnb ?>','<?php echo $sourvenir ?>')"  class="progress-description" style="color:white">
                   Lihat Detail
                  </a>
            </div>
          </div>
        </div>
      <?php } ?>
      </div>
              </div>


      </div>
    </div>
  </div>



<div class="row">
    <div class="col-md-12">
      <div class="box">
         <div class="box-header with-border">
          <h3 class="box-title">Pemasukan berdasarkan Kasir</h3>
         
        </div>
        <div class="box-body">
<div class="row">
  <?php foreach ($berdasarkan_kasir as $k => $v) { 
    
    $nilai = count($v['nilai']) == 0 ? 0 :  array_sum($v['nilai']);
    $member = count($v['member']) == 0 ? 0 :  array_sum($v['member']);
    $kelas = count($v['kelas']) == 0 ? 0 :  array_sum($v['kelas']);
    $fnb = count($v['fnb']) == 0 ? 0 :  array_sum($v['fnb']);
    $sourvenir = count($v['sourvenir']) == 0 ? 0 :  array_sum($v['sourvenir']);
    ?>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-user"></i></span>
            <div class="info-box-content">
              <span class="info-box-text"><?php echo $v['kasir'] ?></span>
              <span class="info-box-number"><?php echo number_format($nilai) ?></span>
              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description">
                    <a href="javascript:void(0)" onclick="lihat_detail_kasir('<?php echo $v['kasir'] ?>','<?php echo $nilai ?>','<?php echo $member ?>','<?php echo $kelas ?>','<?php echo $fnb ?>','<?php echo $sourvenir ?>')"  class="progress-description" style="color:white">
                   Lihat Detail
                  </a>
                  </span>
            </div>
          </div>
        </div>
      <?php } ?>
      </div>
              </div>


      </div>
    </div>
  </div>

  <div class="modal fade" id="lihat_detail_metode_pembayaran">
    <form action="<?php echo base_url('user/kassa/laporan/finance') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail <span id="metode_pembayaran"></span></h4>
              </div>
              <div class="modal-body">
                <table class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <td>No</td>
                      <td>Metode Pembayaran</td>
                      <td>Pendapatan</td>
                    </tr>
                  </thead>
                  <tbody id="data_metode_pembayaran">
                    <tr>
                      <td>1</td>
                      <td>Membership</td>
                      <td align="right" id="membership"> ???? </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Kelas</td>
                      <td align="right" id="kelas"> ???? </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>F & B</td>
                      <td align="right" id="fnb"> ???? </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Sourvenir</td>
                      <td align="right" id="souvenir"> ???? </td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="2">Total</td>
                      <td align="right" id="total"></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/laporan/finance') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/laporan/finance') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/laporan/finance') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/laporan/finance') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
              $('#waktu').html(data.transaksi.tgl_transaksi + '<br>'+data.transaksi.jam_transaksi);
              $('#metode_pembayaran').html(data.transaksi.metode_pembayaran);
              $('#kasir').html(data.transaksi.kasir + ' - '+data.transaksi.jabatan);
              $('#status').html(data.transaksi.status);
                // console.log(data.transaksi);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });

                $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>Total</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(total_belanja)+`</b> <br>
                    
                     </span>
                 
                  </li>
                `);



        //           $('#total_belanja').html(`
        // <div class="box-body" >
        //     <div class="small-box bg-gray">
        //                         <div class="inner">

        //                           <p>Total</p>
        //                           <h3>Rp. `+number_format(total_belanja)+`</h3>
        //                         </div>
        //                       </div>
        // </div>

        //       `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}

function lihat_detail_metode_pembayaran(metode_pembayaran,nilai, member, kelas, fnb, sourvenir){
  
                $('#lihat_detail_metode_pembayaran').modal('show');
                $('#lihat_detail_metode_pembayaran').find('#metode_pembayaran').html("<br>Metode Pembayaran "+metode_pembayaran);
                $('#lihat_detail_metode_pembayaran').find('#membership').html(number_format(member));
                $('#lihat_detail_metode_pembayaran').find('#kelas').html(number_format(kelas));
                $('#lihat_detail_metode_pembayaran').find('#fnb').html(number_format(fnb));
                $('#lihat_detail_metode_pembayaran').find('#souvenir').html(number_format(sourvenir));
                $('#lihat_detail_metode_pembayaran').find('#total').html(number_format(nilai));
   // $.ajax(
   //          {
   //            url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
   //            dataType: 'JSON',
   //            type    : 'POST',
   //            data    : { id_metode_pembayaran : id_metode_pembayaran },
   //            success : function(data)
   //            {
   //            },
   //            error : function(){
   //              console.log('error');
   //            }
   //          });
          

}

function lihat_detail_kasir(kasir,nilai, member, kelas, fnb, sourvenir){
  
                $('#lihat_detail_metode_pembayaran').modal('show');
                $('#lihat_detail_metode_pembayaran').find('#metode_pembayaran').html("<br>Kasir : "+kasir);
                $('#lihat_detail_metode_pembayaran').find('#membership').html(number_format(member));
                $('#lihat_detail_metode_pembayaran').find('#kelas').html(number_format(kelas));
                $('#lihat_detail_metode_pembayaran').find('#fnb').html(number_format(fnb));
                $('#lihat_detail_metode_pembayaran').find('#souvenir').html(number_format(sourvenir));
                $('#lihat_detail_metode_pembayaran').find('#total').html(number_format(nilai));
   // $.ajax(
   //          {
   //            url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
   //            dataType: 'JSON',
   //            type    : 'POST',
   //            data    : { id_metode_pembayaran : id_metode_pembayaran },
   //            success : function(data)
   //            {
   //            },
   //            error : function(){
   //              console.log('error');
   //            }
   //          });
          

}
</script>









