<style type="text/css">
  .highcharts-figure,
.highcharts-data-table table {
    min-width: 310px;
    max-width: 800px;
    margin: 1em auto;
}

#container {
    height: 400px;
}

.highcharts-data-table table {
    font-family: Verdana, sans-serif;
    border-collapse: collapse;
    border: 1px solid #ebebeb;
    margin: 10px auto;
    text-align: center;
    width: 100%;
    max-width: 500px;
}

.highcharts-data-table caption {
    padding: 1em 0;
    font-size: 1.2em;
    color: #555;
}

.highcharts-data-table th {
    font-weight: 600;
    padding: 0.5em;
}

.highcharts-data-table td,
.highcharts-data-table th,
.highcharts-data-table caption {
    padding: 0.5em;
}

.highcharts-data-table thead tr,
.highcharts-data-table tr:nth-child(even) {
    background: #f8f8f8;
}

.highcharts-data-table tr:hover {
    background: #f1f7ff;
}

</style>

<div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
            <h3 class="box-title">Grafik pendapatan member <?php echo $caption ?></h3>
        </div>
        <div class="box-body">
          
    <!-- <div id="container"></div> -->
    <canvas id="chart_member"></canvas>
        </div>


      </div>
    </div>
  </div>
<div class="row">
    <div class="col-md-12">
      <div class="box">

        <div class="box-header">
            <h3 class="box-title">Grafik pendapatan FnB & Sourvenir <?php echo $caption ?></h3>
        </div>
        <div class="box-body">
            <canvas id="chart_fnb"></canvas>
        </div>
      </div>
    </div>
  </div>








  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/laporan/grafik/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                      $bulan = $i;

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/laporan/grafik/') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>





<script src="https://code.highcharts.com/highcharts.js"></script>



<script type="text/javascript">

    var data_grafik = JSON.stringify(<?php echo $kumpul_grafik ?>);
    show_grafik = JSON.parse(data_grafik)


</script>




<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const chart_member = document.getElementById('chart_member');
  const chart_fnb = document.getElementById('chart_fnb');
  const chart_sourvenir = document.getElementById('chart_sourvenir');

  new Chart(chart_member, {
    type: 'bar',
    data: {
      labels: show_grafik.range,
      datasets: [
      {
        label: 'Pendapatan member',
        data: show_grafik.member,
        borderWidth: 1
      },
      {
        label: 'Pendapatan Kelas',
        data: show_grafik.kelas,
        borderWidth: 1
      },
      // {
      //   label: '# of Votes',
      //   data: show_grafik.fnb,
      //   borderWidth: 1
      // },
      // {
      //   label: '# of Votes',
      //   data: show_grafik.sourvenir,
      //   borderWidth: 1
      // }
      ]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });

  new Chart(chart_fnb, {
    type: 'bar',
    data: {
      labels: show_grafik.range,
      datasets: [
      // {
      //   label: '# of Votes',
      //   data: show_grafik.member,
      //   borderWidth: 1
      // },
      {
        label: 'Pendapatan FnB',
        data: show_grafik.fnb,
        borderWidth: 1
      },
      {
        label: 'Pendapatan Sourvenir',
        data: show_grafik.souvenir,
        borderWidth: 1
      }
      ]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
