
  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/laporan/fnb/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/laporan/fnb/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/laporan/fnb/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
            
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/laporan/fnb/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>
