 <div class="row">
    <div class="col-md-12">
      <div class="box">
         <div class="box-header with-border">
          <h3 class="box-title"><?php echo $caption ?></h3>
          <div class="pull-right">
            <?php if ($filter=='bulanan') { ?>
               <a href="<?php echo base_url('user/kassa/laporan/member/export_bulanan?bulan='.$bulan.'&tahun='.$tahun) ?>" class="btn btn-info btn-sm">Export Excel</a>
            <?php }else if ($filter=='tahunan') { ?>
               <a href="<?php echo base_url('user/kassa/laporan/member/export_tahunan?tahun='.$tahun) ?>" class="btn btn-info btn-sm">Export Excel</a>
            <?php } ?>
         </div>
        </div>
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Nama</th>
                <th>No HP</th>
                <th>Jenis Paket</th>
                <th>Biaya</th>
                <th>Potongan Harga</th>
                <th>Nilai Potongan</th>
                <th>Total</th>
                <th>Kasir</th>
                <th>Option</th>
              
              </tr>
            </thead>
            <?php 
            $no=1;
            $status = ['Tidak Aktif', 'Aktif'];
            $jenis = ['Makanan', 'Minuman'];
            $total_biaya = 0 ;
            $total_diskon = 0 ;
            $total_transaksi = 0 ;
            foreach ($member as $d1) { 
              $biaya = $d1['include_register'] == 'Ya' ? (100000 + $d1['biaya']) : $d1['biaya'];
              $jenis_member = $d1['include_register'] == 'Ya' ? 'Registrasi + ' . $d1['jenis_member'] : $d1['jenis_member'];
             
              ?>
              <tr>
                <td><?php echo $no++ ?></td>
                <?php if ($d1['id_jenis_member']==1) { ?>
                <td><?php echo $d1['id_member']?></td>
                <td>-</td>
                <?php }else{ ?>
                <td><?php echo $d1['nama']?></td>
                <td><?php echo $d1['no_hp']?></td>
              <?php  } ?>
                <td><?php echo $jenis_member; ?></td>
                <td align="right"><?php echo number_format($biaya) ?></td>
                  <?php 
                      if ($d1['jenis_potongan_harga']=='diskon') {
                        if ($d1['jenis_diskon']=='Persentase') {
                          $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                          $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                        }else{
                          $potongan = $d1['besar_diskon'] ;
                          $show_potongan = number_format($potongan);

                        }

                        $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                      }else if ($d1['jenis_potongan_harga']=='voucher') {
                        if ($d1['jenis_voucher']=='Persentase') {
                          $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                          $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                        }else{
                          $potongan = $d1['besar_voucher'] ;
                          $show_potongan = number_format($potongan);

                        }
                        $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                      }else{
                        $potongan =0;
                        $show_potongan ='';
                        $caption_potongan = '';
                      }

                        $total = $biaya - $potongan ;

                        
                     ;?>

                <td><?php echo $caption_potongan ?></td>
                 <td align="right"><?php echo $show_potongan; ?></td>
                <td align="right"><?php echo number_format($total) ?></td>
                <td><?php echo $d1['kasir']?></td>
                 <td> 
                          <button  class="btn btn-info btn-xs" onclick="print_order_member('<?php echo enkripsi($d1['id_transaksi_member']) ?>')">
                Print Struk
              </button>  
                        </td>
               
               
              </tr>
            <?php 

            $total_biaya += $biaya;
            $total_diskon += $potongan;
            $total_transaksi += $total;
          } ?>
            <tfoot>
              <th colspan="4">Total</th>
              <th align="right" style="text-align:right"><?php echo number_format($total_biaya) ?></th>
              <th></th>
              <th align="right" style="text-align:right"><?php echo number_format($total_diskon) ?></th>
              <th align="right" style="text-align:right"><?php echo number_format($total_transaksi) ?></th>
              <th colspan="2">-</th>
            </tfoot>
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/kassa/laporan/member') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Jenis Member</label>
                    <select name="jenis_member" class="form-control">
                      <option value="semua">Semua Jenis member</option>
                      <?php foreach ($list_jenis_member as $k => $v) { ?>
                      <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
                      <?php } ?>
                      <option value="dormant">Dormant [Expired lebih 2 Tahun]</option>
                      <option value="register">Khusus Registrasi</option>

                    </select>
                </div>
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/kassa/laporan/member') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">

                <div class="form-group">
                    <label>Jenis Member</label>
                    <select name="jenis_member" class="form-control">
                      <option value="semua">Semua Jenis member</option>
                      <?php foreach ($list_jenis_member as $k => $v) { ?>
                      <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
                      <?php } ?>
                      <option value="dormant">Dormant [Expired lebih 2 Tahun]</option>
                      <option value="register">Khusus Registrasi</option>

                    </select>
                </div>
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/kassa/laporan/member') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Jenis Member</label>
                    <select name="jenis_member" class="form-control">
                      <option value="semua">Semua Jenis member</option>
                      <?php foreach ($list_jenis_member as $k => $v) { ?>
                      <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
                      <?php } ?>
                      <option value="dormant">Dormant [Expired lebih 2 Tahun]</option>
                      <option value="register">Khusus Registrasi</option>

                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/kassa/laporan/member') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Jenis Member</label>
                    <select name="jenis_member" class="form-control">
                      <option value="semua">Semua Jenis member</option>
                      <?php foreach ($list_jenis_member as $k => $v) { ?>
                      <option value="<?php echo $v['id_jenis_member'] ?>"><?php echo $v['jenis_member'] ?></option>
                      <?php } ?>
                      <option value="dormant">Dormant [Expired lebih 2 Tahun]</option>
                      <option value="register">Khusus Registrasi</option>

                    </select>
                </div>
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>





  <div class="modal fade" id="print_order_member">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_member">
              
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Tutup</button>
              </div>
            </div>
          </div>
        </div>



<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
              $('#waktu').html(data.transaksi.tgl_transaksi + '<br>'+data.transaksi.jam_transaksi);
              $('#metode_pembayaran').html(data.transaksi.metode_pembayaran);
              $('#kasir').html(data.transaksi.kasir + ' - '+data.transaksi.jabatan);
              $('#status').html(data.transaksi.status);
                // console.log(data.transaksi);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });

                $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>Total</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(total_belanja)+`</b> <br>
                    
                     </span>
                 
                  </li>
                `);



        //           $('#total_belanja').html(`
        // <div class="box-body" >
        //     <div class="small-box bg-gray">
        //                         <div class="inner">

        //                           <p>Total</p>
        //                           <h3>Rp. `+number_format(total_belanja)+`</h3>
        //                         </div>
        //                       </div>
        // </div>

        //       `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}





function print_order_member(id_transaksi)
  {

    $('#print_order_member').modal('show');
    $('#print_order_member').find('#struk_order_member').html(`
      <iframe src="`+ baseUrl('user/kassa/member/print_order_member/') + id_transaksi +`/?status_print=reprint&action=Lunas" width="100%" height="400px"></iframe>
      `);


          }

</script>









