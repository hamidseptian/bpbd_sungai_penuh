<div class="row">
  
  <div class="col-md-12">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-aqua">
              <div class="widget-user-image">
                <?php 
                $foto = $user['foto'] == '' ? base_url().'/file/user/user.webp' : base_url().'/file/user/'.$user['foto'];
   ?>
                <img class="img" src="<?php echo $foto ?>" alt="User Avatar">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?php echo $user['nama'] ?></h3>
              <h5 class="widget-user-desc"><?php echo $user['nama_hak_akses'] ?></h5>
            </div>
         
          </div>
          <!-- /.widget-user -->
        </div>


</div>






<div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['member'] ?></h3>

              <p>Transaksi Member</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="<?php echo base_url('user/kassa/member') ?>" class="small-box-footer">
             Kelola Member
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['fnb'] ?></h3>

              <p>Transaksi FnB</p>
            </div>
            <div class="icon">
              <i class="fa fa-cutlery"></i>
            </div>
               <a href="<?php echo base_url('user/kassa/fnb/order') ?>" class="small-box-footer">
              Kelola Order Fnb
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['sourvenir'] ?></h3>

              <p>Transaksi Sourvenir</p>
            </div>
            <div class="icon">
              <i class="fa fa-gift"></i>
            </div>
               <a href="<?php echo base_url('user/kassa/sourvenir/order') ?>" class="small-box-footer">
              Kelola Order Sourvenir
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['pengeluaran'] ?></h3>

              <p>Transaksi Pengeluaran</p>
            </div>
            <div class="icon">
              <i class=" fa fa-money"></i>
            </div>
               <a href="<?php echo base_url('user/kassa/pengeluaran/') ?>" class="small-box-footer">
              Kelola Pengeluaran
            </a>
          </div>
        </div>
       
      </div>