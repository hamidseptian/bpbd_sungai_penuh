 <?php echo $this->session->flashdata('pesan') ?>

 <div class="row">
    <div class="col-md-6">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Identitas Pelanggan</h3>
        
        </div>
        <div class="box-body">
            <table class="table">
            <tr>
              <td colspan="3"><b>Pelanggan</b></td>
            </tr>
            <tr>
              <td>Nama</td>
              <td>:</td>
              <td><?php echo $order['nama'] ?></td>
            </tr>
            <tr>
              <td>Alamat</td>
              <td>:</td>
              <td><?php echo $order['alamat'] ?></td>
            </tr>
            <tr>
              <td>No HP</td>
              <td>:</td>
              <td><?php echo $order['no_hp'] ?></td>
            </tr>
            <tr>
              <td>Usaha</td>
              <td>:</td>
              <td><?php echo $order['usaha'] ?></td>
            </tr>
           
            <tr>
              <td colspan="3"><b>Barang</b></td>
            </tr>
            <tr>
              <td colspan="3" >
                <table class="table table-bordered">
                  <thead>
                      <tr>
                        <td>Barang</td>
                        <td>Harga</td>
                      </tr>
                  </thead>
                  <tbody id="list_barang">
                    <?php 
                    $total_list_barang = 0 ;
                    foreach ($list_barang as $k => $v) { 
                      $total_list_barang += $v['harga'];
                      ?>
                     <tr>
                       <td><?php echo $v['jenis_barang'].' - '.$v['keterangan'] ?></td>
                       <td><?php echo number_format($v['harga']) ?></td>
                     </tr>
                    <?php } ?>
                  </tbody>
                  <tfoot>
                      <tr>
                        <td>Total</td>
                        <td id="total_harga_barang"><?php echo number_format($total_list_barang) ?></td>
                      </tr>
                  </tfoot>
              </table>

              </td>
            </tr>
          
            <tr>
              <td colspan="3"><b>Kontrak dan Angsuran</b></td>
            </tr>
              <tr>
              <td>No Kontrak</td>
              <td>:</td>
              <td><?php echo $order['no_kontrak'] ?></td>
            </tr>
            <tr>
              <td>Angsran</td>
              <td>:</td>
              <td><?php echo number_format($order['angsuran']) ?></td>
            </tr>
            <tr>
              <td>DP</td>
              <td>:</td>
              <td><?php echo number_format($order['dp']) ?></td>
            </tr>
            <tr>
              <td>Lama Angsuran</td>
              <td>:</td>
              <td><?php echo $order['lama_angsuran'] ?> <?php echo $order['satuan_angsuran'] ?></td>
            </tr>
            <tr>
              <td>Tanggal Mulai</td>
              <td>:</td>
              <td><?php echo $order['mulai'] ?></td>
            </tr>
            <tr>
              <td>Tanggal Selesai</td>
              <td>:</td>
              <td><?php echo $order['selesai'] ?></td>
            </tr>
          </table>
           <a class="btn btn-info btn-xs" href="<?php echo base_url('user/sales/order/print_kontrak/'.enkripsi($order['id_order'])) ?>" target="_blank">Print Kontrak</a>
           <a class="btn btn-info btn-xs" href="<?php echo base_url('user/sales/order/download_sk/') ?>" target="_blank">Download SK</a>
        </div>


      </div>
    </div>
    <div class="col-md-6">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Pembayaran</h3>
        
        </div>
        <form action="<?php echo base_url('/user/sales/order/simpan_pembayaran') ?>" method="post">
        	
        <div class="box-body">

          <div class="form-group">
            <label>Tanggal Pembayaran</label>
            <input type="date" name="tanggal" class="form-control" value="<?php echo date('Y-m-d') ?>">
          </div>
         
          <div class="form-group">
            <label>Angsuran Ke</label>
            <input type="hidden" name="id_order" id="id_order" class="form-control" value="<?php echo $order['id_order'] ?>">
            <input type="hidden" name="id_pelanggan" id="id_pelanggan" class="form-control" value="<?php echo $order['id_pelanggan'] ?>">
            <input type="hidden" name="angsuran" id="angsuran" class="form-control" value="<?php echo $order['angsuran'] ?>">
            <input type="text" name="ke" id="ke" class="form-control "  value="<?php echo $angsuran_berikutnya ?>">
          </div>
          <div class="form-group">
            <label>Dibayar</label>
            <input type="text" name="dibayar" id="dibayar" class="form-control"  value="<?php echo $order['angsuran'] ?>">
            <span id="caption_dibayar"></span>
          </div>
          <div class="form-group">
            <label>Penyetor</label>
            <input type="text" name="penyetor" id="penyetor" class="form-control" value="<?php echo $order['nama'] ?>">
          </div>
          <div class="form-group">
            <?php if ($angsuran_berikutnya >=$order['lama_angsuran']) { ?>
            <input type="hidden" name="status_kredit" id="status_kredit" class="form-control" value="Lunas">
             <button class="btn btn-info btn-block" type="submit" id="tombol_submit_pembayaran">Simpan Pembayaran Dan Lunaskan</button>
            <?php }else{ ?>
              <input type="hidden" name="status_kredit" id="status_kredit" class="form-control" value="">
             <button class="btn btn-info btn-block" type="submit" id="tombol_submit_pembayaran">Simpan Pembayaran</button>

            <?php } ?>
          </div>

        </div>

        </form>

      </div>
    </div>
    <div class="col-md-9">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">List pembayaran</h3>
          <div class="pull-right">
           <a class="btn btn-info btn-xs" href="<?php echo base_url('user/sales/order/print_kwitansi_all/'.enkripsi($order['id_order'])) ?>" target="_blank">Print semua kwitansi</a>
         </div>
        </div>

           <div class="box-body" style="max-height:500px; overflow-y: scroll">
          
         
          <table class="table data_tabel">
           <thead>
              
            <tr>
              <td>No</td>
              <td>Tanggal</td>
              <td>Keterangan</td>
              <td>Dibayar</td>
              <td>Penyetor</td>
              <!-- <td>Action</td> -->
            </tr>
           </thead>
            <tbody>
            	<?php 
            	$no = 1;
            	$total_dibayar = 0 ;
            	foreach ($pembayaran as $k => $v) {
            	$total_dibayar += $v['dibayar'] ;
            	 ?>

            <tr>
              <td><?php echo $no++ ?></td>
              <td><?php echo $v['tanggal_dibayar'] ?></td>
              <td>Angsuran ke <?php echo $v['angsuran_ke'] ?></td>
              <td><?php echo number_format($v['dibayar']) ?></td>
              <td><?php echo $v['penyetor'] ?></td>
          <!--     <td>
                <a href="" class="btn btn-info btn-xs">Print</a>
              </td> -->
            </tr>
            	<?php } ?>
              
            </tbody>
            <tfoot>
            <tr>
              <td colspan="4">Total</td>
              <td></td>
            </tr>
              
            </tfoot>
          </table>
       






        
        </div>

      

      </div>
      <div id="total_belanja">
    
      </div>
    </div>

    <div class="col-md-3">
    	

    	 <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Sisa pembayaran</h3>
          <div class="pull-right">
         </div>
        </div>

        <div class="box-body" id="form_lihat_ringkasan" style="max-height:500px; overflow-y: scroll">
        	<table class="table">
        		<tr>
        			<td>Biaya </td>
        			<td>:</td>
        			<td><?php echo number_format($total_list_barang) ?></td>
        		</tr>
        		<tr>
        			<td>DP </td>
        			<td>:</td>
        			<td><?php echo number_format($order['dp']) ?></td>
        		</tr>
        		<tr>
        			<td>Dibayar </td>
        			<td>:</td>
        			<td><?php echo number_format($total_dibayar) ?></td>
        		</tr>
        		<tr>
        			<td>Sisa </td>
        			<td>:</td>
        			<td><?php 
        			$sisa_pembayaran = $total_list_barang - $order['dp'] - $total_dibayar;
        			echo number_format($sisa_pembayaran);
        			 ?></td>
        		</tr>
        	</table>  
         



        </div>
     </div>
    </div>
  </div>

  

  <div class="modal fade" id="print_perhalaman">
    <form action="<?php echo base_url('user/kassa/sourvenir/order') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Print Per Halaman</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Print</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  

  
  
<script type="text/javascript">



 var total_list_barang = parseInt(<?php echo $total_list_barang ?>);
 var angsuran = parseInt(<?php echo $order['angsuran'] ?>);
 var next_angsuran = parseInt(<?php echo $angsuran_berikutnya ?>);
 var lama_angsuran = parseInt(<?php echo $order['lama_angsuran'] ?>);

$('#dibayar').keyup(function(){
    var dibayar=$('#dibayar').val();
    var banyak_angsuran =  parseInt(dibayar / angsuran);
    var batas_angsuran = next_angsuran + banyak_angsuran -1
    var sisa = dibayar % angsuran;

     if (dibayar=='') {

    $('#caption_dibayar').html('Masukan pembayaran anda'); 
    $('#tombol_submit_pembayaran').attr('disabled','disabled'); 
    $('#tombol_submit_pembayaran').attr('class','btn btn-danger  btn-block'); 
     }else{
      if (dibayar < angsuran) {

        $('#caption_dibayar').html('Harap memasukan angka sesuai kelipatan angsuran'); 
        $('#tombol_submit_pembayaran').attr('disabled','disabled'); 
        $('#tombol_submit_pembayaran').attr('class','btn btn-danger  btn-block'); 
      }else{
        if (batas_angsuran > lama_angsuran) {
          $('#caption_dibayar').html('Jumlah yang anda bayar melebihi lama angsuran.'); 
        $('#tombol_submit_pembayaran').attr('disabled','disabled'); 
        $('#tombol_submit_pembayaran').attr('class','btn btn-danger  btn-block'); 

        }else{

          $('#tombol_submit_pembayaran').removeAttr('disabled'); 
          $('#tombol_submit_pembayaran').attr('class','btn btn-info  btn-block'); 

          $('#caption_dibayar').html('Anda membayar sebanyak untuk '+banyak_angsuran+' kali angsuran sampai angsuran ke : '+batas_angsuran+'<br>Kembalian : ' + sisa); 
        }
      }

     }
});

  function print_perhalaman(){
    $('#print_perhalaman').modal('show');
  

  }


  function checkform() {
    if ($('#nama').val()=='') {
      Swal.fire('Error','Anda belum menginput Nama');
    }
    else if ($('#alamat').val()=='') {
      Swal.fire('Error','Anda belum menginput Alamat');
      
    }
    else if ($('#nohp').val()=='') {
      Swal.fire('Error','Anda belum menginput No HP');
      
    }
    else if ($('#usaha').val()=='') {
      Swal.fire('Error','Anda belum menginput usaha');
    }
      
    else if ($('#keterangan').val()=='') {
      Swal.fire('Error','Anda belum menginput keterangan');
    }
      
    else if ($('#harga').val()=='') {
      Swal.fire('Error','Anda belum menginput harga');
    }
      
    else if ($('#angsuran').val()=='') {
      Swal.fire('Error','Anda belum menginput angsuran');
    }
      
    else if ($('#dp').val()=='') {
      Swal.fire('Error','Anda belum menginput DP');
    }
      
    else if ($('#lama').val()=='') {
      Swal.fire('Error','Anda belum menginput lama angsuran');
    }
    else if ($('#tanggal').val()=='') {
      Swal.fire('Error','Anda belum menginput tanggal');
    }else{
      ringkasan();
    }
    
}

function ringkasan(){
  $('#data_ringkasan').show();
  $('#tombol_ringkasan').hide();
  var formdata = $('#form_input').serialize();
     $.ajax(
            {
              url     : baseUrl('/user/sales/order/ringkasan'),
              type    : 'POST',
              dataType: 'JSON',
              data    : formdata,
              success : function(data)
              {
                console.log();
                var nama = $('#nama').val();  
                var alamat = $('#alamat').val();  
                var nohp = $('#nohp').val();  
                var usaha = $('#usaha').val();  
                var keterangan = $('#keterangan').val();  
                var harga = $('#harga').val();  
                var angsuran = $('#angsuran').val();  
                var dp = $('#dp').val();  
                var lama = $('#lama').val();  
                var tanggal = $('#tanggal').val();  
                var no_kontrak = $('#no_kontrak').val();  
                
                $('#show_no_kontrak').html(no_kontrak);  
                $('#show_nama').html(nama);  
                $('#show_alamat').html(alamat);  
                $('#show_nohp').html(nohp);  
                $('#show_usaha').html(usaha);  
                $('#show_jenis_barang').html(keterangan);  
                $('#show_harga').html(harga);  
                $('#show_angsuran').html(angsuran);  
                $('#show_dp').html(dp);  
                $('#show_lama_angsuran').html(lama);  
                $('#show_mulai').html(data.mulai);  
                $('#show_selesai').html(data.selesai);  



              },
              error : function(){
                alert('ee');
                
              }
            });
}
</script>