<style type="text/css">
  .header-left{
    float: left;
    width: 100%;

  }

  .logo{
    float: left;
    width: 20%;
  }
  .perusahaan{
    float: left;
    width: 70%;
    margin-left : 10px;
  }
  .nama_perusahaan{
    font-size: 16px;
    font-family: 'arial';
  }
  .alamat_perusahaan{
    font-size: 10px;
    font-family: 'arial';
  }
  .identitas_pembayaran{
    /*font-size: 7.4px;*/
  }

  .garis_putus{
    border-bottom:dotted 1px black;
    width: 80px;
    border-size : 1px;
  }
  .clearfix{
    clear: both;
  }


  .angsuran_ke{
    float: left;
    width: 50%
  }
  .sisa_angsuran{
    float: right;
    width: 40%
  }
  .untuk_pembayaran{
    width: 100%;
  }

  .kwitansi{
    margin-bottom:15px;
    float: left;
    border-width: 2px;
    border-spacing: 100px;

    font-family: 'calibri';
  }
  .tabel-data-kiri{
    font-size:8px;
    float: left;
    width: 45%;
  }
  .tabel-data-tengah{
    width: 35%;
    float: left;
    font-size:9px;
    font-family: 'calibri';
  }
  .tabel-data-kanan{
    width: 20%;
    float: right;
    font-size:9px;
    font-family: 'calibri';
  }
  .tabel-data-bawah{
    margin-top:10px;
  }
  table{
    font-size:9px;
    font-family: 'calibri';
  }
  h2{
    font-size:15px;
    margin-top:5px;
    margin-bottom:5px;
  }
  .caption_kwitansi{
    font-size:7px;
  }
  .terbilang{
    margin-top:6px;
    font-size:10px;
  }
  .footer{
    margin-top:2px;
    margin-bottom:5px;
  }
  .footer-left{
    float: left;
    width : 35%;
    
  }
  .footer-right{
    float: right;
    width : 61.4%;
    
    font-size: 9px;
  }
  .direktur{
    float: right;
    width : 50%;
    text-align: center;
  }
  .ka_pembukuan{
    text-align: center;
    float: left;
    width : 50%;
  }
  .tanggal_ttd{
    text-align: right;
    margin-right : 10px;
  }
</style>

<?php 
$isi_item = "";
$total_harga_semua = 0;
foreach ($item as $k => $v) {
  $harga_total = $v['harga'] * $v['qty'];
  $total_harga_semua +=$harga_total;
  $isi_item.=' <tr>
      <td>'.$v['qty'].'</td>
      <td>'.$v['jenis_barang'].' - '.$v['keterangan'].'</td>
      <td  align="right">'.number_format($v['harga']).'</td>
      <td  align="right">'.number_format($harga_total).'</td>
  
    </tr>';
}
$dp = $order['dp'];
$harga = $order['harga'];
$pengurangan_dp = $harga - $dp;



 ?>
<div class="kwitansi">
<div class="header">
  <div class="header-left">
    <div class="logo">
      <img src="<?php echo base_url('assets/gambar/logo.png') ?>">
      
    </div>
    <div class="perusahaan">
      <div class="nama_perusahaan">
        CV. BERKAH MAJU BERSAMA
      </div>
      <div class="alamat_perusahaan">
        Jl. Utama No. 15 RT 001/RW 008 Kel. Dadok Tunggul Hitam Padang <br>
        HP/WA : 0822 8544 9277
      </div>
    </div>
  </div>
 
</div>

<div class="clearfix"></div>
<br>
<h2>INVOICE / DO</h2>
<div class="tabel-data-kiri">
  <table>
    <tr>
      <td>Nama / Kode Konsultan </td>
      <td>:</td>
      <td> Nama Marketing </td>
    </tr>
    <tr>
      <td>Nama / Kode Inspektur </td>
      <td>:</td>
      <td> Leader / kepala marketing </td>
    </tr>
  
    <tr>
      <td>Nomor Kontrak</td>
      <td>:</td>
      <td><?php echo $order['no_kontrak'] ?></td>
    </tr>
  
    <tr>
      <td>Berdasarkan Permohonan Saudara No</td>
      <td>:</td>
      <td> kosongkan </td>
    </tr>
  
  </table>
</div>
<div class="tabel-data-tengah">
  <table>
    <tr>
      <td>Nama Pelanggan </td>
      <td>:</td>
      <td><?php echo $order['nama'] ?></td>
    </tr>
    <tr>
      <td>Alamat</td>
      <td>:</td>
      <td><?php echo $order['alamat'] ?></td>
    </tr>
    <tr>
      <td>No HP</td>
      <td>:</td>
      <td><?php echo $order['no_hp'] ?></td>
    </tr>
  </table>
</div>

<div class="tabel-data-kanan">
  <table>
    <tr>
      <td>Total</td>
      <td>:</td>
      <td><?php echo number_format($total_harga_semua) ?></td>
    </tr>
    <tr>
      <td>Angsuran</td>
      <td>:</td>
      <td><?php echo number_format($order['angsuran']) ?></td>
    </tr>
    <tr>
      <td>Lama Angsuran</td>
      <td>:</td>
      <td><?php echo $order['lama_angsuran'].'  '.$order['satuan_angsuran'] ?></td>
    </tr>
    <tr>
      <td>DP</td>
      <td>:</td>
      <td><?php echo number_format($order['dp']) ?></td>
    </tr>
  </table>
</div>


<div class="clearfix"></div>


<div class="tabel-data-bawah">
  <table border="1" width="100%" style="border-collapse: collapse;">
    <tr>
      <th>Unit</th>
      <th>Nama Barang</th>
      <th>Harga</th>
      <th>Jumlah</th>
    
    </tr>
   <?php echo $isi_item ?>
    <tr>
      <td colspan="3"> Total </td>
      <td align="right"> <?php echo number_format($total_harga_semua) ?> </td>
    </tr>
  
  </table>
  <div class="terbilang">Terbilang : <?php echo ucwords(terbilang($total_harga_semua)) ?> Rupiah</div>
</div>
<div class="footer">
  <br>
  <br>
  <br>
  <table width="100%" >
    <tr>
      <td  width="25%" align="center"> ............................................</td>
      <td  width="25%" align="center"> ............................................</td>
      <td  width="25%" align="center"> ............................................</td>
      <td  width="25%" align="center"> ............................................</td>
    </tr>
    <tr>
      <td  width="25%" align="center" valign="top">Penyewa / Pembeli</td>
      <td  width="25%" align="center" valign="top">(Administrasi)</td>
      <td  width="25%" align="center" valign="top">(Ka Cabang / Ka. Sub)</td>
      <td  width="25%" align="center" valign="top">(Bagian pengiriman) <br>
      </td>
    </tr>
      <tr>
      <td colspan="3">Keterangan : Barang yang sudah dibeli tidak dapat ditukar / dikembalikan</td>
      <td align="center"  >Diterima dengan baik dan lengkap</td>
    </tr>
  </table>
</div>
</div>
