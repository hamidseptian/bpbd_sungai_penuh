<style>
  .font_laporan{
    font-size:<?php echo $print_setting['preview_font_size_content'] ?>px;
    font-family: <?php echo $print_setting['preview_font_family'] ?>;
  }



  .header{
    font-size:<?php echo $print_setting['preview_font_size_header'] ?>px;
    font-family: <?php echo $print_setting['preview_font_family'] ?>;
  }
  .footer{
    font-size:<?php echo $print_setting['preview_font_size_footer'] ?>px;
    font-family: <?php echo $print_setting['preview_font_family'] ?>;
  }
</style>


<table class="header" width="100%">
  <tr>
    <td colspan="3">
      <center><img src="<?php echo base_url('assets/gambar/logo.png') ?>" width="80px"> </center>
      
    </td>
  </tr>
  <tr>
    <td valign="top">No Transaksi</td>
    <td valign="top">:</td>
    <td valign="top"> <?php 
    $pecah_tgl = explode('-', $transaksi['tgl_transaksi']);
    $pecah_jam = explode(':', $transaksi['jam_transaksi']);

               if ($transaksi['order_ke']>0 && $transaksi['order_ke'] <10) {
                    $order_ke = '000'.$transaksi['order_ke'];
                 }
                 else if ($transaksi['order_ke']>=10 && $transaksi['order_ke'] <100) {
                    $order_ke = '00'.$transaksi['order_ke'];
                 }
                 else if ($transaksi['order_ke']>=100 && $transaksi['order_ke'] <1000) {
                    $order_ke = '0'.$transaksi['order_ke'];
                 }else{
                    $order_ke = $transaksi['order_ke'];
                 }
    $no_transaksi = $pecah_tgl[0].$pecah_tgl[1].$pecah_tgl[2].''.$order_ke;
    $waktu_transaksi = $pecah_tgl[0].'-'.$pecah_tgl[1].'-'.$pecah_tgl[2].'<br>'.$pecah_jam[0].':'.$pecah_jam[1];
    echo $no_transaksi;
     ?> </td>
  </tr>
  <tr>
    <td valign="top">Date</td>
    <td valign="top">:</td>
    <td valign="top"> <?php echo $waktu_transaksi ?> </td>
  </tr>
  <tr>
    <td valign="top">Kasir</td>
    <td valign="top">:</td>
    <td valign="top"> <?php echo $transaksi['nama']; ?> </td>
  </tr>
  <tr>
    <td colspan="3">[<?php echo $status_print ?>]</td>
 
  </tr>
</table>


<hr>

<table class="font_laporan table" width="100%"> 
  <?php 
  $total_semua = 0;
  foreach ($produk as $k => $v) { 
    $hargatotal = $v['harga_satuan'] * $v['qty'];
    $total_semua += $hargatotal;
    ?>
    <tr>
      <td><?php echo $v['produk'] ?></td>
      <td></td>
    </tr>
    <tr>
      <td><?php echo $v['qty'] ?> * <?php echo number_format($v['harga_satuan']) ?></td>
      <td align="right"><?php echo number_format($hargatotal) ?></td>
    </tr>
  <?php } ?>

   </table>
   <hr>
   <table class="font_laporan table" width="100%">
    <tr>
      <td>Total</td>
      <td align="right"><?php echo number_format($total_semua) ?></td>
    </tr>
    <tr>
      <td>Pembayaran Via</td>
      <td align="right"> <?php echo $transaksi['metode_pembayaran'] ?> </td>
    </tr>
    <tr>
      <td>Cash</td>
      <td align="right">  <?php echo number_format($transaksi['dibayar']) ?> </td>
    </tr>
    <tr>
      <td>Change</td>
      <td align="right">  <?php echo number_format($transaksi['kembalian']) ?> </td>
    </tr>
  
</table>


  <center>
<p class="footer" style="margin-top : -10px; text-align: center;">
  Thank You for Your Visit <br><br>
  Jl. Padang Pasir Raya No.6, Padang Pasir, <br> Kec. Padang Barat, Kota Padang, Sumatera Barat <br>
  Telp. (0751)25388
</p>
</center>
