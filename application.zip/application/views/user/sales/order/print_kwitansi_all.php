<style type="text/css">
  .header-left{
    float: left;
    width: 60%;

  }
  .header-right{
    float: right;
    width: 36.7%;

    font-size: 5px;
  }
  .logo{
    float: left;
    width: 20%;
  }
  .perusahaan{
    float: left;
    width: 75%;
    margin-left : 10px;
  }
  .nama_perusahaan{
    font-size: 12px;
    font-family: 'arial';
  }
  .alamat_perusahaan{
    font-size: 7.4px;
    font-family: 'arial';
  }
  .identitas_pembayaran{
    /*font-size: 7.4px;*/
  }

  .garis_putus{
    border-bottom:dotted 1px black;
    width: 80px;
    border-size : 1px;
  }
  .clearfix{
    clear: both;
  }


  .angsuran_ke{
    float: left;
    width: 50%
  }
  .sisa_angsuran{
    float: right;
    width: 40%
  }
  .untuk_pembayaran{
    width: 100%;
  }

  .kwitansi{
    margin-bottom:15px;
    width: 50%;
    float: left;
    border-bottom : solid;
    border-width: 2px;
    border-spacing: 100px;

    font-family: 'calibri';
  }
  .tabel-data-header{
    font-size:8px;
  }
  .tabel-data-body{
    font-size:9px;
    font-family: 'calibri';
  }
  .caption_kwitansi{
    font-size:7px;
  }
  .rp{
    font-size:12px;
  }
  .footer{
    margin-top:2px;
    margin-bottom:5px;
  }
  .footer-left{
    float: left;
    width : 35%;
    
  }
  .footer-right{
    float: right;
    width : 61.4%;
    
    font-size: 9px;
  }
  .direktur{
    float: right;
    width : 50%;
    text-align: center;
  }
  .ka_pembukuan{
    text-align: center;
    float: left;
    width : 50%;
  }
  .tanggal_ttd{
    text-align: right;
    margin-right : 10px;
  }
</style>

<?php 
$dp = $order['dp'];
$harga = $order['harga'];
$pengurangan_dp = $harga - $dp;
for ($i=1; $i <= $order['lama_angsuran'] ; $i++) { 
$dibayarkan = $i*$order['angsuran'];
$sisa_pembayaran = $pengurangan_dp - $dibayarkan;
 ?>
<div class="kwitansi">
<div class="header">
  <div class="header-left">
    <div class="logo">
      <img src="<?php echo base_url('assets/gambar/logo.png') ?>">
      
    </div>
    <div class="perusahaan">
      <div class="nama_perusahaan">
        CV. BERKAH MAJU BERSAMA
      </div>
      <div class="alamat_perusahaan">
        Jl. Utama No. 15 RT 001/RW 008 Kel. Dadok Tunggul Hitam Padang <br>
        HP/WA : 0822 8544 9277
      </div>
    </div>
  </div>
  <div class="header-right">
    <table class="tabel-data-header" style="display: inline-block;">
      <tr>
        <td>Angsuran</td>
        <td>:</td>
        <td class="garis_putus">Rp. <?php echo number_format($order['angsuran']) ?></td>
      </tr>
      <tr>
        <td >No Kwitansi</td>
        <td>:</td>
        <td class="garis_putus"> ??? </td>
      </tr>
      <tr>
        <td>Tgl. Kwitansi</td>
        <td>:</td>
        <td class="garis_putus"> ??? <?php echo @$pembayaran[$i]['tanggal_bayar'] ?></td>
      </tr>
      <tr>
        <td>No Kontrak</td>
        <td>:</td>
        <td class="garis_putus"><?php echo $order['no_kontrak'] ?></td>
      </tr>
    </table>
  </div>
</div>

<div class="clearfix"></div>
<div class="identitas_pembayaran">
  <table class="tabel-data-body">
    <tr>
      <td>Nama Sales </td>
      <td>:</td>
      <td> ??? </td>
    </tr>
    <tr>
      <td>Terima Dari</td>
      <td>:</td>
      <td> <?php echo @$pembayaran[$i]['terima_dari'] ?> </td>
    </tr>
    <tr>
      <td>Uang Sebesar</td>
      <td>:</td>
      <td><?php echo ucwords(terbilang($order['angsuran'])).' Rupiah'; ?> </td>
    </tr>
    <tr>
      <td>Untuk Pembayaran</td>
      <td>:</td>
      <td> 
        <div class="untuk_pembayaran">
          <div class="angsuran_ke"><span>Angsuran Ke : <?php echo $i;// @$pembayaran[$i]['angsuran_ke'] ?></span> <!--  <span style="margin-left: 300px">Sisa Angsuran : Rp. <?php echo number_format($sisa_pembayaran) ?> </span> --></div>
        </div>
      </td>
    </tr>
    <tr style="color:red">
      <td>Nama Barang Cicilan</td>
      <td>:</td>
      <td>
       <?php 
       $count = count($item);
       $q_count = $count-1;
       foreach ($item as $k => $v) {
         echo $v['jenis_barang'].' - '.$v['keterangan'];
        if ($q_count>$k) {
          echo ", ";
        }else{

        }
       }
       ?> 
     </td>
    </tr>
  
  </table>
</div>

<div class="footer">
  <div class="footer-left">
    <div class="rp">
      Rp. <?php echo number_format($order['angsuran']) ?>
    </div>
    <div class="caption_kwitansi">
      INI ADALAH SATU SATUNYA KWITANSI CV. BERKAH MAJU BERSAMA YANG SAH, JANGAN MENERIMA JENIS YANG LAINNYA
    </div>
  </div>
  <div class="footer-right">
    <div class="tanggal_ttd">Padang,............................................. 20.....     </div>
    <br>
    <br>
    <div class="ka_pembukuan">
      <center>
        ................................... <br>
      Ka. Pembukuan / Keuangan
      </center>
    </div>
    <div class="direktur">
      <center>
        ................................... <br>
      Direktur
      
      </center>
    </div>
  </div>
</div>
</div>

<?php } ?>