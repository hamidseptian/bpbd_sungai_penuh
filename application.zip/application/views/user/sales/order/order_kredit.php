 <div class="row">
    <div class="col-md-12">
      <div class="box">
       <div class="box-header">
        </div>
       <input type="hidden" name="" id="id_transaksi_terakhir">
       <input type="hidden" name="" id="status_sourvenir">
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th rowspan="2">No</th>
                <th colspan="4">Pelanggan</th>
              
                <th colspan="7">Data Kredit</th>
                <th rowspan="2">Action</th>
              
              </tr>
              <tr>
                <th>Nama</th>
                <th>Alamat</th>
                <th>No HP</th>
                <th>Usaha</th>
                <th>No Kontrak</th>
                <th>Barang</th>
                <th>Harga</th>
                <th>Angsuran</th>
                <th>DP</th>
                <th>Lama Angsuran</th>
                <th>Status</th>
              </tr>
            </thead>
            <?php 
           $no=1;
            foreach ($data as $d1) {  ?> 
              <tr> 
                <td><?php echo $no++; ?></td> 

                <td><?php echo $d1['nama'];?></td>
                <td><?php echo $d1['alamat'];?></td>
                <td><?php echo $d1['no_hp'];?></td>
                <td><?php echo $d1['usaha'];?></td>
                <td><?php echo $d1['no_kontrak'];?></td>
                <td><?php echo $d1['jenis_barang'].' - '.$d1['keterangan_barang'];?></td>
                <td align="right"><?php echo number_format($d1['harga']) ?></td>
                <td align="right"><?php echo number_format($d1['angsuran']) ?></td>
                <td align="right"><?php echo number_format($d1['dp']) ?></td>
                <td align="right"><?php echo number_format($d1['lama_angsuran']) ?> <?php echo $d1['satuan_angsuran'];?></td>
                <td><?php echo $d1['status']?></td>
                <td> 
                  <a class="btn btn-warning btn-xs" href="<?php echo base_url('user/sales/order/detail/'.enkripsi($d1['id_order']).'/'.$page) ?>">Detail</a>
                </td>
               
              </tr>
            <?php } ?>
          
          </table>
        </div>


      </div>
    </div>
  </div>



  <div class="modal fade" id="detail_transaksi">
    <form action="<?php echo base_url('user/kassa/sourvenir/simpan_stok') ?>" method='post' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Detail Transaksi</h4>
              </div>
              <div class="modal-body">
               <input type="hidden" class="form-control" name="id_sourvenir" id="id_sourvenir" >
             
                 <div class="form-group">
                  <ul class="list-group list-group-unbordered" id="daftar_item">
                  </ul>
              
                </div>

                <div class="form-group">
                   <table class="table">
                     <tr>
                       <td>Waktu Transaksi</td>
                       <td>:</td>
                       <td id="waktu"></td>
                     </tr>
                     <tr>
                       <td>Metode Pembayaran</td>
                       <td>:</td>
                       <td id="metode_pembayaran"></td>
                     </tr>
                     <tr>
                       <td>Kasir</td>
                       <td>:</td>
                       <td id="kasir"></td>
                     </tr>
                     <tr>
                       <td>Status</td>
                       <td>:</td>
                       <td id="status"></td>
                     </tr>
                    
                   </table>


                </div>


                 <div id="total_belanja">
    
                  </div>
               
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>

                <button type="button" class="btn btn-default" onclick="print_order_sourvenir()">Print</button>
              </div>
            </div>
          </div>
    </form>
        </div>




  <div class="modal fade" id="print_order_sourvenir">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                
                <h4 class="modal-title">Print</h4>
              </div>
              <div class="modal-body" id="struk_order_sourvenir">
              
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="close_order_sourvenir()">Tutup</button>
              </div>
            </div>
          </div>
        </div>
<script>
  

function detail_transaksi(id_transaksi, tgl_transaksi, jam_transaksi){
  $('#daftar_item').html('');
   $.ajax(
            {
              url     :'<?php echo base_url() ?>user/kassa/sourvenir/detail_transaksi',
              dataType: 'JSON',
              type    : 'POST',
              data    : { id_transaksi : id_transaksi },
              success : function(data)
              {
              $('#waktu').html(data.transaksi.tgl_transaksi + '<br>'+data.transaksi.jam_transaksi);
              $('#metode_pembayaran').html(data.transaksi.metode_pembayaran);
              $('#kasir').html(data.transaksi.kasir + ' - '+data.transaksi.jabatan);
              $('#status').html(data.transaksi.status);
              
              $('#id_transaksi_terakhir').val(data.id_transaksi);
              $('#status_fnb').val(data.transaksi.status);
                // console.log(data.transaksi);
                if (data.jml_item > 0 ) {
                 
                  var total_belanja = 0;
                  total_belanja = parseInt(total_belanja);
                $.each(data.data_item, function(k,v){
                  total_belanja += parseInt(v.totalharga) ;
                  var show_item = v.catatan == '' ? v.qty + ' * ' + number_format(v.harga) :  v.qty + ' * ' + number_format(v.harga)+` <br> ` + v.catatan;
                    $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>`+ v.produk+`</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(v.totalharga)+`</b> <br>
                    
                     </span>
                    <br>
                    ` + show_item+`
                   
                  </li>
                `);
                });

                $('#daftar_item').append(`

                      <li class="list-group-item">
                    <b>Total</b> 
                     <span class="pull-right" style="color:purple; text-align:right"><b>`+ number_format(total_belanja)+`</b> <br>
                    
                     </span>
                 
                  </li>
                `);



        //           $('#total_belanja').html(`
        // <div class="box-body" >
        //     <div class="small-box bg-gray">
        //                         <div class="inner">

        //                           <p>Total</p>
        //                           <h3>Rp. `+number_format(total_belanja)+`</h3>
        //                         </div>
        //                       </div>
        // </div>

        //       `);
                }else{

                       $('#show_list_order_keranjang').html(`

                  Belum ada order
              `);
                }
                // console.log(data);

                
              },
              error : function(){
                console.log('error');
              }
            });
          

}



function print_order_sourvenir()
  {
    var id_transaksi = $('#id_transaksi_terakhir').val();
    var action = $('#status_sourvenir').val();
    var status_print = action == 'Lunas' ? 'reprint' : 'preview';
    $('#detail_transaksi').modal('hide');
    $('#print_order_sourvenir').modal('show');
    $('#print_order_sourvenir').find('#struk_order_sourvenir').html(`
      <iframe src="`+ baseUrl('user/kassa/sourvenir/print_order_sourvenir/') + id_transaksi +`/?status_print=`+status_print+`&action=`+action+`" width="100%" height="400px"></iframe>
      `);
            // $.ajax(
            // {
            //   url     : baseUrl('/user/kassa/sourvenir/simpan_transaksi'),
            //   dataType: 'JSON',
            //   type    : 'POST',
            //   data    : { 
            //     jumlah : jumlah,
            //     metode_pembayaran : metode_pembayaran,
            //   },
            //   success : function(data)
            //   {
            //     console.log(data.id_transaksi);
            //    print_order_sourvenir(data.id_transaksi);
                 
            //   },
            //   error : function(){
            //     alert('error');
            //   }
            // });
          }

</script>









