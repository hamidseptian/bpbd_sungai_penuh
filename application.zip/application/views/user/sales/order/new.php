 

<form method="post" action="<?php echo base_url('user/sales/order/simpan_order') ?>"  id="form_input">
 <div class="row">
    <div class="col-md-3">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Identitas Pelanggan</h3>
         <div class="pull-right"> 
          <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#pelanggan_lama" onclick="pelanggan_lama()">
                Pelanggan Lama
              </button> 
          <button type="reset" class="btn btn-info btn-xs">
                Clear Form
              </button>
          
         </div>
        </div>
        <div class="box-body">
            <input type="hidden" name="jenis_pel" class="form-control" placeholder="Jenis Pelangggan" id="jenis_pel">
            <input type="hidden" name="id_pel" class="form-control" placeholder="iD Pelangggan" id="id_pel">
            <input type="hidden" name="tgl_mulai" class="form-control" id="tgl_mulai">
            <input type="hidden" name="tgl_selesai" class="form-control" id="tgl_selesai">
          <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" id="nama">
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" name="alamat" class="form-control" id="alamat">
          </div>
          <div class="form-group">
            <label>No HP</label>
            <input type="text" name="nohp" class="form-control" id="nohp">
          </div>
          <div class="form-group">
            <label>Usaha</label>
            <input type="text" name="usaha" class="form-control" id="usaha">
          </div>
        </div>


      </div>
    </div>
    <div class="col-md-6">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Item Kredit</h3>
        
        </div>
        <div class="box-body">




                                    <div class="form-group" >
                                      <label>Barang</label>
                                      <button class="btn btn-info btn-xs pull-right" onclick="tambah_barang()" type="button" data-toggle="tooltip" data-title="Tambah Barang"><i class="fa fa-plus"></i></button>
                                      <div style="overflow-x:scroll; width: 100%">
                                      
                                      <table class="table table-bordered" id="tablelist">
                                        <thead>
                                          <tr>
                                            <td>Jenis Barang</td>
                                            <td>Keterangan</td>
                                            <td>Harga</td>
                                            <td>Action</td>
                                          </tr>
                                        </thead>
                                        <tbody id="form_barang">
                                          <tr>
                                            <td>
                                               <select name="jenis_barang[]" class="form-control">
                                                <?php foreach ($jenis_barang as $k => $v) { ?>
                                                <option value="<?php echo $v['id_jenis_barang'].'|'.$v['jenis_barang'] ?>"><?php echo $v['jenis_barang'] ?></option>
                                                <?php } ?>
                                              </select>
                                            </td>
                                            <td><input type="text"  name="keterangan[]" required class="form-control keterangan"></td>
                                            <td><input type="text"  name="harga[]" class="form-control harga"></td>
                                            <td align="center"> - </td>
                                          </tr>
                                        </tbody>

                                      </table>
                                      </div>
                                    </div>
                                 


                                    <hr>

          <div class="form-group">
            <label>No. Kontrak</label>
            <input type="keterangan" name="no_kontrak" id="no_kontrak" class="form-control">
          </div>
       
          <div class="form-group">
            <label>Angsuran</label>
            <input type="text" name="angsuran" id="angsuran" class="form-control">
          </div>
          <div class="form-group">
            <label>DP</label>
            <input type="text" name="dp" id="dp" class="form-control">
          </div>
          <div class="form-group">
            <label>Lama Angsuran</label>
            <div class="row">
              <div class="col-md-4">
                <input type="text" name="lama" id="lama" class="form-control" value="200">
              </div>
              <div class="col-md-8">
                <input type="text" name="jenis_angsuran" class="form-control" value="Hari" readonly>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label>Tanggal </label>
            <input type="date" name="tanggal" class="form-control" value="<?php echo date('Y-m-d') ?>">
          </div>
         
        </div>


      </div>
    </div>
    <div class="col-md-3">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Ringkasan</h3>
          <div class="pull-right">
           <button class="btn btn-info btn-xs" type="button" onclick="checkform()">Lihat ringkasan kredit</button>
         </div>
        </div>

           <div class="box-body" id="form_lihat_ringkasan" style="max-height:500px; overflow-y: scroll">
          
          <div id="tombol_ringkasan">
            Klik <button class="btn btn-info btn-xs" type="button" onclick="checkform()">Lihat ringkasan kredit</button> sebelum menyimpan
          </div>
          <div id="data_ringkasan" hidden="true">
          <table class="table">
            <tr>
              <td colspan="3"><b>Pelanggan</b></td>
            </tr>
            <tr>
              <td>Nama</td>
              <td>:</td>
              <td id="show_nama"></td>
            </tr>
            <tr>
              <td>Alamat</td>
              <td>:</td>
              <td id="show_alamat"></td>
            </tr>
            <tr>
              <td>No HP</td>
              <td>:</td>
              <td id="show_nohp"></td>
            </tr>
            <tr>
              <td>Usaha</td>
              <td>:</td>
              <td id="show_usaha"></td>
            </tr>
            <tr>
              <td colspan="3"><b>Barang</b></td>
            </tr>
            <tr>
              <td colspan="3" >
                <table class="table table-bordered">
                  <thead>
                      <tr>
                        <td>Barang</td>
                        <td>Harga</td>
                      </tr>
                  </thead>
                  <tbody id="list_barang"></tbody>
                  <tfoot>
                      <tr>
                        <td>Total</td>
                        <td id="total_harga_barang"></td>
                      </tr>
                  </tfoot>
              </table>

              </td>
            </tr>
           <tr>
              <td colspan="3"><b>Kontrak dan Angsuran</b></td>
            </tr>
            <tr>
              <td>No Kontrak</td>
              <td>:</td>
              <td id="show_no_kontrak"></td>
            </tr>
            <tr>
              <td>Angsuran</td>
              <td>:</td>
              <td id="show_angsuran"></td>
            </tr>
            <tr>
              <td>DP</td>
              <td>:</td>
              <td id="show_dp"></td>
            </tr>
            <tr>
              <td>Lama Angsuran</td>
              <td>:</td>
              <td id="show_lama_angsuran"></td>
            </tr>
            <tr>
              <td>Tanggal Mulai</td>
              <td>:</td>
              <td id="show_mulai"></td>
            </tr>
            <tr>
              <td>Tanggal Selesai</td>
              <td>:</td>
              <td id="show_selesai"></td>
            </tr>
            <tr>
              <td colspan="3">
         <button id="tombol_simpan" class="btn btn-info btn-sm">Simpan Order</button></td>
           
            </tr>
          </table>
        </div>
         






        
        </div>

      

      </div>
      <div id="total_belanja">
    
      </div>
    </div>
  </div>
</form>

  

  

  <div class="modal fade" id="pelanggan_lama">
    <form action="<?php echo base_url('user/su/admin/simpanedit_akun') ?>" method='post' enctype="multipart/form-data"> 
      
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih pelanggan lama</h4>
              </div>
                
               <div class="modal-body">
               
                  <table class="table data_tabel">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No HP</th>
                        <th>Usaha</th>
                        <th>Pilih</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($pelanggan as $key => $v) { ?>

                      <tr>
                        <th>No</th>
                        <td><?php echo $v['nama'] ?></td>
                        <td><?php echo $v['alamat'] ?></td>
                        <td><?php echo $v['no_hp'] ?></td>
                        <td><?php echo $v['usaha'] ?></td>
                        <td>
                          <button type="button" class="btn btn-info btn-xs pull-left" data-dismiss="modal" onclick="pelanggan_dipilih('<?php echo $v['id_pelanggan'] ?>','<?php echo $v['nama'] ?>','<?php echo $v['alamat'] ?>','<?php echo $v['no_hp'] ?>','<?php echo $v['usaha'] ?>')">Pilih</button>
                        </td>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>            
             
              </div>


              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
              </div>
            </div>
            
          </div>
    </form>
        </div>


  
<script type="text/javascript">
  function pelanggan_dipilih(id_pel, nama, alamat, nohp, usaha){
    $('#jenis_pel').val('Lama');
    $('#id_pel').val(id_pel);
    $('#nama').val(nama);
    $('#alamat').val(alamat);
    $('#nohp').val(nohp);
    $('#usaha').val(usaha);

  }



  function tambah_barang(){
    $('#form_barang').append(`
       <tr class="form_barang_baru">
                                            <td>
                                              <select name="jenis_barang[]" class="form-control">
                                                <?php foreach ($jenis_barang as $k => $v) { ?>
                                                <option value="<?php echo $v['id_jenis_barang'].'|'.$v['jenis_barang'] ?>"><?php echo $v['jenis_barang'] ?></option>
                                                <?php } ?>
                                              </select>

                                            </td>
                                            <td><input type="text" name="keterangan[]" required class="form-control keterangan"></td>
                                            <td><input type="text" name="harga[]" class="form-control harga"></td>
                                            <td align="center">
                                              <button class="btn btn-danger btn-xs  hapus_form_barang" onclick="hapus_form_barang(this)" type="button"><i class="fa fa-times"></i></button>
                                            </td>
                                          </tr>`);

  }



 function hapus_form_barang(x){
 $(x).parents("tr").remove();
 };

  function checkform() {
    if ($('#nama').val()=='') {
      Swal.fire('Error','Anda belum menginput Nama');
    }
    // else if ($('#alamat').val()=='') {
    //   Swal.fire('Error','Anda belum menginput Alamat');
      
    // }
    // else if ($('#nohp').val()=='') {
    //   Swal.fire('Error','Anda belum menginput No HP');
      
    // }
    // else if ($('#usaha').val()=='') {
    //   Swal.fire('Error','Anda belum menginput usaha');
    // }
      
    else if ($('.keterangan').val()=='') {
      Swal.fire('Error','Anda belum menginput keterangan');
    }
      
    else if ($('.harga').val()=='') {
      Swal.fire('Error','Anda belum menginput harga');
    }
      
    // else if ($('#angsuran').val()=='') {
    //   Swal.fire('Error','Anda belum menginput angsuran');
    // }
      
    // else if ($('#dp').val()=='') {
    //   Swal.fire('Error','Anda belum menginput DP');
    // }
      
    // else if ($('#lama').val()=='') {
    //   Swal.fire('Error','Anda belum menginput lama angsuran');
    // }
    // else if ($('#tanggal').val()=='') {
    //   Swal.fire('Error','Anda belum menginput tanggal');
    // }
    else{
      ringkasan();
    }
    
}


function numberWithCommas(x) {
   return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

console.log(numberWithCommas(1000))


function ringkasan(){
  $('#data_ringkasan').show();
  $('#tombol_ringkasan').hide();
  var formdata = $('#form_input').serialize();
     $.ajax(
            {
              url     : baseUrl('/user/sales/order/ringkasan'),
              type    : 'POST',
              dataType: 'JSON',
              data    : formdata,
              success : function(data)
              {
                console.log(data.barang);
                var nama = $('#nama').val();  
                var alamat = $('#alamat').val();  
                var nohp = $('#nohp').val();  
                var usaha = $('#usaha').val();  
                var keterangan = $('#keterangan').val();  
                var harga = $('#harga').val();  
                var angsuran = $('#angsuran').val();  
                var dp = $('#dp').val();  
                var lama = $('#lama').val();  
                var tanggal = $('#tanggal').val();  
                var no_kontrak = $('#no_kontrak').val();  
                



                $('#list_barang').html(`


`);  
                var total_harga_barang =0;
                $.each(data.barang, function(k,v){
                  total_harga_barang += parseInt(v.harga);
                  $('#list_barang').append(`
                    <tr>
                      <td>`+v.jenis_barang+` - `+v.keterangan+`</td>
                      <td>`+numberWithCommas(v.harga)+`</td>
                    </tr>
                  `);  
                });
                  // $('#list_barang').append(`</table>`);  
                $('#total_harga_barang').html(total_harga_barang);  
                $('#show_nama').html(nama);  
                $('#show_alamat').html(alamat);  
                $('#show_nohp').html(nohp);  
                $('#show_angsuran').html(numberWithCommas(angsuran));  
                $('#show_dp').html(numberWithCommas(dp));  
                $('#show_lama_angsuran').html(lama);  
                $('#show_mulai').html(data.mulai);  
                $('#show_selesai').html(data.selesai);  

               $('#tgl_mulai').val(data.mulai);  
               $('#tgl_selesai').val(data.selesai);  



              },
              error : function(){
                alert('ee');
                
              }
            });
}
</script>