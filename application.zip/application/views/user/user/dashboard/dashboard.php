<?php 
$foto = $user['foto'] == '' ? base_url().'/file/user/user.webp' : base_url().'/file/user/'.$user['foto'];
 ?> <div class="row">
   





   <div class="col-md-4">


          <div class="box box-primary">
            <div class="box-body box-profile">
                            
                <img class=" img-responsive " src="<?php echo $foto ?>" alt="User profile picture" width="100%">
              <h3 class="profile-username text-center">sdhisuh</h3>
 <div class="bg-green disabled color-palette" style="padding:5px; text-align:center"><span>Bergabung Pada <br>2024-01-14 15:28<br><b>Aktif sampai 2025-01-14</b></span></div>   
             



            </div>
            
          </div>
          

          
          
        </div>




  </div>
