<div class="row">
  
  <div class="col-md-12">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-aqua">
              <div class="widget-user-image">
                <?php 
                $foto = $user['foto'] == '' ? base_url().'/file/user/user.webp' : base_url().'/file/user/'.$user['foto'];
   ?>
                <img class="img" src="<?php echo $foto ?>" alt="User Avatar">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?php echo $user['nama'] ?></h3>
              <h5 class="widget-user-desc"><?php echo $user['nama_hak_akses'] ?></h5>
            </div>
         
          </div>
          <!-- /.widget-user -->
        </div>


</div>






<div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['user'] ?></h3>

              <p>User Akses</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="<?php echo base_url('user/master/user') ?>" class="small-box-footer">
             Kelola Akses User
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $count['pengeluaran'] ?></h3>

              <p>Usulan pengeluaran Baru</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
               <a href="<?php echo base_url('user/master/approval/pengeluaran') ?>" class="small-box-footer">
              Kelola Pengeluaran
            </a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>7</h3>

              <p>Jenis laporan</p>
            </div>
            <div class="icon">
              <i class="fa fa-sticky-note-o"></i>
            </div>



                  <a type="button" class="small-box-footer dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Action
                    <span class="fa fa-caret-down"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo base_url('user/kassa/laporan/member/') ?>">Membership - Laporan</a></li>
                    <li><a href="<?php echo base_url('user/kassa/laporan/member/diskon') ?>">Membership - Diskon</a></li>
                    <li><a href="<?php echo base_url('user/kassa/laporan/fnb/stok?filter=harian&tgl='.date('Y-m-d')) ?>">FnB - Stok</a></li>
                    <li><a href="<?php echo base_url('user/kassa/laporan/fnb/order?filter=harian&tgl='.date('Y-m-d')) ?>">FnB - Order</a></li>
                    <li><a href="<?php echo base_url('user/kassa/laporan/sourvenir/stok?filter=harian&tgl='.date('Y-m-d')) ?>">Souvenir - Stok</a></li>
                    <li><a href="<?php echo base_url('user/kassa/laporan/sourvenir/order?filter=harian&tgl='.date('Y-m-d')) ?>">Souvenir - Order</a></li>
                    <li class="divider"></li>
                    <li><a href="<?php echo base_url('user/kassa/laporan/finance/?filter=harian&tgl='.date('Y-m-d')) ?>">Gabungan</a></li>
                  </ul>


          </div>
        </div>
       
      </div>