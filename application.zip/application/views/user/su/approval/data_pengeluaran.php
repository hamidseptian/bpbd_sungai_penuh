 <?php 
              $no=1;
                foreach($pengeluaran as $v){ 
                $src_foto = base_url('file/kartu/'.$v['file']);  
                  ?>

                     <style>
  .example_<?php echo $v['id_kartu_member'] ?> {
  border: 2px solid black;
  background: url(<?php echo $src_foto ?>);
  background-repeat: no-repeat;
    background-size: 100% 100%;
    width : 100%;
    height : auto;
    /*opacity: 0.5;*/
}
</style>

<?php   } ?>


<div class="row">

   
    <div class="col-md-8">
      <div class="box">
    
        <div class="box-body" style="overflow-x: scroll">
          <?php echo $this->session->flashdata('pesan') ?>
          <table class="table table-striped table-bordered" id="tabel1">
            <thead>
              <tr>
                <th width="20px">No</th>
                <th>Tanggal</th>
                <th>Pengusul</th>
                <th>Besar Pengeluaran</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Option</th>
             
              
              </tr>
            </thead>
            <tbody> 
              <?php 
              $no=1;

              $total_usulan = 0;
              $total_acc = 0;
              $total_reject = 0;
              $total_belum_cek = 0;


              $total_pengusul_usulan = 0;
              $total_pengusul_acc = 0;
              $total_pengusul_batal = 0;
              $total_pengusul_reject = 0;
              $total_pengusul_belum_cek = 0;
                foreach($pengeluaran as $v){ 
                $total_pengusul_usulan++;

                if ($v['status']==0) {
                  $total_belum_cek += $v['besar_pengeluaran'];
                  $total_usulan += $v['besar_pengeluaran'];
                  $total_pengusul_belum_cek++;
                 }
                elseif ($v['status']==2) {
                  $total_belum_cek += $v['besar_pengeluaran'];
                  $total_pengusul_batal++;
                 }else{
                  $total_usulan += $v['besar_pengeluaran'];
                  if ($v['approval']==1) {
                    $total_acc += $v['besar_pengeluaran'];
                    $total_pengusul_acc++;
                  }else{
                    $total_pengusul_reject++;
                    $total_reject += $v['besar_pengeluaran'];
                  }
                 } 
                  ?>
              <tr>  
                <td><?php echo $no++ ?></td>
               
                <td><?php echo $v['tgl_transaksi'] ?></td>
                <td><?php echo $v['nama'] ?></td>
                <td align="right"><?php echo ($v['besar_pengeluaran']) ?></td>
                <td><?php echo $v['keterangan'] ?></td>
                <?php if ($v['status']==0) { ?>
                  <td><?php echo $status[$v['status']] ?></td>
                   <td>
                    <a href="javascript:void(0)" class="btn btn-warning btn-xs"  onclick="detail('<?php echo $v['id_pengeluaran'] ?>','<?php echo $v['file'] ?>')">Detail</a>
                
                  </td>
                <?php }elseif ($v['status']==2) { ?>
                  <td><?php echo $status[$v['status']] ?></td>
                   <td>
                    <a href="javascript:void(0)" class="btn btn-default btn-xs"  onclick="detail('<?php echo $v['id_pengeluaran'] ?>','<?php echo $v['file'] ?>')">Detail</a>
                
                  </td>
                <?php }else{ ?>
                  <td><?php echo $status[$v['status']].' - '.$approval[$v['approval']].'<br>'.$v['keterangan_approval'] ?></td>
                  <td>
                    <?php if($v['approval']==0){ ?>
                    <a href="javascript:void(0)" class="btn btn-danger btn-xs"  onclick="detail('<?php echo $v['id_pengeluaran'] ?>','<?php echo $v['file'] ?>')">Detail</a>
                    <?php }else{ ?>
                    <a href="javascript:void(0)" class="btn btn-success btn-xs"  onclick="detail('<?php echo $v['id_pengeluaran'] ?>','<?php echo $v['file'] ?>')">Detail</a>
                    <?php } ?>
                  </td>
                <?php } ?>
              
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>


      </div>
    </div>


    <div class="col-md-4">
      <div class="row"> 
        <div class="col-md-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Usulan Pengeluaran</span>
              <span class="info-box-number"><?php echo number_format($total_usulan) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description"><a href="javascript:void(0)" style="color:white" onclick="statistika('usulan')"><?php echo $total_pengusul_usulan ?> Pengusul</a>, <?php echo $total_pengusul_batal ?> Membatalkan</span>
            </div>
          </div>
        </div>


        <div class="col-md-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Pengeluaran Di ACC</span>
              <span class="info-box-number"><?php echo number_format($total_acc) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description"><?php echo $total_pengusul_acc ?> Pengusul</span>
            </div>
          </div>
        </div>


        <div class="col-md-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Pengeluaran Di Tolak</span>
              <span class="info-box-number"><?php echo number_format($total_reject) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description"><?php echo $total_pengusul_reject ?> Pengusul</span>
            </div>
          </div>
        </div>


        <div class="col-md-12">
          <div class="info-box bg-aqua">
            <span class="info-box-icon"><i class="fa fa-money"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Pengeluaran Di Belum di verifikasi</span>
              <span class="info-box-number"><?php echo number_format($total_belum_cek) ?></span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
                  <span class="progress-description"><?php echo $total_pengusul_belum_cek ?> Pengusul</span>
            </div>
          </div>
        </div>


      </div>
    
    </div>
  </div>





  <div class="modal fade" id="detail_pengeluaran">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <form action="<?php echo base_url('user/master/approval/approve_pengeluaran') ?>" method="post">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Detail Pengeluaran</h4>
                </div>
                <div class="modal-body">
                  <input type="hidden" name="id_pengeluaran" id="id_pengeluaran">
                  <div class="row">
                      <div class="col-md-7">
                      <label>Bukti Transaksi</label>
                      <div id="bukti"></div>
                    </div> 
                    <div class="col-md-5">
                      <label>Detail</label>
                        <table class="table">
                         <tr>
                           <td>Waktu Transaksi</td>
                           <td>:</td>
                           <td id="waktu"></td>
                         </tr>
                         <tr>
                           <td>Keterangan</td>
                           <td>:</td>
                           <td id="keterangan"></td>
                         </tr>
                         <tr>
                           <td>Besar Pengeluaran</td>
                           <td>:</td>
                           <td id="besar_pengeluaran"></td>
                         </tr>
                      
                         <tr>
                           <td>Kasir</td>
                           <td>:</td>
                           <td id="kasir"></td>
                         </tr>
                          <tr>
                           <td>Status</td>
                           <td>:</td>
                           <td id="status"></td>
                         </tr>
                       
                       </table>
                       <div id="form_approval">
                         <div class="form-group">
                           <label>Approval</label>
                           <select class="form-control" name="approval">
                             <option value="1">Setujui</option>
                             <option value="0">Tolak</option>
                           </select>
                         </div>
                         <div class="form-group">
                           <label>Catatan</label>
                           <textarea class="form-control" name="keterangan_approval" rows="4"></textarea>
                         </div>
                         <div class="form-group">
                           <button type="submit" class="btn btn-info">Verifikasi</button> 
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                         </div>
                       </div>
                       <div id="hasil_approval">
                         <div class="form-group" id="form_hasil_approval">
                           <label>Approval</label> <br>
                           <span id="show_hasil_approval"></span>
                         </div>
                       
                         <div class="form-group">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                         </div>
                       </div>

                    </div> 
                  
                  </div>
                  <div class="form-group">
                    
                  </div>
                </div>
              
            </form>
              </div>
          </div>
        </div>




  <div class="modal fade" id="statistika">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <form action="<?php echo base_url('user/master/approval/approve_pengeluaran') ?>" method="post">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title">Statistika</h4>
                </div>
                <div class="modal-body" style="overflow-x:scroll">
                   <table class="table table-striped table-bordered data_tabel">
                    <thead>
                      <tr>
                        <th width="20px">No</th>
                        <th>Tanggal</th>
                        <th>Pengusul</th>
                        <th>Besar Pengeluaran</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th>Option</th>
                     
                      
                      </tr>
                    </thead>
                    <tbody> 
                    </tbody>
                  </table>
                </div>
              
            </form>
              </div>
          </div>
        </div>








  <div class="modal fade" id="filter_harian">
    <form action="<?php echo base_url('user/master/approval/pengeluaran') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal</label>
                    <input type="hidden" name="filter" value="harian">
                    <input type="date" name="tgl" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_bulanan">
    <form action="<?php echo base_url('user/master/approval/pengeluaran') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="bulanan">
                <div class="form-group">
                    <label>Bulan</label>
                    <select name="bulan" class="form-control">
                      <?php for ($i=1; $i <= 12 ; $i++) { 
                         if ($i<10) {
                      $bulan = "0".$i;
                    }else{
                      $bulan = $i;

                    }

                    ?>
                      <option value="<?php echo $bulan ?>" <?php if($i==date('n')){echo "selected";} ?>><?php echo bulan_global($i) ?></option>
                      <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_tahunan">
    <form action="<?php echo base_url('user/master/approval/pengeluaran') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" name="filter" value="tahunan">
               
                <div class="form-group">
                    <label>Tahun</label>
                    <select name="tahun" class="form-control">
                      <?php for ($i=date('Y'); $i >= 2000 ; $i--) { ?>
                      <option><?php echo $i ?></option>
                      <?php } ?>

                    </select>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>

  <div class="modal fade" id="filter_periode">
    <form action="<?php echo base_url('user/master/approval/pengeluaran') ?>" method='get' id="form_catat_order">  
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Filter</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                    <label>Tanggal Awal</label>
                    <input type="hidden" name="filter" value="periode">
                    <input type="date" name="tgl_awal" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Tanggal Akhir</label>
                    <input type="date" name="tgl_akhir" class="form-control" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info">Filter</button>
              </div>
            </div>
          </div>
    </form>
  </div>






<script type="">
  
function detail(id_pengeluaran)
  {
    $('#detail_pengeluaran').modal('show');
    $('#detail_pengeluaran').find('#id_pengeluaran').val(id_pengeluaran);

    var status = ['Menunggu Verifikasi','Telah Di Verifikasi','Dibatalkan'];
    var approval = ['Pengeluaran Ditolak','Pengeluaran Di ACC'];
      $.ajax(
            {
              url     : baseUrl('/user/kassa/pengeluaran/detail_transaksi'),
              type    : 'POST',
              dataType: 'JSON',
              data    : { 
                id_pengeluaran : id_pengeluaran,
                
              },
              success : function(data)
              {
                console.log(data);
                $('#detail_pengeluaran').find('#waktu').html(data.transaksi.tgl_transaksi);
                $('#detail_pengeluaran').find('#keterangan').html(data.transaksi.keterangan);
                $('#detail_pengeluaran').find('#besar_pengeluaran').html('Rp. ' + number_format(data.transaksi.besar_pengeluaran));
                $('#detail_pengeluaran').find('#kasir').html(data.transaksi.kasir);
                $('#detail_pengeluaran').find('#status').html(status[data.transaksi.status]);
                if (data.transaksi.status==0) {
                  $('#detail_pengeluaran').find('#form_approval').show();
                  $('#detail_pengeluaran').find('#hasil_approval').hide();

                }
                else if (data.transaksi.status==2) {
                    $('#detail_pengeluaran').find('#form_approval').hide();
                  $('#detail_pengeluaran').find('#form_hasil_approval').hide();

                }else{
                  $('#detail_pengeluaran').find('#form_approval').hide();
                  $('#detail_pengeluaran').find('#hasil_approval').show();
                  $('#detail_pengeluaran').find('#show_hasil_approval').html(approval[data.transaksi.approval] + '<br>' + data.transaksi.keterangan_approval);

                }
                $('#detail_pengeluaran').find('#bukti').html('<img src="'+baseUrl('file/pengeluaran/')+ data.transaksi.file + '" width="100%">');
                // window.location.href=baseUrl('user/kassa/pengeluaran');
              },
              error : function(){
                alert('ee');
                
              }
            });
  }

  
  
function statistika(jenis)
  {
    // $('#statistika').modal('show');

   
      // $.ajax(
      //       {
      //         url     : baseUrl('/user/kassa/pengeluaran/detail_transaksi'),
      //         type    : 'POST',
      //         dataType: 'JSON',
      //         data    : { 
      //           id_pengeluaran : id_pengeluaran,
                
      //         },
      //         success : function(data)
      //         {
      //           console.log(data);
      //           $('#detail_pengeluaran').find('#waktu').html(data.transaksi.tgl_transaksi);
      //           $('#detail_pengeluaran').find('#keterangan').html(data.transaksi.keterangan);
      //           $('#detail_pengeluaran').find('#besar_pengeluaran').html('Rp. ' + number_format(data.transaksi.besar_pengeluaran));
      //           $('#detail_pengeluaran').find('#kasir').html(data.transaksi.kasir);
      //           $('#detail_pengeluaran').find('#status').html(status[data.transaksi.status]);
      //           if (data.transaksi.status==0) {
      //             $('#detail_pengeluaran').find('#form_approval').show();
      //             $('#detail_pengeluaran').find('#hasil_approval').hide();

      //           }
      //           if (data.transaksi.status==2) {
      //               $('#detail_pengeluaran').find('#form_approval').hide();
      //             $('#detail_pengeluaran').find('#hasil_approval').hide();

      //           }else{
      //             $('#detail_pengeluaran').find('#form_approval').hide();
      //             $('#detail_pengeluaran').find('#hasil_approval').show();
      //             $('#detail_pengeluaran').find('#show_hasil_approval').html(approval[data.transaksi.approval] + '<br>' + data.transaksi.keterangan_approval);

      //           }
      //           $('#detail_pengeluaran').find('#bukti').html('<img src="'+baseUrl('file/pengeluaran/')+ data.transaksi.file + '" width="100%">');
      //           // window.location.href=baseUrl('user/kassa/pengeluaran');
      //         },
      //         error : function(){
      //           alert('ee');
                
      //         }
      //       });
  }

  
function hapus(id_kartu, file)
  {
    Swal.fire({
        title: 'Warning',
        html: 'Hapus Kartu.?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aktifkan',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
            $.ajax(
            {
              url     : baseUrl('/user/kassa/pengeluaran/hapus'),
              type    : 'POST',
              data    : { 
                id_kartu : id_kartu,
                file : file,
                
              },
              success : function(data)
              {
                // alert('ew');
                window.location.href=baseUrl('user/kassa/pengeluaran');
              },
              error : function(){
                alert('ee');
                
              }
            });
      

        
        }
      }); 
  }


</script>