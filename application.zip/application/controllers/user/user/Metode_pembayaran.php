<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Metode_pembayaran extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
    }



	public function index()
	{
		$data['judul'] = 'Metode Pembayaran';
        $q = $this->db->query("SELECT  id_metode_pembayaran,metode_pembayaran,status from metode_pembayaran ")->result_array();
		$data['metode_pembayaran'] = '<a href="'.base_url('user/admin/dokumen_publik/tambah').'" class="btn btn-info btn-xs">Tambah Dokumen</a>';
		$this->template->load('template/user_adminlte','user/admin/metode_pembayaran/data_metode_pembayaran', $data);

		// $this->load->view('template/user_adminlte');
	}

	public function tambah()
	{
		$data['judul'] = 'Tambah Data Dokumen Publik';
		$data['top_button'] = '<a href="'.base_url('user/admin/dokumen_publik').'" class="btn btn-info btn-xs">Kembali</a>';
		$this->template->load('template/user_adminlte','user/admin/dokumen_publik/tambah', $data);

		// $this->load->view('template/user_adminlte');
	}

	public function edit($id)
	{
		$id_dokumen_publik = bap_crypt($id, 'D');
		$data['judul'] = 'Edit Data dokumen_publik';
		$data['dokumen_publik'] = $this->db->query("SELECT * from dokumen_publik where id_dokumen_publik='$id_dokumen_publik'")->row_array();
		$data['top_button'] = '<a href="'.base_url('user/admin/dokumen_publik').'" class="btn btn-info btn-xs">Kembali</a>';
		$this->template->load('template/user_adminlte','user/admin/dokumen_publik/edit', $data);

		// $this->load->view('template/user_adminlte');
	}


    public function download($id)
    {
        $id_dokumen_publik = bap_crypt($id, 'D');
        $dokumen_publik = $this->db->query("SELECT * from dokumen_publik where id_dokumen_publik='$id_dokumen_publik'")->row_array();
        $file = $dokumen_publik['nama_file'];
        $pecah = explode('.', $file);
        $extensi = end($pecah);
        $download =  'file/dokumen_publik/'.$file;
        echo $download;
        // force_download($download,NULL);

        force_download($dokumen_publik['judul_file'].'.'.$extensi, file_get_contents($download));
        // $this->load->view('template/user_adminlte');
    }



    public function simpan_dokumen_publik(){
        $config['upload_path']          = './file/dokumen_publik';
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $namafile = $_FILES['berkas']['name'] ;
        $pecah = explode(".", $namafile);
        $extensi = end($pecah);
        $new_file_name=date("Ymdhi").'.'.$extensi;
        $config['file_name']            = $new_file_name;
            $config['max_size']         = '10000';
 
        $this->load->library('upload', $config);
    
        if ( ! $this->upload->do_upload('berkas')){
            if ($this->upload->display_errors()) {
                $pesan_ERROR = $this->upload->display_errors();
            }else{
                $pesan_ERROR = '';

            }
                $error = 1;
            $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;
            $warna = 'alert alert-danger';
            $redirect = 'user/admin/dokumen_publik/tambah';
        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong>";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/admin/dokumen_publik/';

            $data_insert = [
                'judul_file'=>$this->input->post('judul'),
                'nama_file'=>$new_file_name,
                'keterangan_file'=>$this->input->post('ket'),
                'tgl_upload'=>date('Y-m-d H:i:s'),
                'hit'=>0,
                'input_by'=>id_user(),
            ];
            $this->db->insert('dokumen_publik', $data_insert);
        }
        $this->session->set_flashdata('pesan','<div class="alert alert-secondary dark alert-dismissible fade show" role="alert"> '.$pesan.'
                      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close" data-bs-original-title="" title=""></button>
                    </div>');
            redirect($redirect);

    }



    public function simpanedit_dokumen_publik(){
        $config['upload_path']          = './file/dokumen_publik';
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $new_file_name=date("Ymdhi");
        // $config['file_name']            = $new_file_name;
        $namafile = $_FILES['berkas']['name'] ;
            $config['max_size']         = '10000';
        $id_dokumen_publik = $this->input->post('id_dokumen_publik');
        $this->load->library('upload', $config);
        $where  = [
            'id_dokumen_publik'=>$this->input->post('id_dokumen_publik'),
          
        ];

    
        if ( ! $this->upload->do_upload('berkas')){
            if ($nama_file=='') {
                $data_insert = [
                    'judul_file'=>$this->input->post('judul'),
                    'keterangan_file'=>$this->input->post('ket'),
                    'tgl_upload'=>date('Y-m-d H:i:s'),
                    'hit'=>0,
                    'input_by'=>id_user(),
                ];
                $error = 0;
              
            }else{
                if ($this->upload->display_errors()) {
                    $pesan_ERROR = $this->upload->display_errors();
                    $error = 1;
                    $warna = 'alert alert-danger';
                    $data_insert = [
                        'judul_file'=>$this->input->post('judul'),
                        'keterangan_file'=>$this->input->post('ket'),
                        'tgl_upload'=>date('Y-m-d H:i:s'),
                        'hit'=>0,
                        'input_by'=>id_user(),
                    ];
                }else{
                    $pesan_ERROR = '';
                    $error = 0;
                    $warna = 'alert alert-success';
                    $data_insert = [
                        'judul_file'=>$this->input->post('judul'),
                        'nama_file'=>$namafile,
                        'keterangan_file'=>$this->input->post('ket'),
                        'tgl_upload'=>date('Y-m-d H:i:s'),
                        'hit'=>0,
                        'input_by'=>id_user(),
                    ];

                }
                $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;

            }


            if ($error>0) {
                $redirect = 'user/admin/dokumen_publik/edit/'.$id_dokumen_publik;
                # code...
            }else{
                $redirect = 'user/admin/dokumen_publik/';

            }
        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong>";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/admin/dokumen_publik/';

            $data_insert = [
                'judul_file'=>$this->input->post('judul'),
                'nama_file'=>$namafile,
                'keterangan_file'=>$this->input->post('ket'),
                'tgl_upload'=>date('Y-m-d H:i:s'),
                'hit'=>0,
                'input_by'=>id_user(),
            ];
        }
            $this->db->update('dokumen_publik', $data_insert, $where);
        $this->session->set_flashdata('pesan','<div class="alert alert-secondary dark alert-dismissible fade show" role="alert"> '.$pesan.'
                      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close" data-bs-original-title="" title=""></button>
                    </div>');
            redirect($redirect);

    }




    public function dt_dokumen_publik()
    {
        
           
                $tabel = 'dokumen_publik';
                $where          = [];
            
            $column_order   = ['tgl_upload'];
            $column_search  = ['judul_file'];
            $order          = ['tgl_upload' => 'DESC'];
            $list           = $this->datatables_model->get_datatables($tabel,$column_order,$column_search,$order,$where);
            $data           = [];
            $no             = $_POST['start'];
                $nomor = $no;
            foreach ($list as $lists)
            {
                $nomor++;
                $row    = [];
                $row[]  = $nomor;
                $row[]  = $lists->judul_file;
                $row[]  = $lists->keterangan_file;
                $row[]  = $lists->tgl_upload;
                $row[]  = '<a href="javascript:void(0)" class="btn btn-info btn-xs"  title="Hapus '.$lists->judul_file.'" onclick="hapus_dokumen_publik(`'.$lists->id_dokumen_publik.'`,`'.$lists->judul_file.'`)"><i class="fa fa-trash"></i> Hapus</a> '.
                '<a href="'.base_url('user/admin/dokumen_publik/edit/'.bap_crypt($lists->id_dokumen_publik)).'" class="btn btn-info btn-xs"  title="Edit '.$lists->judul_file.'"><i class="fa fa-edit"></i> Edit</a>'.
                '<a href="'.base_url('user/admin/dokumen_publik/download/'.bap_crypt($lists->id_dokumen_publik)).'" class="btn btn-info btn-xs"  title="Download '.$lists->judul_file.'"><i class="fa fa-download"></i> Download</a>';
                
              

                $data[] = $row;
            }

            $output = [
                        "draw"              => $_POST['draw'],
                        "recordsTotal"      => $this->datatables_model->count_all($tabel,$where),
                        "recordsFiltered"   => $this->datatables_model->count_filtered($tabel,$column_order,$column_search,$order,$where),
                        "data"              => $data,
                      ];

            echo json_encode($output);
        
    }



    public function hapus_dokumen_publik()
    {
        
            $output = [
                'status'    => false,
                // 'data'      => [],
               
            ];

            $id_dokumen_publik = $this->input->post('id_dokumen_publik');
            $q = $this->db->query("DELETE from dokumen_publik where id_dokumen_publik='$id_dokumen_publik'");

            $output['status'] = true;


            echo json_encode($output);
        
    }


}
