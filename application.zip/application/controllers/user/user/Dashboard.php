<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
    }



	public function index()
	{
		$data['judul'] = 'Dashboard';
         $id_user = $this->session->userdata('id_user');
         $user = $this->db->query("SELECT * from user u left join hak_akses ha on u.id_hak_akses = ha.id_hak_akses where u.id_user = '$id_user'")->row_array();
$data['user'] = $user;
		$this->template->load('template/user_adminlte','user/user/dashboard/dashboard', $data);
        // $this->template->load('template/user','user/admin/dashboard/dashboard', $data);

		// $this->load->view('template/admin');
	}

	
}
