<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class berita extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
    }



	public function index()
	{
		$data['judul'] = 'Berita';
		$data['top_button'] = '<a href="'.base_url('user/admin/berita/tambah').'" class="btn btn-info btn-xs">Tambah Berita</a>';
		$this->template->load('template/admin','user/admin/berita/berita', $data);

		// $this->load->view('template/admin');
	}

	public function tambah()
	{
		$data['judul'] = 'Tambah Berita';
        $data['kategori'] = $this->db->get('kategori')->result_array();
		$data['top_button'] = '<a href="'.base_url('user/admin/berita').'" class="btn btn-info btn-xs">Kembali</a>';
		$this->template->load('template/admin','user/admin/berita/tambah', $data);

		// $this->load->view('template/admin');
	}

	public function edit($id)
	{
		$id_berita = bap_crypt($id, 'D');
		$data['judul'] = 'Edit Berita';
        $data['kategori'] = $this->db->get('kategori')->result_array();
		$data['berita'] = $this->db->query("SELECT * from berita where id_berita='$id_berita'")->row_array();
		$data['top_button'] = '<a href="'.base_url('user/admin/berita').'" class="btn btn-info btn-xs">Kembali</a>';
		$this->template->load('template/admin','user/admin/berita/edit', $data);

		// $this->load->view('template/admin');
	}


    public function baca($id)
    {
        $id_berita = bap_crypt($id, 'D');
        $berita = $this->db->query("SELECT * from berita where id_berita='$id_berita'")->row_array();
        $data['berita'] = $berita;
        $data['judul'] =$berita['judul_berita'];
        $data['top_button'] = '<a href="'.base_url('user/admin/berita').'" class="btn btn-info btn-xs">Kembali</a>';
        $this->template->load('template/admin','user/admin/berita/baca', $data);

        // $this->load->view('template/admin');
    }


   



    public function simpan_berita(){
        $config['upload_path']          = './file/berita';
        $config['allowed_types']        = 'gif|jpg|png';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $namafile = $_FILES['berkas']['name'] ;
        $pecah = explode(".", $namafile);
        $extensi = end($pecah);
        $new_file_name=date("Ymdhi").'.'.$extensi;
        $config['file_name']            = $new_file_name;
            $config['max_size']         = '10000';
 
        $this->load->library('upload', $config);
    
        if ( ! $this->upload->do_upload('berkas')){
            if ($this->upload->display_errors()) {
                $pesan_ERROR = $this->upload->display_errors();
            }else{
                $pesan_ERROR = '';

            }
                $error = 1;
            $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;
            $warna = 'alert alert-danger';
            $redirect = 'user/admin/berita/tambah';
        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong>";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/admin/berita/';

            $data_insert = [
                'kategori'=>$this->input->post('kategori'),
                'judul_berita'=>$this->input->post('judul'),
                'slug_berita'=>slug($this->input->post('judul')),
                'isi_berita'=>$this->input->post('isi'),
                'bagian'=>$this->input->post('bagian'),
                'tgl_berita'=>$this->input->post('tgl'),
                'gambar_berita'=>$new_file_name,
                'hit'=>0,
                'aktif'=>$this->input->post('aktif'),
                'headline'=>$this->input->post('carousel'),
                'input_by'=>id_user(),
                'last_update '=>timestamp(),
              
            ];
            $this->db->insert('berita', $data_insert);
        }
        $this->session->set_flashdata('pesan','<div class="alert alert-secondary dark alert-dismissible fade show" role="alert"> '.$pesan.'
                      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close" data-bs-original-title="" title=""></button>
                    </div>');
            redirect($redirect);

    }



    public function simpanedit_berita(){
        $config['upload_path']          = './file/berita';
        $config['allowed_types']        = 'gif|jpg|png"jpeg';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $new_file_name=date("Ymdhi");
        // $config['file_name']            = $new_file_name;
        $namafile = $_FILES['berkas']['name'] ;
            $config['max_size']         = '10000';
        $id_berita = $this->input->post('id_berita');
        $this->load->library('upload', $config);
        $where  = [
            'id_berita'=>$this->input->post('id'),
          
        ];

    
        if ( ! $this->upload->do_upload('berkas')){
            if ($nama_file=='') {
                 $data_insert = [
                    'kategori'=>$this->input->post('kategori'),
                    'judul_berita'=>$this->input->post('judul'),
                    'slug_berita'=>slug($this->input->post('judul')),
                    'isi_berita'=>$this->input->post('isi'),
                    'bagian'=>$this->input->post('bagian'),
                    'tgl_berita'=>$this->input->post('tgl'),
                    'aktif'=>$this->input->post('aktif'),
                    'headline'=>$this->input->post('carousel'),
                    'input_by'=>id_user(),
                    'last_update '=>timestamp(),
                  
                ];
                $error = 0;
              
            }else{
                if ($this->upload->display_errors()) {
                    $pesan_ERROR = $this->upload->display_errors();
                    $error = 1;
                    $warna = 'alert alert-danger';
                      $data_insert = [
                        'kategori'=>$this->input->post('kategori'),
                        'judul_berita'=>$this->input->post('judul'),
                        'slug_berita'=>slug($this->input->post('judul')),
                        'isi_berita'=>$this->input->post('isi'),
                        'bagian'=>$this->input->post('bagian'),
                        'tgl_berita'=>$this->input->post('tgl'),
                        'aktif'=>$this->input->post('aktif'),
                        'headline'=>$this->input->post('carousel'),
                        'input_by'=>id_user(),
                        'last_update '=>timestamp(),
                      
                    ];
                }else{
                    $pesan_ERROR = '';
                    $error = 0;
                    $warna = 'alert alert-success';
                     $data_insert = [
                        'kategori'=>$this->input->post('kategori'),
                        'judul_berita'=>$this->input->post('judul'),
                        'slug_berita'=>slug($this->input->post('judul')),
                        'isi_berita'=>$this->input->post('isi'),
                        'bagian'=>$this->input->post('bagian'),
                        'tgl_berita'=>$this->input->post('tgl'),
                        'aktif'=>$this->input->post('aktif'),
                        'headline'=>$this->input->post('carousel'),
                        'input_by'=>id_user(),
                        'last_update '=>timestamp(),
                      
                    ];

                }
                $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;

            }


            if ($error>0) {
                $redirect = 'user/admin/berita/edit/'.$id_berita;
                # code...
            }else{
                $redirect = 'user/admin/berita/';

            }
        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong>";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/admin/berita/';

             $data_insert = [
                'kategori'=>$this->input->post('kategori'),
                'judul_berita'=>$this->input->post('judul'),
                'slug_berita'=>slug($this->input->post('judul')),
                'isi_berita'=>$this->input->post('isi'),
                'bagian'=>$this->input->post('bagian'),
                'tgl_berita'=>$this->input->post('tgl'),
                'gambar_berita'=>$new_file_name,
                'hit'=>0,
                'aktif'=>$this->input->post('aktif'),
                'headline'=>$this->input->post('carousel'),
                'input_by'=>id_user(),
                'last_update '=>timestamp(),
              
            ];
        }
            $this->db->update('berita', $data_insert, $where);
        $this->session->set_flashdata('pesan','<div class="alert alert-secondary dark alert-dismissible fade show" role="alert"> '.$pesan.'
                      <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close" data-bs-original-title="" title=""></button>
                    </div>');
            redirect($redirect);

    }




    public function dt_berita()
    {
        
           
                $tabel = 'berita';
                $where          = [];
            
            $column_order   = ['tgl_berita'];
            $column_search  = ['judul_berita'];
            $order          = ['tgl_berita' => 'DESC'];
            $list           = $this->datatables_model->get_datatables($tabel,$column_order,$column_search,$order,$where);
            $data           = [];
            $no             = $_POST['start'];
                $nomor = $no;
            foreach ($list as $lists)
            {
                $nomor++;
                $row    = [];

                $tanda_carousel = $lists->headline =='Ya' ? '<br><a href="javascript:void(0)"   title="'.$lists->judul_berita.'" class="btn btn-outline-info btn-xs">Headline</a>' : '';
                $row[]  = $nomor;
                $row[]  = '<img src="'.base_url().'file/berita/'.$lists->gambar_berita.'" width="100px">';
                $row[]  =  '<a href="'.base_url('user/admin/berita/baca/'.bap_crypt($lists->id_berita)).'"   title="Baca '.$lists->judul_berita.'">'.$lists->judul_berita.'</a> '.$tanda_carousel;
                $row[]  = $lists->kategori;
                $row[]  = @bagian($lists->bagian);
                $row[]  = $lists->tgl_berita;
                $row[]  = $lists->hit;
                $row[]  = '<a href="javascript:void(0)" class="btn btn-info btn-xs"  title="Hapus '.$lists->judul_berita.'" onclick="hapus_berita(`'.$lists->id_berita.'`,`'.$lists->judul_berita.'`)"><i class="fa fa-trash"></i> Hapus</a> '.
                '<a href="'.base_url('user/admin/berita/edit/'.bap_crypt($lists->id_berita)).'" class="btn btn-info btn-xs"  title="Edit '.$lists->judul_berita.'"><i class="fa fa-edit"></i> Edit</a>';
                
              

                $data[] = $row;
            }

            $output = [
                        "draw"              => $_POST['draw'],
                        "recordsTotal"      => $this->datatables_model->count_all($tabel,$where),
                        "recordsFiltered"   => $this->datatables_model->count_filtered($tabel,$column_order,$column_search,$order,$where),
                        "data"              => $data,
                      ];

            echo json_encode($output);
        
    }



    public function hapus_berita()
    {
        
            $output = [
                'status'    => false,
                // 'data'      => [],
               
            ];

            $id_berita = $this->input->post('id_berita');
            $q = $this->db->query("DELETE from berita where id_berita='$id_berita'");

            $output['status'] = true;


            echo json_encode($output);
        
    }


}
