<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kelas extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses=='2') {
            redirect('auth/login/kick');
        }
    }




    public function index()
    {
        $data['judul'] = 'Laporan - Kelas - Rekap Kelas';
          $data['breadchumb'] = ' 
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>



            ';

        $filter = $this->input->get('filter');
        $kelas = $this->input->get('kelas');
        $detail_kelas = $this->input->get('detail_kelas');

        $q_kelas = $this->db->query("SELECT id_kelas, kelas from kelas where status='1'")->result_array();
        $kumpul_kelas = [];
        foreach ($q_kelas as $k => $v) {
            $kumpul_kelas[$v['id_kelas']] = $v['kelas'];
        }
        if ($this->input->get('filter')) {
            if ($filter=='harian') {
                $tgl_daftar = $this->input->get('tgl');
                $q_filter = "where jenis_keanggotaan='Paket Kelas' and tgl_daftar='$tgl_daftar'";
                $caption = "tanggal ".$tgl_daftar;

            }
            else if ($filter=='bulanan') {
                $bulan = $this->input->get('bulan');
                $tahun = $this->input->get('tahun');
                $q_filter = "where jenis_keanggotaan='Paket Kelas' and month(tgl_daftar)='$bulan' and year(tgl_daftar)='$tahun'";
                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $caption = "bulan ".bulan_global(intval($bulan))." ".$tahun;
                # code...
            }
            else if ($filter=='tahunan') {
                $tahun = $this->input->get('tahun');
                $q_filter = "where jenis_keanggotaan='Paket Kelas' and  year(tgl_daftar)='$tahun'";
                $data['tahun'] = $tahun;
                $caption = "tahun  ".$tahun;
                # code...
            }
            else if ($filter=='periode') {
                $tgl_awal = $this->input->get('tgl_awal');
                $tgl_akhir = $this->input->get('tgl_akhir');
                $q_filter = "where jenis_keanggotaan='Paket Kelas' and tgl_daftar between '$tgl_awal' and '$tgl_akhir' ";

                $caption = "tanggal ".$tgl_awal.' s/d '.$tgl_akhir;
                # code...
            }
            else if ($filter=='semua') {
                $q_filter = "";

                $caption = "keseluruhan ";
                # code...
            }
        }else{
            $tgls = date('Y-m-d');
                $q_filter = "where jenis_keanggotaan='Paket Kelas' and tgl_daftar='$tgls'";

                $caption = "hari ini <br>".$tgls;

        }



        if ($kelas=='semua') {
            $q_filter_kelas = "";
            $caption_jenis_member = 'Semua Kelas';
            # code...
        }
       else{
            if ($detail_kelas=='') {
                $caption_jenis_member = "Kelas";
                $q_filter_kelas = "and km.id_kelas='$kelas'";
                # code...
            }else{
                $caption_jenis_member = "Kelas";
                $q_filter_kelas = "and km.id_kelas='$kelas' and km.id_detail_kelas='$detail_kelas'";

            }

        }


        
            // $thns = 2023;
            // $filter = "where  year(tgl_daftar)='$thns'";        
        $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.id_transaksi_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
            tm.jenis_potongan_harga, tm.id_voucher, tm.id_diskon,
            m.nama, m.no_hp, 
            k.kelas, dk.biaya, dk.nama_paket_kelas, 
            d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
            v.jenis as jenis_voucher, v.besar_voucher, v.nama_voucher,
            u.nama as kasir
         from transaksi_member tm 
         left join keanggotaan_member km on tm.id_transaksi_member = km.id_transaksi_member
         left join member m on km.id_member = m.id_member
         left join kelas k on km.id_kelas = k.id_kelas
         left join detail_kelas dk on km.id_detail_kelas = dk.id_detail_kelas
         left join diskon d on tm.id_diskon = d.id_diskon 
         left join voucher v on tm.id_voucher = v.id_voucher 
         left join user u on tm.id_user = u.id_user

                $q_filter 
                $q_filter_kelas
                ")->result_array();
        $data['filter'] = $filter;
        $data['member'] = $member;
        $data['list_kelas'] = $q_kelas;
        $data['caption'] = "Laporan ".$caption_jenis_member .' '.$caption;
        $page = 'user/kassa/laporan/kelas/lap_kelas';
        $this->template->load('template/user_adminlte',$page, $data);

        // $this->load->view('template/user_adminlte');
    }






    public function diskon()
    {
        $data['judul'] = 'Laporan - Diskon - Rekap Diskon Member';
          $data['breadchumb'] = ' 
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>



            ';

        $filter = $this->input->get('filter');

        if ($this->input->get('filter')) {
            if ($filter=='harian') {
                $tgl_daftar = $this->input->get('tgl');
                $q_filter = "where km.id_diskon!='' and tgl_daftar='$tgl_daftar'";
                $caption = "Laporan diskon member tanggal ".$tgl_daftar;

            }
            else if ($filter=='bulanan') {
                $bulan = $this->input->get('bulan');
                $tahun = $this->input->get('tahun');
                $q_filter = "where km.id_diskon!='' and month(tgl_daftar)='$bulan' and year(tgl_daftar)='$tahun'";
                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $caption = "Laporan diskon member bulan ".bulan_global(intval($bulan))." ".$tahun;
                # code...
            }
            else if ($filter=='tahunan') {
                $tahun = $this->input->get('tahun');
                $q_filter = "where km.id_diskon!='' and  year(tgl_daftar)='$tahun'";
                $data['tahun'] = $tahun;
                $caption = "Laporan diskon member tahun  ".$tahun;
                # code...
            }
            else if ($filter=='periode') {
                $tgl_awal = $this->input->get('tgl_awal');
                $tgl_akhir = $this->input->get('tgl_akhir');
                $q_filter = "where km.id_diskon!='' and tgl_daftar between '$tgl_awal' and '$tgl_akhir' ";

                $caption = "Laporan diskon member tanggal ".$tgl_awal.' s/d '.$tgl_akhir;
                # code...
            }
            else if ($filter=='semua') {
                $q_filter = "";

                $caption = "Laporan diskon member keseluruhan ";
                # code...
            }
        }else{
            $thns = date('Y');
            $q_filter = "where km.id_diskon!='' and year(tgl_daftar)='$thns'";

                $caption = "Laporan diskon member tahun ".$thns;

        }



        
            // $thns = 2023;
            // $filter = "where  year(tgl_daftar)='$thns'";        
        $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
            m.nama, m.no_hp, 
            jm.jenis_member, jm.biaya, 
            d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon
         from keanggotaan_member km
         left join member m on km.id_member = m.id_member
         left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
         left join diskon d on km.id_diskon = d.id_diskon 

                $q_filter
                ")->result_array();
        $data['filter'] = $filter;
        $data['member'] = $member;
        $data['caption'] = $caption;
        $page = 'user/kassa/laporan/member/lap_diskon_member';
        $this->template->load('template/user_adminlte',$page, $data);

        // $this->load->view('template/user_adminlte');
    }







  public function export_bulanan(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    // $fill_program = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'f0cdf5')
    //     )
    // );
    // $fill_kegiatan = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'FF99CC')
    //     )
    // );




// // Untuk judulnya
//     $excel->getActiveSheet()->mergeCells('A1:AR1');
//     $excel->getActiveSheet()->mergeCells('A2:AR2');
//     $excel->getActiveSheet()->mergeCells('A3:AR3');


    $bulan_order = $this->input->get('bulan');
    $tahun_order = $this->input->get('tahun');
    $caption_judul = "Laporan member bulan ".bulan_global(intval($bulan_order))." ".$tahun_order;

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Nama");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "No Hp");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "Jenis paket");
    $excel->setActiveSheetIndex(0)->setCellValue('E3', "Biaya");
    $excel->setActiveSheetIndex(0)->setCellValue('F3', "Diskon");
    $excel->setActiveSheetIndex(0)->setCellValue('G3', "Potongan Diskon");
    $excel->setActiveSheetIndex(0)->setCellValue('H3', "Total");
    $excel->setActiveSheetIndex(0)->setCellValue('I3', "Kasir");











    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
    $excel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('G')->setWidth(17);
    $excel->getActiveSheet()->getColumnDimension('H')->setWidth(17);
    $excel->getActiveSheet()->getColumnDimension('I')->setWidth(15);




    $excel->setActiveSheetIndex(0)->setCellValue('A4', "1");
    $excel->setActiveSheetIndex(0)->setCellValue('B4', "2");
    $excel->setActiveSheetIndex(0)->setCellValue('C4', "3");
    $excel->setActiveSheetIndex(0)->setCellValue('D4', "4");
    $excel->setActiveSheetIndex(0)->setCellValue('E4', "5");
    $excel->setActiveSheetIndex(0)->setCellValue('F4', "6");
    $excel->setActiveSheetIndex(0)->setCellValue('G4', "7");
    $excel->setActiveSheetIndex(0)->setCellValue('H4', "8=5-7");
    $excel->setActiveSheetIndex(0)->setCellValue('I4', "9");

    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I3')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('B3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('G3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('I3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I4')->applyFromArray($border);







    $q_filter = "where month(tgl_daftar)='$bulan_order' and year(tgl_daftar)='$tahun_order'";
    $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
            m.nama, m.no_hp, 
            jm.jenis_member, jm.biaya, 
            d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
                 u.nama as kasir
         from transaksi_member tm 
         left join keanggotaan_member km on tm.id_transaksi_member = km.id_transaksi_member

         left join member m on km.id_member = m.id_member
         left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
         left join diskon d on km.id_diskon = d.id_diskon 

         left join user u on tm.id_user = u.id_user

                $q_filter
                ")->result_array();



    $row_start = 5;
    $row_data_terakhir = 5;

     $total_biaya = 0 ;
            $total_diskon = 0 ;
            $total_transaksi = 0 ;


  foreach ($member as $k => $v) {
        $row_data_terakhir +=1;

        $baris = $row_start + $k;
        $no = $k+1;


         $biaya = $v['id_jenis_member'] == 'Pendaftaran' ? 100000 : $v['biaya'];
          $jenis_member = $v['id_jenis_member'] == 'Pendaftaran' ? 'Registrasi' : $v['jenis_member'];
          if ($v['jenis_diskon']=='Persentase') {
              $potongan = ($v['besar_diskon'] / 100) * $v['biaya'];
              $show_potongan = $v['besar_diskon'].'% ['.number_format($potongan).']';
            }else{
              $potongan = $v['besar_diskon'] ;
              $show_potongan = $potongan;

            }

            $total = $biaya - $potongan ;




            $total_biaya += $biaya;
            $total_diskon += $potongan;
            $total_transaksi += $total;

        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris, $no);
        if ($v['id_jenis_member']==1) {
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['id_member']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, "-");
        }else{
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['nama']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, $v['no_hp']);
        }
        $excel->setActiveSheetIndex(0)->setCellValue('D'.$baris, $jenis_member);
        $excel->setActiveSheetIndex(0)->setCellValue('E'.$baris, $biaya);
        $excel->setActiveSheetIndex(0)->setCellValue('F'.$baris, $v['nama_diskon']);
        $excel->setActiveSheetIndex(0)->setCellValue('G'.$baris, $show_potongan);
        $excel->setActiveSheetIndex(0)->setCellValue('H'.$baris, $total);
        $excel->setActiveSheetIndex(0)->setCellValue('I'.$baris, $v['kasir']);



        $excel->getActiveSheet()->getStyle('E'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('G'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('H'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);




    $excel->getActiveSheet()->getStyle('A'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I'.$baris)->applyFromArray($border);

    }

    $excel->getActiveSheet()->getStyle('A'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I'.$row_data_terakhir)->applyFromArray($border);

        $excel->setActiveSheetIndex(0)->setCellValue('A'.$row_data_terakhir, "Jumlah");
        $excel->setActiveSheetIndex(0)->setCellValue('E'.$row_data_terakhir, $total_biaya);
        $excel->setActiveSheetIndex(0)->setCellValue('G'.$row_data_terakhir, $total_diskon);
        $excel->setActiveSheetIndex(0)->setCellValue('H'.$row_data_terakhir, $total_transaksi);


        $excel->getActiveSheet()->getStyle('E'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('G'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('H'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

    $excel->getActiveSheet()->mergeCells('A'.$row_data_terakhir.':D'.$row_data_terakhir);







    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export = $caption_judul.'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }













  public function export_tahunan(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    // $fill_program = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'f0cdf5')
    //     )
    // );
    // $fill_kegiatan = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'FF99CC')
    //     )
    // );




// // Untuk judulnya
//     $excel->getActiveSheet()->mergeCells('A1:AR1');
//     $excel->getActiveSheet()->mergeCells('A2:AR2');
//     $excel->getActiveSheet()->mergeCells('A3:AR3');


    $tahun_order = $this->input->get('tahun');
    $caption_judul = "Laporan member tahun ".$tahun_order;

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Nama");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "No Hp");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "Jenis paket");
    $excel->setActiveSheetIndex(0)->setCellValue('E3', "Biaya");
    $excel->setActiveSheetIndex(0)->setCellValue('F3', "Diskon");
    $excel->setActiveSheetIndex(0)->setCellValue('G3', "Potongan Diskon");
    $excel->setActiveSheetIndex(0)->setCellValue('H3', "Total");
    $excel->setActiveSheetIndex(0)->setCellValue('I3', "Kasir");











    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
    $excel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('G')->setWidth(17);
    $excel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('I')->setWidth(17);




    $excel->setActiveSheetIndex(0)->setCellValue('A4', "1");
    $excel->setActiveSheetIndex(0)->setCellValue('B4', "2");
    $excel->setActiveSheetIndex(0)->setCellValue('C4', "3");
    $excel->setActiveSheetIndex(0)->setCellValue('D4', "4");
    $excel->setActiveSheetIndex(0)->setCellValue('E4', "5");
    $excel->setActiveSheetIndex(0)->setCellValue('F4', "6");
    $excel->setActiveSheetIndex(0)->setCellValue('G4', "7");
    $excel->setActiveSheetIndex(0)->setCellValue('H4', "8=5-7");
    $excel->setActiveSheetIndex(0)->setCellValue('I4', "9");

    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I3')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('B3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('F3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('G3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('H3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('I3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I4')->applyFromArray($border);







    $q_filter = "where year(tgl_daftar)='$tahun_order'";
    $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
            m.nama, m.no_hp, 
            jm.jenis_member, jm.biaya, 
            d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
      

           u.nama as kasir
         from transaksi_member tm 
         left join keanggotaan_member km on tm.id_transaksi_member = km.id_transaksi_member
         left join member m on km.id_member = m.id_member
         left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
         left join diskon d on km.id_diskon = d.id_diskon 
         left join user u on tm.id_user = u.id_user





                $q_filter
                ")->result_array();



    $row_start = 5;
    $row_data_terakhir = 5;

     $total_biaya = 0 ;
            $total_diskon = 0 ;
            $total_transaksi = 0 ;


  foreach ($member as $k => $v) {
        $row_data_terakhir +=1;

        $baris = $row_start + $k;
        $no = $k+1;


         $biaya = $v['id_jenis_member'] == 'Pendaftaran' ? 100000 : $v['biaya'];
          $jenis_member = $v['id_jenis_member'] == 'Pendaftaran' ? 'Registrasi' : $v['jenis_member'];
          if ($v['jenis_diskon']=='Persentase') {
              $potongan = ($v['besar_diskon'] / 100) * $v['biaya'];
              $show_potongan = $v['besar_diskon'].'% ['.number_format($potongan).']';
            }else{
              $potongan = $v['besar_diskon'] ;
              $show_potongan = $potongan;

            }

            $total = $biaya - $potongan ;




            $total_biaya += $biaya;
            $total_diskon += $potongan;
            $total_transaksi += $total;

        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris, $no);

        if ($v['id_jenis_member']==1) {
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['id_member']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, "-");
        }else{
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['nama']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, $v['no_hp']);
        }
        $excel->setActiveSheetIndex(0)->setCellValue('D'.$baris, $jenis_member);
        $excel->setActiveSheetIndex(0)->setCellValue('E'.$baris, $biaya);
        $excel->setActiveSheetIndex(0)->setCellValue('F'.$baris, $v['nama_diskon']);
        $excel->setActiveSheetIndex(0)->setCellValue('G'.$baris, $show_potongan);
        $excel->setActiveSheetIndex(0)->setCellValue('H'.$baris, $total);
        $excel->setActiveSheetIndex(0)->setCellValue('I'.$baris, $v['kasir']);



        $excel->getActiveSheet()->getStyle('E'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('G'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('H'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);




    $excel->getActiveSheet()->getStyle('A'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H'.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I'.$baris)->applyFromArray($border);

    }

    $excel->getActiveSheet()->getStyle('A'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('E'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('F'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('G'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('H'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('I'.$row_data_terakhir)->applyFromArray($border);

        $excel->setActiveSheetIndex(0)->setCellValue('A'.$row_data_terakhir, "Jumlah");
        $excel->setActiveSheetIndex(0)->setCellValue('E'.$row_data_terakhir, $total_biaya);
        $excel->setActiveSheetIndex(0)->setCellValue('G'.$row_data_terakhir, $total_diskon);
        $excel->setActiveSheetIndex(0)->setCellValue('H'.$row_data_terakhir, $total_transaksi);


        $excel->getActiveSheet()->getStyle('E'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('G'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        $excel->getActiveSheet()->getStyle('H'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

    $excel->getActiveSheet()->mergeCells('A'.$row_data_terakhir.':D'.$row_data_terakhir);







    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export = $caption_judul.'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }












function numberToColumnName($number){
    $abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $abc_len = strlen($abc);

    $result_len = 1; // how much characters the column's name will have
    $pow = 0;
    while( ( $pow += pow($abc_len, $result_len) ) < $number ){
        $result_len++;
    }

    $result = "";
    $next = false;
    // add each character to the result...
    for($i = 1; $i<=$result_len; $i++){
        $index = ($number % $abc_len) - 1; // calculate the module

        // sometimes the index should be decreased by 1
        if( $next || $next = false ){
            $index--;
        }

        // this is the point that will be calculated in the next iteration
        $number = floor($number / strlen($abc));

        // if the index is negative, convert it to positive
        if( $next = ($index < 0) ) {
            $index = $abc_len + $index;
        }

        $result = $abc[$index].$result; // concatenate the letter
    }
    return $result;
}
















}
