<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Grafik extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses=='2') {
            redirect('auth/login/kick');
        }
    }




    public function index()
    {
        $data['judul'] = 'Grafik';
          $data['breadchumb'] = ' 
          
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
        



            ';

        $filter =$this->input->get('filter');

        if ($this->input->get('filter')) {
          if ($filter=='bulanan') {
                $bulan = $this->input->get('bulan');
                $tahun = $this->input->get('tahun');
                $q_filter = "where month(tgl_daftar)='$bulan' and year(tgl_daftar)='$tahun'";
                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $caption = "bulan ".bulan_global(intval($bulan))." ".$tahun; 
                $batas_for = jml_hari_dalam_bulan($bulan, $tahun);

                    if ($bulan>0 && $bulan <10) {
                        $bulan = '0'.$bulan;
                    }else{
                        $bulan = $bulan;

                    }




                  $kumpul_grafik_member = [];
                  $kumpul_grafik_kelas = [];
                  $kumpul_grafik_fnb = [];
                  $kumpul_grafik_souvenir = [];
                  $kumpul_bulan =[];
                for ($i=0; $i < $batas_for ; $i++) { 
                     $tanggal = $i+1;
                    if ($tanggal>0 && $tanggal <10) {
                        $tgl_transaksi = $tahun.'-'.$bulan.'-0'.$tanggal;
                    }else{
                        $tgl_transaksi = $tahun.'-'.$bulan.'-'.$tanggal;

                    }
                    

                           


                           $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.jenis_keanggotaan, km.include_register, km.id_transaksi_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
                                tm.jenis_potongan_harga, tm.id_voucher, tm.id_diskon,
                                jm.jenis_member, jm.biaya, 
                                dk.biaya as biaya_kelas,
                                d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
                                v.jenis as jenis_voucher, v.besar_voucher, v.nama_voucher
                             from transaksi_member tm 
                             left join keanggotaan_member km on tm.id_transaksi_member = km.id_transaksi_member
                             left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
                             left join kelas k on km.id_kelas = k.id_kelas 
                             left join detail_kelas dk on km.id_detail_kelas = dk.id_detail_kelas
                             left join diskon d on tm.id_diskon = d.id_diskon 
                             left join voucher v on tm.id_voucher = v.id_voucher 
                             where  (km.id_jenis_member!='Pendaftaran') and km.tgl_daftar='$tgl_transaksi'
                                 
                                    ")->result_array();
                           $total_transaksi_member =0;
                           $total_transaksi_kelas =0;
                           foreach ($member as $k => $d1) {
                             if ($d1['jenis_keanggotaan']=='Membership') {   
                                $biaya = $d1['include_register'] == 'Ya' ? (100000 + $d1['biaya']) : $d1['biaya'];
                                $member_baru = $d1['include_register'] == 'Ya' ? 1 : 0 ;
                                if ($d1['jenis_potongan_harga']=='diskon') {
                                        if ($d1['jenis_diskon']=='Persentase') {
                                          $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                                          $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                                        }else{
                                          $potongan = $d1['besar_diskon'] ;
                                          $show_potongan = number_format($potongan);

                                        }

                                        $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                                      }else if ($d1['jenis_potongan_harga']=='voucher') {
                                        if ($d1['jenis_voucher']=='Persentase') {
                                          $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                                          $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                                        }else{
                                          $potongan = $d1['besar_voucher'] ;
                                          $show_potongan = number_format($potongan);

                                        }
                                        $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                                      }else{
                                        $potongan =0;
                                        $show_potongan ='';
                                        $caption_potongan = '';
                                      }

                                $total = $biaya - $potongan ;

                               $total_transaksi_member += $total;
                            }else{
                                if ($d1['jenis_potongan_harga']=='diskon') {
                                    if ($d1['jenis_diskon']=='Persentase') {
                                      $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                                      $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                                    }else{
                                      $potongan = $d1['besar_diskon'] ;
                                      $show_potongan = number_format($potongan);
                                    }
                                    $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                                  }else if ($d1['jenis_potongan_harga']=='voucher') {
                                    if ($d1['jenis_voucher']=='Persentase') {
                                      $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                                      $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                                    }else{
                                      $potongan = $d1['besar_voucher'] ;
                                      $show_potongan = number_format($potongan);
                                    }
                                    $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                                  }else{
                                    $potongan =0;
                                    $show_potongan ='';
                                    $caption_potongan = '';
                                  }
                                $total = $d1['biaya_kelas'] - $potongan ;

                               $total_transaksi_kelas += $total;
                            }




                       }




                    $transaksi_fnb = $this->db->query("SELECT sum(total) as total from transaksi_fnb where tgl_transaksi='$tgl_transaksi'")->row_array();
                    $total_transaksi_fnb =$transaksi_fnb['total'] == '' ? 0 : $transaksi_fnb['total']; 
                    
                    $transaksi_sourvenir = $this->db->query("SELECT sum(total) as total from transaksi_sourvenir where tgl_transaksi='$tgl_transaksi'")->row_array();
                    $total_transaksi_sourvenir =$transaksi_sourvenir['total'] == '' ? 0 : $transaksi_sourvenir['total']; 

                    array_push($kumpul_grafik_souvenir, intval($total_transaksi_sourvenir));
                    array_push($kumpul_grafik_fnb, intval($total_transaksi_fnb));
                    array_push($kumpul_grafik_member, intval($total_transaksi_member));
                    array_push($kumpul_grafik_kelas, intval($total_transaksi_kelas));
                    array_push($kumpul_bulan,$tanggal);
                }


                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $kumpul_grafik = [
                    'range' =>$kumpul_bulan,
                    'member' =>$kumpul_grafik_member,
                    'kelas' =>$kumpul_grafik_kelas,
                    'fnb' =>$kumpul_grafik_fnb,
                    'souvenir' =>$kumpul_grafik_souvenir,
                ];
            }
            else{
                $tahun = $this->input->get('tahun');
                $q_filter = "where  year(tgl_daftar)='$tahun'";
                $data['tahun'] = $tahun;

                $batas_for = 12;
                  $kumpul_grafik_member = [];
                  $kumpul_grafik_kelas = [];
                  $kumpul_grafik_fnb = [];
                  $kumpul_grafik_souvenir = [];
                  $kumpul_bulan =[];
                for ($i=0; $i < $batas_for ; $i++) { 
                    $bulan = $i+1;
                    if ($bulan>0 && $bulan <10) {
                        $tgl_transaksi = '0'.$bulan;
                    }else{
                        $tgl_transaksi = $bulan;

                    }
                    $transaksi_member = $this->db->query("SELECT sum(total) as total from transaksi_member where month(tgl_transaksi)='$tgl_transaksi' and year(tgl_transaksi)='$tahun'")->row_array();
                    $total_transaksi_member =$transaksi_member['total'] == '' ? 0 : $transaksi_member['total']; 





                           $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.jenis_keanggotaan, km.include_register, km.id_transaksi_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
                                tm.jenis_potongan_harga, tm.id_voucher, tm.id_diskon,
                                jm.jenis_member, jm.biaya, 
                                dk.biaya as biaya_kelas,
                                d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
                                v.jenis as jenis_voucher, v.besar_voucher, v.nama_voucher
                             from transaksi_member tm 
                             left join keanggotaan_member km on tm.id_transaksi_member = km.id_transaksi_member
                             left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
                             left join kelas k on km.id_kelas = k.id_kelas 
                             left join detail_kelas dk on km.id_detail_kelas = dk.id_detail_kelas
                             left join diskon d on tm.id_diskon = d.id_diskon 
                             left join voucher v on tm.id_voucher = v.id_voucher 
                             where  (km.id_jenis_member!='Pendaftaran') and month(tgl_daftar)='$tgl_transaksi' and year(tgl_daftar)='$tahun'
                                 
                                    ")->result_array();
                           $total_transaksi_member =0;
                           $total_transaksi_kelas =0;
                           foreach ($member as $k => $d1) {
                             if ($d1['jenis_keanggotaan']=='Membership') {   
                                $biaya = $d1['include_register'] == 'Ya' ? (100000 + $d1['biaya']) : $d1['biaya'];
                                $member_baru = $d1['include_register'] == 'Ya' ? 1 : 0 ;
                                if ($d1['jenis_potongan_harga']=='diskon') {
                                        if ($d1['jenis_diskon']=='Persentase') {
                                          $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                                          $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                                        }else{
                                          $potongan = $d1['besar_diskon'] ;
                                          $show_potongan = number_format($potongan);

                                        }

                                        $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                                      }else if ($d1['jenis_potongan_harga']=='voucher') {
                                        if ($d1['jenis_voucher']=='Persentase') {
                                          $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                                          $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                                        }else{
                                          $potongan = $d1['besar_voucher'] ;
                                          $show_potongan = number_format($potongan);

                                        }
                                        $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                                      }else{
                                        $potongan =0;
                                        $show_potongan ='';
                                        $caption_potongan = '';
                                      }

                                $total = $biaya - $potongan ;

                               $total_transaksi_member += $total;
                            }else{
                                if ($d1['jenis_potongan_harga']=='diskon') {
                                    if ($d1['jenis_diskon']=='Persentase') {
                                      $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                                      $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                                    }else{
                                      $potongan = $d1['besar_diskon'] ;
                                      $show_potongan = number_format($potongan);
                                    }
                                    $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                                  }else if ($d1['jenis_potongan_harga']=='voucher') {
                                    if ($d1['jenis_voucher']=='Persentase') {
                                      $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                                      $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                                    }else{
                                      $potongan = $d1['besar_voucher'] ;
                                      $show_potongan = number_format($potongan);
                                    }
                                    $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                                  }else{
                                    $potongan =0;
                                    $show_potongan ='';
                                    $caption_potongan = '';
                                  }
                                $total = $d1['biaya_kelas'] - $potongan ;

                               $total_transaksi_kelas += $total;
                            }




                       }






                    $transaksi_fnb = $this->db->query("SELECT sum(total) as total from transaksi_fnb where month(tgl_transaksi)='$tgl_transaksi' and year(tgl_transaksi)='$tahun'")->row_array();
                    $total_transaksi_fnb =$transaksi_fnb['total'] == '' ? 0 : $transaksi_fnb['total']; 
                    
                    $transaksi_sourvenir = $this->db->query("SELECT sum(total) as total from transaksi_sourvenir where month(tgl_transaksi)='$tgl_transaksi' and year(tgl_transaksi)='$tahun'")->row_array();
                    $total_transaksi_sourvenir =$transaksi_sourvenir['total'] == '' ? 0 : $transaksi_sourvenir['total']; 

                    array_push($kumpul_grafik_souvenir, intval($total_transaksi_sourvenir));
                    array_push($kumpul_grafik_fnb, intval($total_transaksi_fnb));
                    array_push($kumpul_grafik_member, intval($total_transaksi_member));
                    array_push($kumpul_grafik_kelas, intval($total_transaksi_kelas));
                    array_push($kumpul_bulan, bulan_global($bulan));
                }


                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $kumpul_grafik = [
                    'range' =>$kumpul_bulan,
                    'member' =>$kumpul_grafik_member,
                    'kelas' =>$kumpul_grafik_kelas,
                    'fnb' =>$kumpul_grafik_fnb,
                    'souvenir' =>$kumpul_grafik_souvenir,
                ];
                $caption = "tahun  ".$tahun;
                
            }
           
        }else{
             
                $bulan = intval(date('m'));
                $tahun = date('Y');
                $q_filter = "where month(tgl_daftar)='$bulan' and year(tgl_daftar)='$tahun'";
                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $caption = "bulan ".bulan_global(intval($bulan))." ".$tahun; 
                $batas_for = jml_hari_dalam_bulan($bulan, $tahun);

                    if ($bulan>0 && $bulan <10) {
                        $bulan = '0'.$bulan;
                    }else{
                        $bulan = $bulan;

                    }




                  $kumpul_grafik_kelas = [];
                  $kumpul_grafik_member = [];
                  $kumpul_grafik_fnb = [];
                  $kumpul_grafik_souvenir = [];
                  $kumpul_bulan =[];
                for ($i=0; $i < $batas_for ; $i++) { 
                     $tanggal = $i+1;
                    if ($tanggal>0 && $tanggal <10) {
                        $tgl_transaksi = $tahun.'-'.$bulan.'-0'.$tanggal;
                    }else{
                        $tgl_transaksi = $tahun.'-'.$bulan.'-'.$tanggal;

                    }
                    





                           $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.jenis_keanggotaan, km.include_register, km.id_transaksi_member, km.id_diskon, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, km.id_metode_pembayaran, 
                                tm.jenis_potongan_harga, tm.id_voucher, tm.id_diskon,
                                jm.jenis_member, jm.biaya, 
                                dk.biaya as biaya_kelas,
                                d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
                                v.jenis as jenis_voucher, v.besar_voucher, v.nama_voucher
                             from transaksi_member tm 
                             left join keanggotaan_member km on tm.id_transaksi_member = km.id_transaksi_member
                             left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
                             left join kelas k on km.id_kelas = k.id_kelas 
                             left join detail_kelas dk on km.id_detail_kelas = dk.id_detail_kelas
                             left join diskon d on tm.id_diskon = d.id_diskon 
                             left join voucher v on tm.id_voucher = v.id_voucher 
                             where  (km.id_jenis_member!='Pendaftaran') and km.tgl_daftar='$tgl_transaksi'
                                 
                                    ")->result_array();
                           $total_transaksi_member =0;
                           $total_transaksi_kelas =0;
                           foreach ($member as $k => $d1) {
                             if ($d1['jenis_keanggotaan']=='Membership') {   
                                $biaya = $d1['include_register'] == 'Ya' ? (100000 + $d1['biaya']) : $d1['biaya'];
                                $member_baru = $d1['include_register'] == 'Ya' ? 1 : 0 ;
                                if ($d1['jenis_potongan_harga']=='diskon') {
                                        if ($d1['jenis_diskon']=='Persentase') {
                                          $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                                          $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                                        }else{
                                          $potongan = $d1['besar_diskon'] ;
                                          $show_potongan = number_format($potongan);

                                        }

                                        $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                                      }else if ($d1['jenis_potongan_harga']=='voucher') {
                                        if ($d1['jenis_voucher']=='Persentase') {
                                          $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                                          $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                                        }else{
                                          $potongan = $d1['besar_voucher'] ;
                                          $show_potongan = number_format($potongan);

                                        }
                                        $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                                      }else{
                                        $potongan =0;
                                        $show_potongan ='';
                                        $caption_potongan = '';
                                      }

                                $total = $biaya - $potongan ;

                               $total_transaksi_member += $total;
                            }else{
                                if ($d1['jenis_potongan_harga']=='diskon') {
                                    if ($d1['jenis_diskon']=='Persentase') {
                                      $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                                      $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                                    }else{
                                      $potongan = $d1['besar_diskon'] ;
                                      $show_potongan = number_format($potongan);
                                    }
                                    $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                                  }else if ($d1['jenis_potongan_harga']=='voucher') {
                                    if ($d1['jenis_voucher']=='Persentase') {
                                      $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                                      $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                                    }else{
                                      $potongan = $d1['besar_voucher'] ;
                                      $show_potongan = number_format($potongan);
                                    }
                                    $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                                  }else{
                                    $potongan =0;
                                    $show_potongan ='';
                                    $caption_potongan = '';
                                  }
                                $total = $d1['biaya_kelas'] - $potongan ;

                               $total_transaksi_kelas += $total;
                            }




                       }





                    $transaksi_fnb = $this->db->query("SELECT sum(total) as total from transaksi_fnb where tgl_transaksi='$tgl_transaksi'")->row_array();
                    $total_transaksi_fnb =$transaksi_fnb['total'] == '' ? 0 : $transaksi_fnb['total']; 
                    
                    $transaksi_sourvenir = $this->db->query("SELECT sum(total) as total from transaksi_sourvenir where tgl_transaksi='$tgl_transaksi'")->row_array();
                    $total_transaksi_sourvenir =$transaksi_sourvenir['total'] == '' ? 0 : $transaksi_sourvenir['total']; 

                    array_push($kumpul_grafik_souvenir, intval($total_transaksi_sourvenir));
                    array_push($kumpul_grafik_fnb, intval($total_transaksi_fnb));
                    array_push($kumpul_grafik_kelas, intval($total_transaksi_kelas));
                    array_push($kumpul_grafik_member, intval($total_transaksi_member));
                    array_push($kumpul_bulan,$tanggal);
                }


                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $kumpul_grafik = [
                    'range' =>$kumpul_bulan,
                    'member' =>$kumpul_grafik_member,
                    'kelas' =>$kumpul_grafik_kelas,
                    'fnb' =>$kumpul_grafik_fnb,
                    'souvenir' =>$kumpul_grafik_souvenir,
                ];


        }

                $data['kumpul_grafik'] = json_encode($kumpul_grafik);



        $data['filter'] = $filter;
        $data['caption'] = $caption;
        $page = 'user/kassa/laporan/grafik/gabungan';
        $this->template->load('template/user_adminlte',$page, $data);

        // $this->load->view('template/user_adminlte');
    }











}
