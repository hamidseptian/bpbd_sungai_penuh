<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_kredit extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
        date_default_timezone_set('Asia/Jakarta');
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses=='2') {
            redirect('auth/login/kick');
        }
    }



  public function export(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    // Panggil class PHPExcel nya

    // Settingan awal fil excel
    // $excel->getProperties()->setCreator('My Notes Code')
    //              ->setLastModifiedBy('My Notes Code')
    //              ->setTitle("Data Siswa")
    //              ->setSubject("Siswa")
    //              ->setDescription("Laporan Semua Data Siswa")
    //              ->setKeywords("Data Siswa");

    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    $bulan_order = 02;
    $tahun_order = 2024;
    $caption_judul = "Laporan Kredit ";

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);

    $excel->getActiveSheet()->mergeCells('A1:A1');
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Nama");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "Alamat");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "No HP");
    $excel->setActiveSheetIndex(0)->setCellValue('E3', "Usaha");
    $excel->setActiveSheetIndex(0)->setCellValue('F3', "No Kontrak");
    $excel->setActiveSheetIndex(0)->setCellValue('G3', "Tagihan");
    $excel->setActiveSheetIndex(0)->setCellValue('H3', "Lama Tagihan");
    // $excel->setActiveSheetIndex(0)->setCellValue('J3', "Sisa Tagihan");

    // $excel->getActiveSheet()->mergeCells('A3:A4');
    // $excel->getActiveSheet()->mergeCells('B3:B4');
    // $excel->getActiveSheet()->mergeCells('C3:C4');
    // $excel->getActiveSheet()->mergeCells('D3:D4');



    $row_start = 4;
    $tgl_mulai = '2024-01-01';

      $q_order = $this->db->query("SELECT  
         ok.id_order,ok.id_jenis_barang,ok.jenis_barang,ok.keterangan_barang,ok.harga,ok.angsuran,ok.lama_angsuran,ok.satuan_angsuran,ok.dp,ok.id_pelanggan,ok.status, ok.no_kontrak,
         p.nama, p.alamat, p.no_hp, p.usaha, (SELECT  sum(harga) from item_kredit where id_order=ok.id_order) as modal 
         from order_kredit ok  
         left join pelanggan p on ok.id_pelanggan = p.id_pelanggan
         where ok.status = 'Belum Lunas' order by ok.id_order desc")->result_array();
      $merge_pelanggan = 4;
      foreach ($q_order as $k => $v) {

      	$baris_awal = ($k+1) * $merge_pelanggan;
      	$batas_merge = ($k+1) * $merge_pelanggan + 3;
      	$jatuh_tempo_cell = ($k+1) * $merge_pelanggan + 1;
      	$dibayar_cell = ($k+1) * $merge_pelanggan + 2;
      	  $baris = $row_start + $k;
        $no = $k+1;
        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris_awal, $no);

    $excel->getActiveSheet()->mergeCells('A'.$baris_awal.':A'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('B'.$baris_awal.':B'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('C'.$baris_awal.':C'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('D'.$baris_awal.':D'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('E'.$baris_awal.':E'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('F'.$baris_awal.':F'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('G'.$baris_awal.':G'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('H'.$baris_awal.':H'.$batas_merge);
    $excel->getActiveSheet()->mergeCells('I'.$baris_awal.':I'.$batas_merge);


        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris_awal, $v['nama']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris_awal, $v['alamat']);
        $excel->setActiveSheetIndex(0)->setCellValue('D'.$baris_awal, $v['no_hp']);
        $excel->setActiveSheetIndex(0)->setCellValue('E'.$baris_awal, $v['usaha']);
        $excel->setActiveSheetIndex(0)->setCellValue('F'.$baris_awal, $v['no_kontrak']);
        $excel->setActiveSheetIndex(0)->setCellValue('G'.$baris_awal, $v['angsuran']);
        $excel->setActiveSheetIndex(0)->setCellValue('H'.$baris_awal, $v['lama_angsuran'].' '.$v['satuan_angsuran']);
        // $excel->setActiveSheetIndex(0)->setCellValue('I'.$baris_awal, $v['modal']);

        $excel->setActiveSheetIndex(0)->setCellValue('J'.$baris_awal, "Angsuran Ke");
        $excel->setActiveSheetIndex(0)->setCellValue('J'.$jatuh_tempo_cell, "Jatuh Tempo");
        $excel->setActiveSheetIndex(0)->setCellValue('J'.$dibayar_cell, "Dibayar");
        $excel->setActiveSheetIndex(0)->setCellValue('J'.$batas_merge, "Tgl Dibayar");

        $excel->getActiveSheet()->getStyle('A1:I'.$batas_merge)->getAlignment()->setWrapText(true);

    $excel->getActiveSheet()->getStyle('A'.$baris_awal.':I'.$batas_merge)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP); 

        $excel->getActiveSheet()->getStyle('G'.$baris_awal)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
        // $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris_awal, $v['nama']);


	    $start_kolom = 11; //K

	    // $merge_kolom = $start_kolom + $banyak_hari; //D
	    // $convert_kolom_merge_penambahan_stok = $this->numberToColumnName($merge_kolom);

	    for ($i= $start_kolom; $i <= $v['lama_angsuran']; $i++) { 
	    	$angsuran_ke = $i-10;
            $tgl_jatuh_tempo = date('Y-m-d', strtotime($tgl_mulai .' +1 day'));

	    	 $kolom_tgl = $this->numberToColumnName($i);
	            $excel->getActiveSheet()->getColumnDimension($kolom_tgl)->setWidth(6);
	            // $excel->getActiveSheet()->getStyle($kolom_tgl.'3')->applyFromArray($border);

	            $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$baris_awal,$angsuran_ke);
	            $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$jatuh_tempo_cell,$tgl_jatuh_tempo);
	            // $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.'5', $i);

	            // $excel->getActiveSheet()->getStyle($kolom_tgl.'4')->applyFromArray($border);
	            // $excel->getActiveSheet()->getStyle($kolom_tgl.'5')->applyFromArray($border);


	    	# code...
	    }

      }


    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(12);

	







//      $excel->getActiveSheet()->getStyle('P'.$baris_mulai_paket)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    



    // Set width kolom
  // Set width kolom E
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export ='Tess.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }













function numberToColumnName($number){
    $abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $abc_len = strlen($abc);

    $result_len = 1; // how much characters the column's name will have
    $pow = 0;
    while( ( $pow += pow($abc_len, $result_len) ) < $number ){
        $result_len++;
    }

    $result = "";
    $next = false;
    // add each character to the result...
    for($i = 1; $i<=$result_len; $i++){
        $index = ($number % $abc_len) - 1; // calculate the module

        // sometimes the index should be decreased by 1
        if( $next || $next = false ){
            $index--;
        }

        // this is the point that will be calculated in the next iteration
        $number = floor($number / strlen($abc));

        // if the index is negative, convert it to positive
        if( $next = ($index < 0) ) {
            $index = $abc_len + $index;
        }

        $result = $abc[$index].$result; // concatenate the letter
    }
    return $result;
}

}
