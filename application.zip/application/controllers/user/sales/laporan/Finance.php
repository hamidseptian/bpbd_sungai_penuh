<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Finance extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
        ]);

        date_default_timezone_set('Asia/Jakarta');
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses=='2') {
            redirect('auth/login/kick');
        }
        error_reporting(0);
    }




    public function index()
    {
        $data['judul'] = 'Laporan - Finance - Rekap Finance';
          $data['breadchumb'] = ' 
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>



            ';


        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
        $id_user = $this->session->userdata('id_user'); 
        if ($id_hak_akses==3) {
            $where_id_user_member = "and tm.id_user='$id_user'";    
            $where_id_user_fnb = "and ts.id_user='$id_user'";    
            $where_id_user_souvenir = "and ts.id_user='$id_user'";    
            $where_id_user_pengeluaran = "and id_user='$id_user'";    
            $where_id_user_kasir = "and id_user='$id_user'";    
        }else{
            $where_id_user_member = "";   
            $where_id_user_fnb = "";   
            $where_id_user_souvenir = "";   
            $where_id_user_pengeluaran = "";   
            $where_id_user_kasir = "";   

        }

        $filter = $this->input->get('filter');
        if ($this->input->get('filter')) {
            if ($filter=='harian') {
                $tgl = $this->input->get('tgl');
                $q_filter_member = "and km.tgl_daftar='$tgl'".$where_id_user_member;;
                $q_filter_fnb =  "where tgl_order='$tgl'".$where_id_user_fnb;
                $q_filter_sourvenir = "where tgl_order='$tgl'".$where_id_user_souvenir;
                $q_filter_pengeluaran = "and tgl_transaksi='$tgl'".$where_id_user_pengeluaran;
                $caption = "Laporan finance tanggal ".$tgl;

            }
            else if ($filter=='bulanan') {
                $bulan = $this->input->get('bulan');
                $tahun = $this->input->get('tahun');
                $q_filter_member = "and month(km.tgl_daftar)='$bulan' and year(km.tgl_daftar)='$tahun'".$where_id_user_member;
                $q_filter_fnb =  "where month(tgl_order)='$bulan' and year(tgl_order)='$tahun'".$where_id_user_fnb;
                $q_filter_sourvenir = "where month(tgl_order)='$bulan' and year(tgl_order)='$tahun'".$where_id_user_souvenir;
                $q_filter_pengeluaran =  "and month(tgl_transaksi)='$bulan' and year(tgl_transaksi)='$tahun'".$where_id_user_pengeluaran;
                $caption = "Laporan finance bulan ".bulan_global(intval($bulan))." ".$tahun;
                # code...
            }
            else if ($filter=='tahunan') {
                $tahun = $this->input->get('tahun');
                $q_filter_member = "and year(km.tgl_daftar)='$tahun'".$where_id_user_member;;
                $q_filter_fnb =  "where year(tgl_order)='$tahun'".$where_id_user_fnb;
                $q_filter_sourvenir = " where year(tgl_order)='$tahun'".$where_id_user_souvenir;
                $q_filter_pengeluaran =  "and year(tgl_transaksi)='$tahun'".$where_id_user_pengeluaran;
                $caption = "Laporan finance tahun  ".$tahun;
                # code...
            }
            else if ($filter=='periode') {
                $tgl_awal = $this->input->get('tgl_awal');
                $tgl_akhir = $this->input->get('tgl_akhir');
                // $q_filter = "where tgl_daftar between '$tgl_awal' and '$tgl_akhir' ".$where_id_user_member;
                $q_filter_member = "and km.tgl_daftar between '$tgl_awal' and '$tgl_akhir'";
                $q_filter_fnb =  "where tgl_order between '$tgl_awal' and '$tgl_akhir'".$where_id_user_fnb;
                $q_filter_sourvenir = "where tgl_order between '$tgl_awal' and '$tgl_akhir'".$where_id_user_souvenir;
                $q_filter_pengeluaran = "and tgl_transaksi between '$tgl_awal' and '$tgl_akhir'".$where_id_user_pengeluaran;

                $caption = "Laporan finance tanggal ".$tgl_awal.' s/d '.$tgl_akhir;
                # code...
            }
            else if ($filter=='semua') {
                $q_filter = "";

                $caption = "Laporan member keseluruhan ";
                # code...
            }
        }else{
            $q_filter_member = '';
            $q_filter_fnb = '';
            $q_filter_sourvenir = '';
            $q_filter_pengeluaran = '';
        }




    $metode_pembayaran = $this->db->query("SELECT id_metode_pembayaran, metode_pembayaran from metode_pembayaran")->result_array();
    $kumpul_metode_pembayaran = [];
    foreach ($metode_pembayaran as $k => $v) {
        $kumpul_metode_pembayaran[$v['id_metode_pembayaran']] = 
         [
                'id_metode_pembayaran' => $v['id_metode_pembayaran'],
                'metode_pembayaran' => $v['metode_pembayaran'],
                'nilai'=>[],
                'member'=>[],
                'kelas'=>[],
                'fnb'=>[],
                'sourvenir'=>[],
            
        ]  ;
        // array_push($kumpul_metode_pembayaran, $data_metode_pembayaran) ; 
    }


    $kasir = $this->db->query("SELECT id_user, nama from user where id_hak_akses='3' $where_id_user_kasir")->result_array();
    $kumpul_kasir = [];
    foreach ($kasir as $k => $v) {
        $kumpul_kasir[$v['id_user']] = 
         [
                'id_user' => $v['id_user'],
                'kasir' => $v['nama'],
                'nilai'=>[],
                'member'=>[],
                'kelas'=>[],
                'fnb'=>[],
                'sourvenir'=>[],
            
        ]  ;
        // array_push($kumpul_metode_pembayaran, $data_metode_pembayaran) ; 
    }

        // membership
        $member = $this->db->query("SELECT km.id_member, km.id_jenis_member, km.id_diskon, km.jenis_keanggotaan, km.tgl_daftar, km.jam_daftar, km.akhir_masa_aktif, 
            km.include_register,
         tm.id_metode_pembayaran, 
            tm.jenis_potongan_harga, tm.id_voucher, tm.id_diskon,
            m.nama, m.no_hp, 
            jm.jenis_member, jm.biaya, 
            dk.biaya as biaya_kelas,
            d.jenis as jenis_diskon, d.besar_diskon, d.nama_diskon,
            v.jenis as jenis_voucher, v.besar_voucher, v.nama_voucher,
            tm.id_user
         from keanggotaan_member km
         left join member m on km.id_member = m.id_member
         left join jenis_member jm on km.id_jenis_member = jm.id_jenis_member
         left join kelas k on km.id_kelas = k.id_kelas 
         left join detail_kelas dk on km.id_detail_kelas = dk.id_detail_kelas
         left join transaksi_member tm on km.id_transaksi_member = tm.id_transaksi_member
         left join diskon d on tm.id_diskon = d.id_diskon 
         left join voucher v on tm.id_voucher = v.id_voucher 
         where km.id_jenis_member!='Pendaftaran'

        $q_filter_member")->result_array();
          $total_pendapatan_member = 0;
          $total_pendapatan_kelas = 0;
          $total_member_baru = 0;
          $total_member_kelas = 0;
          foreach ($member as $k => $d1) {

            if ($d1['jenis_keanggotaan']=='Membership') {   
                $biaya = $d1['include_register'] == 'Ya' ? (100000 + $d1['biaya']) : $d1['biaya'];
                $member_baru = $d1['include_register'] == 'Ya' ? 1 : 0 ;
                $jenis_member = $d1['include_register'] == 'Ya' ? 'Registrasi' : $d1['jenis_member'];
               


                if ($d1['jenis_potongan_harga']=='diskon') {
                        if ($d1['jenis_diskon']=='Persentase') {
                          $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                          $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                        }else{
                          $potongan = $d1['besar_diskon'] ;
                          $show_potongan = number_format($potongan);

                        }

                        $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                      }else if ($d1['jenis_potongan_harga']=='voucher') {
                        if ($d1['jenis_voucher']=='Persentase') {
                          $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                          $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                        }else{
                          $potongan = $d1['besar_voucher'] ;
                          $show_potongan = number_format($potongan);

                        }
                        $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                      }else{
                        $potongan =0;
                        $show_potongan ='';
                        $caption_potongan = '';
                      }






                $total = $biaya - $potongan ;
                $total_pendapatan_member += $total;
                $total_member_baru += $member_baru;
                array_push($kumpul_metode_pembayaran[$d1['id_metode_pembayaran']]['nilai'], $total);
                array_push($kumpul_metode_pembayaran[$d1['id_metode_pembayaran']]['member'], $total);

                array_push($kumpul_kasir[$d1['id_user']]['nilai'], $total);
                array_push($kumpul_kasir[$d1['id_user']]['member'], $total);
                # code...
            }else{
                if ($d1['jenis_potongan_harga']=='diskon') {
                    if ($d1['jenis_diskon']=='Persentase') {
                      $potongan = ($d1['besar_diskon'] / 100) * $d1['biaya'];
                      $show_potongan = $d1['besar_diskon'].'% ['.number_format($potongan).']';
                    }else{
                      $potongan = $d1['besar_diskon'] ;
                      $show_potongan = number_format($potongan);

                    }

                    $caption_potongan = 'Diskon<br>'.$d1['nama_diskon'];
                  }else if ($d1['jenis_potongan_harga']=='voucher') {
                    if ($d1['jenis_voucher']=='Persentase') {
                      $potongan = ($d1['besar_voucher'] / 100) * $d1['biaya'];
                      $show_potongan = $d1['besar_voucher'].'% ['.number_format($potongan).']';
                    }else{
                      $potongan = $d1['besar_voucher'] ;
                      $show_potongan = number_format($potongan);

                    }
                    $caption_potongan = 'Voucher<br>'.$d1['nama_voucher'];
                  }else{
                    $potongan =0;
                    $show_potongan ='';
                    $caption_potongan = '';
                  }

                        // $total = $biaya - $potongan ;




                $total = $d1['biaya_kelas'] - $potongan ;
                $total_pendapatan_kelas += $total;
                $total_member_kelas += 1;
                array_push($kumpul_metode_pembayaran[$d1['id_metode_pembayaran']]['nilai'], $total);
                array_push($kumpul_metode_pembayaran[$d1['id_metode_pembayaran']]['kelas'], $total);

                array_push($kumpul_kasir[$d1['id_user']]['nilai'], $total);
                array_push($kumpul_kasir[$d1['id_user']]['kelas'], $total);
            }


          }

          $data['cek'] = count($member);
        // // sourvenir
        // $q_sourvenir = $this->db->query("SELECT id_sourvenir, jenis, produk, harga from sourvenir where status=1")->result_array();
        // $total_pendapatan_sourvenir =0;
        // $total_qty_order_sourvenir =0;
        // foreach ($q_sourvenir as $k => $v) { 
        //     $id_sourvenir = $v['id_sourvenir'];
        //     $order_sourvenir = $this->db->query("SELECT sum(qty) as qty from order_sourvenir where status='1' and id_sourvenir='$id_sourvenir'
        //         $q_filter_sourvenir")->row_array();
        //     $qty = $order_sourvenir['qty'];
        //     $total = $order_sourvenir['qty'] * $v['harga'];
        //     $total_pendapatan_sourvenir +=$total;
        //     $total_qty_order_sourvenir +=$order_sourvenir['qty'];
           

        //     // array_push($kumpul_metode_pembayaran[$v['id_metode_pembayaran']]['nilai'], $total);
        // }
          
        // sourvenir
        $q_sourvenir = $this->db->query("SELECT o.id_sourvenir, o.qty, o.harga_satuan,
            ts.id_metode_pembayaran, ts.id_user
         from order_sourvenir o
            left join transaksi_sourvenir ts on o.id_transaksi_sourvenir = ts.id_transaksi_sourvenir    
         $q_filter_sourvenir")->result_array();
        $total_pendapatan_sourvenir =0;
        $total_qty_order_sourvenir =0;
        foreach ($q_sourvenir as $k => $v) { 
            $id_sourvenir = $v['id_sourvenir'];
           
            $qty = $v['qty'];
            $total = $v['qty'] * $v['harga_satuan'];
            $total_pendapatan_sourvenir +=$total;
            $total_qty_order_sourvenir +=$v['qty'];
           

            array_push($kumpul_metode_pembayaran[$v['id_metode_pembayaran']]['nilai'], $total);
            array_push($kumpul_metode_pembayaran[$v['id_metode_pembayaran']]['sourvenir'], $total);

                array_push($kumpul_kasir[$d1['id_user']]['nilai'], $total);
                array_push($kumpul_kasir[$d1['id_user']]['sourvenir'], $total);

                // array_push($kumpul_metode_pembayaran[$d1['id_metode_pembayaran']]['kelas'], $total);
        }
          

          
        // fnb
        $q_fnb = $this->db->query("SELECT o.id_fnb, o.qty, o.harga_satuan, o.action,
            ts.id_metode_pembayaran, ts.id_user
         from order_fnb o
            left join transaksi_fnb ts on o.id_transaksi_fnb = ts.id_transaksi_fnb    
         $q_filter_fnb")->result_array();
        $total_pendapatan_fnb =0;
        $total_qty_order_fnb =0;
        $total_qty_entertain_fnb =0;
        foreach ($q_fnb as $k => $v) { 
            $id_fnb = $v['id_fnb'];
           
            $qty = $v['qty'];
            $total = $v['qty'] * $v['harga_satuan'];

            if ($v['action']=='Penjualan') {
                $total_pendapatan_fnb +=$total;
                $total_qty_order_fnb +=$v['qty'];
                array_push($kumpul_metode_pembayaran[$v['id_metode_pembayaran']]['nilai'], $total);
                array_push($kumpul_metode_pembayaran[$v['id_metode_pembayaran']]['fnb'], $total);
                array_push($kumpul_kasir[$d1['id_user']]['nilai'], $total);
                array_push($kumpul_kasir[$d1['id_user']]['fnb'], $total);
                # code...
            }else{
                $total_qty_entertain_fnb +=$v['qty'];

            }

                // array_push($kumpul_metode_pembayaran[$d1['id_metode_pembayaran']]['kelas'], $total);
        }
          







        // fnb
        // $q_fnb = $this->db->query("SELECT id_fnb, jenis, produk, harga from fnb where status=1")->result_array();
        // $total_pendapatan_fnb =0;
        // $total_qty_order_fnb =0;
        // foreach ($q_fnb as $k => $v) { 
        //     $id_fnb = $v['id_fnb'];
        //     $order_fnb = $this->db->query("SELECT sum(qty) as qty from order_fnb where status='1' and id_fnb='$id_fnb' and action='Penjualan'
        //         $q_filter_fnb")->row_array();
        //     $qty = $order_fnb['qty'];
        //     $total = $order_fnb['qty'] * $v['harga'];
        //     $total_pendapatan_fnb +=$total;
        //     $total_qty_order_fnb +=$order_fnb['qty'];
           
        // }


        // pengeluaran
        $q_pengeluaran = $this->db->query("SELECT besar_pengeluaran from pengeluaran where approval=1 $q_filter_pengeluaran")->result_array();
        $total_pengeluaran =0;
        $banyak_transaksi_pengeluaran =0;
        foreach ($q_pengeluaran as $k => $v) { 
            $banyak_transaksi_pengeluaran++;
            $total = $v['besar_pengeluaran'];
            $total_pengeluaran +=$total;
           
        }
          
        $total_pemasukan = $total_pendapatan_member + $total_pendapatan_sourvenir + $total_pendapatan_fnb + $total_pendapatan_kelas;
        $pendapatan = $total_pemasukan - $total_pengeluaran;
        $kumpul_data = [
            'qty_member'=>$total_member_baru.' Member Baru',
            'qty_kelas'=>$total_member_kelas.' Member Kelas',
            'qty_fnb'=>$total_qty_order_fnb.' Item Terjual, '.$total_qty_entertain_fnb.' Item Entertain',
            'qty_sourvenir'=>$total_qty_order_sourvenir.' Item Terjual',
            'qty_pengeluaran'=>$banyak_transaksi_pengeluaran.' Transaksi',

            'rp_member'=>$total_pendapatan_member,
            'rp_kelas'=>$total_pendapatan_kelas,
            'rp_fnb'=>$total_pendapatan_fnb,
            'rp_sourvenir'=>$total_pendapatan_sourvenir,
            'rp_pemasukan'=>$total_pemasukan,
            'rp_pengeluaran'=>$total_pengeluaran,
            'rp_pendapatan'=>$pendapatan,
        ];
        $data['finance'] =$kumpul_data;
        $data['caption'] =$caption;

    $data['berdasarkan_metode_pembayaran'] = $kumpul_metode_pembayaran;
    $data['berdasarkan_kasir'] = $kumpul_kasir;

        $page = 'user/kassa/laporan/finance/lap_finance';
        $this->template->load('template/user_adminlte',$page, $data);

        // $this->load->view('template/user_adminlte');
    }







function numberToColumnName($number){
    $abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $abc_len = strlen($abc);

    $result_len = 1; // how much characters the column's name will have
    $pow = 0;
    while( ( $pow += pow($abc_len, $result_len) ) < $number ){
        $result_len++;
    }

    $result = "";
    $next = false;
    // add each character to the result...
    for($i = 1; $i<=$result_len; $i++){
        $index = ($number % $abc_len) - 1; // calculate the module

        // sometimes the index should be decreased by 1
        if( $next || $next = false ){
            $index--;
        }

        // this is the point that will be calculated in the next iteration
        $number = floor($number / strlen($abc));

        // if the index is negative, convert it to positive
        if( $next = ($index < 0) ) {
            $index = $abc_len + $index;
        }

        $result = $abc[$index].$result; // concatenate the letter
    }
    return $result;
}
















}
