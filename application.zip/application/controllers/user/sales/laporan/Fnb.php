<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fnb extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
        date_default_timezone_set('Asia/Jakarta');
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses=='2') {
            redirect('auth/login/kick');
        }
    }




    public function order()
    {
        $data['judul'] = 'Laporan - fnb - Order fnb';
          $data['breadchumb'] = ' 
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>

            ';

        $q_fnb = $this->db->query("SELECT f.id_fnb, f.jenis, f.produk, f.harga from order_fnb of 
            left join fnb f on of.id_fnb = f.id_fnb 
            group by of.id_fnb
            ")->result_array();

        $kumpul_fnb = [];

        if ($this->input->get('filter')) {
            $filter = $this->input->get('filter');
            if ($filter=='harian') {
                $tgl_order = $this->input->get('tgl');
                $filter = "and tgl_order='$tgl_order'";
                $caption = "Laporan penjualan fnb tanggal ".$tgl_order;
                $page = 'user/kassa/laporan/fnb/order_fnb';

            }
            else if ($filter=='bulanan') {
                $bulan_order = $this->input->get('bulan');
                $tahun_order = $this->input->get('tahun');
                $filter = "and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'";
                $page = 'user/kassa/laporan/fnb/order_fnb_bulanan';
                // $page = 'user/kassa/laporan/fnb/order_fnb';
                $data['jumlah_hari'] = jml_hari_dalam_bulan($bulan_order, $tahun_order);
                $data['bulan_order'] = $bulan_order;
                $data['tahun_order'] = $tahun_order;
                $data['data_fnb'] = $q_fnb;
                $caption = "Laporan penjualan fnb bulan ".bulan_global(intval($bulan_order))." ".$tahun_order;
                # code...
            }
            else if ($filter=='tahunan') {
                $tahun_order = $this->input->get('tahun');
                $filter = "and year(tgl_order)='$tahun_order'";
                $page = 'user/kassa/laporan/fnb/order_fnb_tahunan';
                // $page = 'user/kassa/laporan/fnb/order_fnb';
                $data['tahun_order'] = $tahun_order;
                $data['data_fnb'] = $q_fnb;
                $caption = "Laporan penjualan fnb tahun ".$tahun_order;
                # code...
            }
            else if ($filter=='periode') {
                $tgl_awal = $this->input->get('tgl_awal');
                $tgl_akhir = $this->input->get('tgl_akhir');
                $page = 'user/kassa/laporan/fnb/order_fnb';
                $filter = "and tgl_order between '$tgl_awal' and '$tgl_akhir' ";

                $caption = "Laporan penjualan fnb tanggal ".$tgl_awal.' s/d '.$tgl_akhir;
                # code...
            }
            else if ($filter=='semua') {
                $page = 'user/kassa/laporan/fnb/order_fnb';
                $filter = "";

                $caption = "Laporan penjualan fnb keseluruhan ";
                # code...
            }
        }else{
            $thns = date('Y');
            $filter = "and year(tgl_order)='$thns'";
            $page = 'user/kassa/laporan/fnb/order_fnb';

                $caption = "Laporan penjualan fnb tahun ".$thns;

        }

          $q_fnb = $this->db->query("SELECT f.id_fnb, f.jenis, f.produk, f.harga from order_fnb of 
                    left join fnb f on of.id_fnb = f.id_fnb 
                  
                    group by of.id_fnb
                    ")->result_array();

        $kumpul_fnb = [];
        foreach ($q_fnb as $k => $v) { 
            $id_fnb = $v['id_fnb'];
            $order_fnb = $this->db->query("SELECT  qty, action from order_fnb where status='1' and id_fnb='$id_fnb'
                $filter")->result_array();
            $qty_fnb_terjual = 0 ; 
            $qty_fnb_entertain = 0 ; 
            $rp_fnb_terjual = 0 ; 
            foreach ($order_fnb as $k_fnb => $v_fnb) {
            $qty = $v_fnb['qty'];
               if ($v_fnb['action']=='Penjualan') {
                  $qty_fnb_terjual+=$qty;
                    $total = $v_fnb['qty'] * $v['harga'];
                  $rp_fnb_terjual+=$total;
               }else{
                  $qty_fnb_entertain +=$qty;

               }

            }
            $data_order_fnb = [
                'id_fnb'=>$v['id_fnb'],
                'jenis'=>$v['jenis'],
                'produk'=>$v['produk'],
                'harga'=>$v['harga'],
                'terjual'=>$qty_fnb_terjual ,
                'entertain'=>$qty_fnb_entertain ,
                'total'=>$rp_fnb_terjual    ,
            ];
            array_push($kumpul_fnb, $data_order_fnb);
        }

        
        // $q = $this->db->query("SELECT tf.id_transaksi_fnb, tf.tgl_transaksi, tf.jam_transaksi, tf.total, tf.status from transaksi_fnb tf order by tf.tgl_transaksi desc, tf.jam_transaksi desc")->result_array();
        $data['fnb'] = $kumpul_fnb;
        $data['caption'] = $caption;
        // $page = 'user/kassa/laporan/fnb/order_fnb';

         $data['modal_order']  = $this->load->view('user/kassa/laporan/fnb/modal_order', $data);
        $this->template->load('template/user_adminlte',$page, $data);

        // $this->load->view('template/user_adminlte');
    }




    public function stok()
    {
        $data['judul'] = 'Laporan - fnb - Stok fnb';
          $data['breadchumb'] = ' 
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>




            ';

        $q_fnb = $this->db->query("SELECT id_fnb, jenis, produk, harga from fnb where status=1")->result_array();

        $kumpul_fnb = [];
        $filter = $this->input->get('filter');

        if ($this->input->get('filter')) {
            $filter_stok = $this->input->get('filter');
            if ($filter_stok=='harian') {
                $tgl_order = $this->input->get('tgl');
                $filter_stok = "and tgl_masuk='$tgl_order'";
                $filter_order = "and tgl_order='$tgl_order'";
                $caption = "Laporan pengelolaan stok  fnb tanggal ".$tgl_order;


                $tanggal_sebelumnya    =date('Y-m-d', strtotime("-1 day", strtotime($tgl_order)));
                $data['tanggal_sebelumnya'] = $tanggal_sebelumnya    ;
                $data['tanggal_order'] = $tgl_order    ;
                $page = 'user/kassa/laporan/fnb/stok_fnb_harian';

            }
            else if ($filter_stok=='bulanan') {
                $bulan_order = $this->input->get('bulan');
                $tahun_order = $this->input->get('tahun');
                $bulan_sebelumnya    =date('Y-m', strtotime("-1 month", strtotime($tahun_order.'-'.$bulan_order)));
                // $excel->setActiveSheetIndex(0)->setCellValue('A2', $bulan_sebelumnya);
                $pecah = explode('-', $bulan_sebelumnya);
                $tahun_sebelumnya = $pecah[0];
                $bulan_sebelumnya = $pecah[1];
                $filter_stok = "and month(tgl_masuk)='$bulan_order' and year(tgl_masuk)='$tahun_order'";
                $filter_order = "and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'";
                $page = 'user/kassa/laporan/fnb/stok_fnb_bulanan';
                // $page = 'user/kassa/laporan/fnb/stok_fnb';
                $data['jumlah_hari'] = jml_hari_dalam_bulan($bulan_order, $tahun_order);
                $data['bulan_order'] = $bulan_order;
                $data['tahun_order'] = $tahun_order;
                $data['data_fnb'] = $q_fnb;
                $data['tahun_sebelumnya'] = $tahun_sebelumnya    ;
                $data['bulan_sebelumnya'] = $bulan_sebelumnya  ;
                $caption = "Laporan pengelolaan stok  fnb bulan ".bulan_global(intval($bulan_order))." ".$tahun_order;
                # code...
            }
            else if ($filter_stok=='tahunan') {
                $bulan_order = $this->input->get('bulan');
                $tahun_order = $this->input->get('tahun');
                $bulan_sebelumnya    =date('Y-m', strtotime("-1 month", strtotime($tahun_order.'-'.$bulan_order)));
                // $excel->setActiveSheetIndex(0)->setCellValue('A2', $bulan_sebelumnya);
                $pecah = explode('-', $bulan_sebelumnya);
                $tahun_sebelumnya = $tahun_order-1;
                $bulan_sebelumnya = $pecah[1];
                $filter_stok = "and year(tgl_masuk)='$tahun_order'";
                $filter_order = "and year(tgl_order)='$tahun_order'";
                $page = 'user/kassa/laporan/fnb/stok_fnb_tahunan';
                // $page = 'user/kassa/laporan/fnb/stok_fnb';
                $data['tahun_order'] = $tahun_order;
                $data['data_fnb'] = $q_fnb;
                $data['tahun_sebelumnya'] = $tahun_sebelumnya    ;
                $data['bulan_sebelumnya'] = $bulan_sebelumnya  ;
                $caption = "Laporan pengelolaan stok  fnb tahun  ".$tahun_order;
                # code...
            }
            else if ($filter_stok=='periode') {
                $tgl_awal = $this->input->get('tgl_awal');
                $tgl_akhir = $this->input->get('tgl_akhir');
                $page = 'user/kassa/laporan/fnb/stok_fnb_periode';
                $filter_stok = "and tgl_masuk between '$tgl_awal' and '$tgl_akhir' ";
                $filter_order = "and tgl_order between '$tgl_awal' and '$tgl_akhir' ";

                $data['tgl_awal'] = $tgl_awal    ;
                $caption = "Laporan pengelolaan stok fnb tanggal ".$tgl_awal.' s/d '.$tgl_akhir;
                # code...
            }
            else if ($filter_stok=='semua') {
                $page = 'user/kassa/laporan/fnb/stok_fnb';
                $filter_stok = "";
                $filter_order = "";

                $caption = "Laporan pengelolaan stok fnb keseluruhan ";
                # code...
            }
        }else{
            $thns = date('Y');
            $filter_stok = "and year(tgl_masuk)='$thns'";
            $filter_order = "and year(tgl_order)='$thns'";
            $page = 'user/kassa/laporan/fnb/stok_fnb';

                $caption = "Laporan pengelolaan stok fnb tahun ".$thns;

        }


        foreach ($q_fnb as $k => $v) { 
            $id_fnb = $v['id_fnb'];
            $stok_fnb = $this->db->query("SELECT sum(qty) as qty from stok_fnb where id_fnb='$id_fnb'
                $filter_stok")->row_array();
            $order_fnb = $this->db->query("SELECT sum(qty) as qty from order_fnb where id_fnb='$id_fnb'
                $filter_order")->row_array();
            $qty_masuk = $stok_fnb['qty'];
            $qty_keluar = $order_fnb['qty'];
            $qty_sisa = $qty_masuk - $qty_keluar;
            $data_order_fnb = [
                'id_fnb'=>$id_fnb,
                'jenis'=>$v['jenis'],
                'produk'=>$v['produk'],
                'harga'=>$v['harga'],
                'qty_masuk'=>$qty_masuk == '' ? 0 : $qty_masuk,
                'qty_keluar'=>$qty_keluar == '' ? 0 : $qty_keluar,
                'qty_sisa'=>$qty_sisa,
            ];
            array_push($kumpul_fnb, $data_order_fnb);
        }

        
        // $q = $this->db->query("SELECT tf.id_transaksi_fnb, tf.tgl_transaksi, tf.jam_transaksi, tf.total, tf.status from transaksi_fnb tf order by tf.tgl_transaksi desc, tf.jam_transaksi desc")->result_array();
        $data['fnb'] = $kumpul_fnb;
        $data['caption'] = $caption;
        $data['filter'] = $filter;
         $data['modal_stok']  = $this->load->view('user/kassa/laporan/fnb/modal_stok', $data);
        $this->template->load('template/user_adminlte',$page, $data);

        // $this->load->view('template/user_adminlte');
    }













































  public function export_stok_bulanan(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    // Panggil class PHPExcel nya

    // Settingan awal fil excel
    // $excel->getProperties()->setCreator('My Notes Code')
    //              ->setLastModifiedBy('My Notes Code')
    //              ->setTitle("Data Siswa")
    //              ->setSubject("Siswa")
    //              ->setDescription("Laporan Semua Data Siswa")
    //              ->setKeywords("Data Siswa");

    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    // $fill_program = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'f0cdf5')
    //     )
    // );
    // $fill_kegiatan = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'FF99CC')
    //     )
    // );




// // Untuk judulnya
//     $excel->getActiveSheet()->mergeCells('A1:AR1');
//     $excel->getActiveSheet()->mergeCells('A2:AR2');
//     $excel->getActiveSheet()->mergeCells('A3:AR3');


    $bulan_order = $this->input->get('bulan');
    $tahun_order = $this->input->get('tahun');
    $caption_judul = "Laporan pengelolaan stok  fnb bulan ".bulan_global(intval($bulan_order))." ".$tahun_order;

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Produk");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "Harga");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "Sisa Stok Sampai Bulan Lalu");
    $excel->setActiveSheetIndex(0)->setCellValue('E3', "Penambahan Stok / Tgl");

    $excel->getActiveSheet()->mergeCells('A3:A4');
    $excel->getActiveSheet()->mergeCells('B3:B4');
    $excel->getActiveSheet()->mergeCells('C3:C4');
    $excel->getActiveSheet()->mergeCells('D3:D4');







    $banyak_hari = jml_hari_dalam_bulan($bulan_order, $tahun_order) -1;
    $start_kolom = 5; //D
    $merge_kolom = $start_kolom + $banyak_hari; //D




    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(12);


    // setting kolom tanggal
    $convert_kolom_merge_penambahan_stok = $this->numberToColumnName($merge_kolom);
    $kolom_total = $merge_kolom+1;
    $kolom_total_stok_semua = $kolom_total +1;  
    $kolom_terjual = $kolom_total_stok_semua+1;
    $kolom_sisa_stok = $kolom_terjual+1;
    $convert_kolom_sum_row = $this->numberToColumnName($kolom_total-1);
    $convert_kolom_total_stok = $this->numberToColumnName($kolom_total);
    $convert_kolom_total_stok_semua = $this->numberToColumnName($kolom_total_stok_semua);
    $convert_kolom_terjual = $this->numberToColumnName($kolom_terjual);
    $convert_kolom_sisa_stok = $this->numberToColumnName($kolom_sisa_stok);


    $excel->setActiveSheetIndex(0)->setCellValue('A5', "1");
    $excel->setActiveSheetIndex(0)->setCellValue('B5', "2");
    $excel->setActiveSheetIndex(0)->setCellValue('C5', "3");
    $excel->setActiveSheetIndex(0)->setCellValue('D5', "4");

    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D5')->applyFromArray($border);



    $row_kolom_angka = $start_kolom;
    for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 
    $row_kolom_angka +=1;
        $tgl = $i-4;
        $kolom_tgl = $this->numberToColumnName($i);
            $excel->getActiveSheet()->getColumnDimension($kolom_tgl)->setWidth(6);
            $excel->getActiveSheet()->getStyle($kolom_tgl.'3')->applyFromArray($border);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.'4', $tgl);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.'5', $i);

            $excel->getActiveSheet()->getStyle($kolom_tgl.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($kolom_tgl.'5')->applyFromArray($border);
        # code...
    }
    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_stok)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.'3', "Total Stok Bulan Ini");
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.'3')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.'5')->applyFromArray($border);


    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_stok_semua)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.'3', "Total Stok Sampai Bulan Ini");
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.'3')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.'5')->applyFromArray($border);



    $row_kolom_total_stok = $merge_kolom+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.'5', $row_kolom_total_stok."=SUM(E".$start_kolom.":".$convert_kolom_sum_row."".$start_kolom.")");

    $excel->getActiveSheet()->getColumnDimension($convert_kolom_terjual)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.'3', "Stok Keluar Bulan Ini");

    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.'3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.'4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.'5')->applyFromArray($border);



    $row_kolom_stok_semua = $row_kolom_angka+1;
    $row_kolom_terjual = $row_kolom_stok_semua+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.'5', $row_kolom_terjual);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.'5', $row_kolom_stok_semua.'=4+'.$row_kolom_total_stok);

    $excel->getActiveSheet()->getColumnDimension($convert_kolom_sisa_stok)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.'3', "Sisa Stok");

    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.'3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.'4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.'5')->applyFromArray($border);



    $excel->getActiveSheet()->mergeCells($convert_kolom_total_stok.'3:'.$convert_kolom_total_stok.'4');
    $excel->getActiveSheet()->mergeCells($convert_kolom_total_stok_semua.'3:'.$convert_kolom_total_stok_semua.'4');
    $excel->getActiveSheet()->mergeCells($convert_kolom_terjual.'3:'.$convert_kolom_terjual.'4');





    $row_kolom_sisa = $row_kolom_terjual+1;
    $excel->getActiveSheet()->mergeCells($convert_kolom_sisa_stok.'3:'.$convert_kolom_sisa_stok.'4');
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.'5', $row_kolom_sisa."=".$row_kolom_stok_semua."-".$row_kolom_terjual);


    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_sisa_stok.'5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_sisa_stok.'5')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 







    $q_fnb = $this->db->query("SELECT id_fnb, jenis, produk, harga from fnb where status=1")->result_array();





    $row_start = 6;
    $row_data_terakhir = 6;

    $kumpul_total_fnb = [];
    $kumpul_terjual = [];
    $total_harga_semua =0;
    $total_stok_sebelumnya =0;
    $total_stok_gabungan = 0;


    $bulan_sebelumnya    =date('Y-m', strtotime("-1 month", strtotime($tahun_order.'-'.$bulan_order)));
    // $excel->setActiveSheetIndex(0)->setCellValue('A2', $bulan_sebelumnya);
    $pecah = explode('-', $bulan_sebelumnya);
    $tahun_sebelumnya = $pecah[0];
    $bulan_sebelumnya = $pecah[1];
    foreach ($q_fnb as $k => $v) {
        $row_data_terakhir +=1;
        $id_fnb = $v['id_fnb'];

           $q_stok_sebelumnya = $this->db->query("SELECT sum(qty) as qty from stok_fnb
                    where id_fnb='$id_fnb' 
                 and month(tgl_masuk)<='$bulan_sebelumnya' and year(tgl_masuk)<='$tahun_sebelumnya'
                    ")->row_array();
           $stok_sebelumnya = $q_stok_sebelumnya['qty'] == '' ? 0 : $q_stok_sebelumnya['qty'];

           $q_order_sebelumnya = $this->db->query("SELECT sum(qty) as qty from order_fnb
                    where id_fnb='$id_fnb' 
                 and month(tgl_order)<='$bulan_sebelumnya' and year(tgl_order)<='$tahun_sebelumnya'
                    ")->row_array();
           $order_sebelumnya = $q_order_sebelumnya['qty'] == '' ? 0 : $q_order_sebelumnya['qty'];
           $sisa_stok_sebelumnya = $stok_sebelumnya - $order_sebelumnya;

        

           $order_fnb = $this->db->query("SELECT sum(qty) as qty from order_fnb
                    where id_fnb='$id_fnb' 
                 and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'
                    ")->row_array();
           $stok_terjual = $order_fnb['qty'] == '' ? 0 : $order_fnb['qty'];

        array_push($kumpul_terjual, $stok_terjual);
        $total_harga_semua += $v['harga'];
        $total_stok_sebelumnya += $sisa_stok_sebelumnya;
        $baris = $row_start + $k;
        $no = $k+1;
        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris, $no);
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['produk']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, $v['harga']);
        $excel->setActiveSheetIndex(0)->setCellValue('D'.$baris, $sisa_stok_sebelumnya);
        $excel->getActiveSheet()->getStyle('A'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('B'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('C'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('D'.$baris)->applyFromArray($border);

        $excel->getActiveSheet()->getStyle('C'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

    $excel->getActiveSheet()->getStyle('D'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 
    $excel->getActiveSheet()->getStyle('A'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

        $total_stok_fnb = 0;
          for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 

                $tgl = $i-4;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_tgl = $this->numberToColumnName($i);

                $stok_fnb = $this->db->query("SELECT sum(qty) as qty from stok_fnb
                where id_fnb='$id_fnb' 
                and day(tgl_masuk)='$tgl' and month(tgl_masuk)='$bulan_order' and year(tgl_masuk)='$tahun_order'
                ")->row_array();
                $stok_masuk = $stok_fnb['qty'] == '' ? 0 : $stok_fnb['qty'];
                $total_stok_fnb += $stok_masuk;

                $kumpul_total_fnb[$index_jumlah][$k] =$stok_masuk; 

                    $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$baris, $stok_masuk);
                    $excel->getActiveSheet()->getStyle($kolom_tgl.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

                $excel->getActiveSheet()->getStyle($kolom_tgl.$baris)->applyFromArray($border);
                # code...
            }


    $sisa_stok_sampai_bulan_ini = $sisa_stok_sebelumnya + $total_stok_fnb;
       $total_stok_gabungan += $sisa_stok_sampai_bulan_ini ; 

    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.$baris, $sisa_stok_sampai_bulan_ini);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$baris)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$baris)->applyFromArray($border);


    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.$baris, $total_stok_fnb);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.$baris, $stok_terjual);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 



    $sisa_stok = $sisa_stok_sampai_bulan_ini - $stok_terjual;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.$baris, $sisa_stok);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
        
    }



    $kumpul_total_stok_semua = [];
     for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 


                $tgl = $i-4;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_tgl = $this->numberToColumnName($i);
                $json = json_encode($kumpul_total_fnb[$index_jumlah]);
                $total = array_sum($kumpul_total_fnb[$index_jumlah]);
                $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$row_data_terakhir, $total);
                array_push($kumpul_total_stok_semua, $total);
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->applyFromArray($border);

     }


    $total_stok_semua = array_sum($kumpul_total_stok_semua);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.$row_data_terakhir, $total_stok_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$row_data_terakhir)->applyFromArray($border);

    $total_terjual_semua = array_sum($kumpul_terjual);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.$row_data_terakhir, $total_terjual_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$row_data_terakhir)->applyFromArray($border);


    $total_stok_sisa = $total_stok_gabungan - $total_terjual_semua;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.$row_data_terakhir, $total_stok_sisa);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$row_data_terakhir)->applyFromArray($border);


    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.$row_data_terakhir, $total_stok_gabungan);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_sisa_stok.$row_data_terakhir)->getAlignment()->setWrapText(true); 

    $excel->setActiveSheetIndex(0)->setCellValue('A'.$row_data_terakhir, "Jumlah");
    $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $total_harga_semua);
    $excel->setActiveSheetIndex(0)->setCellValue('D'.$row_data_terakhir, $total_stok_sebelumnya);

    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    $excel->getActiveSheet()->getStyle('A'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->applyFromArray($border);

    // $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $json);
    $excel->getActiveSheet()->mergeCells('A'.$row_data_terakhir.':B'.$row_data_terakhir);
    // $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 





    $excel->getActiveSheet()->mergeCells('E3:'.$convert_kolom_merge_penambahan_stok.'3');
    // $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);

//         $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
//     $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 

// // Judul Laporan
//     $excel->getActiveSheet()->getStyle('A6:A7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

 

    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    















//      $excel->getActiveSheet()->getStyle('P'.$baris_mulai_paket)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    



    // Set width kolom
  // Set width kolom E
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export = $caption_judul.'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }




















  public function export_stok_tahunan(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    // Panggil class PHPExcel nya

    // Settingan awal fil excel
    // $excel->getProperties()->setCreator('My Notes Code')
    //              ->setLastModifiedBy('My Notes Code')
    //              ->setTitle("Data Siswa")
    //              ->setSubject("Siswa")
    //              ->setDescription("Laporan Semua Data Siswa")
    //              ->setKeywords("Data Siswa");

    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    // $fill_program = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'f0cdf5')
    //     )
    // );
    // $fill_kegiatan = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'FF99CC')
    //     )
    // );




// // Untuk judulnya
//     $excel->getActiveSheet()->mergeCells('A1:AR1');
//     $excel->getActiveSheet()->mergeCells('A2:AR2');
//     $excel->getActiveSheet()->mergeCells('A3:AR3');


    $bulan_order = $this->input->get('bulan');
    $tahun_order = $this->input->get('tahun');
    $caption_judul = "Laporan pengelolaan stok  fnb tahun ".$tahun_order;

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Produk");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "Harga");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "Sisa Stok Sampai Tahun Lalu");
    $excel->setActiveSheetIndex(0)->setCellValue('E3', "Penambahan Stok / Bulan");

    $excel->getActiveSheet()->mergeCells('A3:A4');
    $excel->getActiveSheet()->mergeCells('B3:B4');
    $excel->getActiveSheet()->mergeCells('C3:C4');
    $excel->getActiveSheet()->mergeCells('D3:D4');







    $banyak_bulan = 12 -1;
    $start_kolom = 5; //D
    $merge_kolom = $start_kolom + $banyak_bulan; //D




    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(12);


    // setting kolom tanggal
    $convert_kolom_merge_penambahan_stok = $this->numberToColumnName($merge_kolom);
    $kolom_total = $merge_kolom+1;
    $kolom_total_stok_semua = $kolom_total +1;  
    $kolom_terjual = $kolom_total_stok_semua+1;
    $kolom_sisa_stok = $kolom_terjual+1;
    $convert_kolom_sum_row = $this->numberToColumnName($kolom_total-1);
    $convert_kolom_total_stok = $this->numberToColumnName($kolom_total);
    $convert_kolom_total_stok_semua = $this->numberToColumnName($kolom_total_stok_semua);
    $convert_kolom_terjual = $this->numberToColumnName($kolom_terjual);
    $convert_kolom_sisa_stok = $this->numberToColumnName($kolom_sisa_stok);


    $excel->setActiveSheetIndex(0)->setCellValue('A5', "1");
    $excel->setActiveSheetIndex(0)->setCellValue('B5', "2");
    $excel->setActiveSheetIndex(0)->setCellValue('C5', "3");
    $excel->setActiveSheetIndex(0)->setCellValue('D5', "4");

    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D5')->applyFromArray($border);



    $row_kolom_angka = $start_kolom;
    for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 
    $row_kolom_angka +=1;
        $bulan = $i-4;
        $nama_bulan = substr(bulan_global($bulan), 0,3);
        $kolom_bulan = $this->numberToColumnName($i);
            $excel->getActiveSheet()->getColumnDimension($kolom_bulan)->setWidth(6);
            $excel->getActiveSheet()->getStyle($kolom_bulan.'3')->applyFromArray($border);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_bulan.'4', $nama_bulan);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_bulan.'5', $i);

            $excel->getActiveSheet()->getStyle($kolom_bulan.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($kolom_bulan.'5')->applyFromArray($border);
        # code...
    }
    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_stok)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.'3', "Total Stok Tahun Ini");
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.'3')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.'5')->applyFromArray($border);


    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_stok_semua)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.'3', "Total Stok Sampai Tahun Ini");
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.'3')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.'5')->applyFromArray($border);



    $row_kolom_total_stok = $merge_kolom+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.'5', $row_kolom_total_stok."=SUM(E".$start_kolom.":".$convert_kolom_sum_row."".$start_kolom.")");

    $excel->getActiveSheet()->getColumnDimension($convert_kolom_terjual)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.'3', "Stok Keluar Tahun Ini");

    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.'3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.'4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.'5')->applyFromArray($border);



    $row_kolom_stok_semua = $row_kolom_angka+1;
    $row_kolom_terjual = $row_kolom_stok_semua+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.'5', $row_kolom_terjual);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.'5', $row_kolom_stok_semua.'=4+'.$row_kolom_total_stok);

    $excel->getActiveSheet()->getColumnDimension($convert_kolom_sisa_stok)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.'3', "Sisa Stok");

    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.'3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.'4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.'5')->applyFromArray($border);



    $excel->getActiveSheet()->mergeCells($convert_kolom_total_stok.'3:'.$convert_kolom_total_stok.'4');
    $excel->getActiveSheet()->mergeCells($convert_kolom_total_stok_semua.'3:'.$convert_kolom_total_stok_semua.'4');
    $excel->getActiveSheet()->mergeCells($convert_kolom_terjual.'3:'.$convert_kolom_terjual.'4');





    $row_kolom_sisa = $row_kolom_terjual+1;
    $excel->getActiveSheet()->mergeCells($convert_kolom_sisa_stok.'3:'.$convert_kolom_sisa_stok.'4');
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.'5', $row_kolom_sisa."=".$row_kolom_stok_semua."-".$row_kolom_terjual);


    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_sisa_stok.'5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_sisa_stok.'5')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 







    $q_fnb = $this->db->query("SELECT id_fnb, jenis, produk, harga from fnb where status=1")->result_array();





    $row_start = 6;
    $row_data_terakhir = 6;

    $kumpul_total_fnb = [];
    $kumpul_terjual = [];
    $total_harga_semua =0;
    $total_stok_sebelumnya =0;
    $total_stok_gabungan = 0;


    $tahun_sebelumnya = $tahun_order - 1;
    foreach ($q_fnb as $k => $v) {
        $row_data_terakhir +=1;
        $id_fnb = $v['id_fnb'];

           $q_stok_sebelumnya = $this->db->query("SELECT sum(qty) as qty from stok_fnb
                    where id_fnb='$id_fnb' 
               and year(tgl_masuk)<='$tahun_sebelumnya'
                    ")->row_array();
           $stok_sebelumnya = $q_stok_sebelumnya['qty'] == '' ? 0 : $q_stok_sebelumnya['qty'];

           $q_order_sebelumnya = $this->db->query("SELECT sum(qty) as qty from order_fnb
                    where id_fnb='$id_fnb' 
                and year(tgl_order)<='$tahun_sebelumnya'
                    ")->row_array();
           $order_sebelumnya = $q_order_sebelumnya['qty'] == '' ? 0 : $q_order_sebelumnya['qty'];
           $sisa_stok_sebelumnya = $stok_sebelumnya - $order_sebelumnya;

        

           $order_fnb = $this->db->query("SELECT sum(qty) as qty from order_fnb
                    where id_fnb='$id_fnb' 
                 and year(tgl_order)='$tahun_order'
                    ")->row_array();
           $stok_terjual = $order_fnb['qty'] == '' ? 0 : $order_fnb['qty'];

        array_push($kumpul_terjual, $stok_terjual);
        $total_harga_semua += $v['harga'];
        $total_stok_sebelumnya += $sisa_stok_sebelumnya;
        $baris = $row_start + $k;
        $no = $k+1;
        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris, $no);
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['produk']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, $v['harga']);
        $excel->setActiveSheetIndex(0)->setCellValue('D'.$baris, $sisa_stok_sebelumnya);
        $excel->getActiveSheet()->getStyle('A'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('B'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('C'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('D'.$baris)->applyFromArray($border);

        $excel->getActiveSheet()->getStyle('C'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

    $excel->getActiveSheet()->getStyle('D'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 
    $excel->getActiveSheet()->getStyle('A'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

        $total_stok_fnb = 0;
          for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 

                $bulan = $i-4;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_bulan = $this->numberToColumnName($i);

                $stok_fnb = $this->db->query("SELECT sum(qty) as qty from stok_fnb
                where id_fnb='$id_fnb' 
                and month(tgl_masuk)='$bulan' and year(tgl_masuk)='$tahun_order'
                ")->row_array();
                $stok_masuk = $stok_fnb['qty'] == '' ? 0 : $stok_fnb['qty'];
                $total_stok_fnb += $stok_masuk;

                $kumpul_total_fnb[$index_jumlah][$k] =$stok_masuk; 

                    $excel->setActiveSheetIndex(0)->setCellValue($kolom_bulan.$baris, $stok_masuk);
                    $excel->getActiveSheet()->getStyle($kolom_bulan.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

                $excel->getActiveSheet()->getStyle($kolom_bulan.$baris)->applyFromArray($border);
                # code...
            }


    $sisa_stok_sampai_bulan_ini = $sisa_stok_sebelumnya + $total_stok_fnb;
       $total_stok_gabungan += $sisa_stok_sampai_bulan_ini ; 

    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.$baris, $sisa_stok_sampai_bulan_ini);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$baris)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$baris)->applyFromArray($border);


    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.$baris, $total_stok_fnb);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.$baris, $stok_terjual);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 



    $sisa_stok = $sisa_stok_sampai_bulan_ini - $stok_terjual;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.$baris, $sisa_stok);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
        
    }



    $kumpul_total_stok_semua = [];
     for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 


                $tgl = $i-4;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_tgl = $this->numberToColumnName($i);
                $json = json_encode($kumpul_total_fnb[$index_jumlah]);
                $total = array_sum($kumpul_total_fnb[$index_jumlah]);
                $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$row_data_terakhir, $total);
                array_push($kumpul_total_stok_semua, $total);
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->applyFromArray($border);

     }


    $total_stok_semua = array_sum($kumpul_total_stok_semua);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok.$row_data_terakhir, $total_stok_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok.$row_data_terakhir)->applyFromArray($border);

    $total_terjual_semua = array_sum($kumpul_terjual);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_terjual.$row_data_terakhir, $total_terjual_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_terjual.$row_data_terakhir)->applyFromArray($border);


    $total_stok_sisa = $total_stok_gabungan - $total_terjual_semua;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_sisa_stok.$row_data_terakhir, $total_stok_sisa);
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$row_data_terakhir)->applyFromArray($border);


    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_stok_semua.$row_data_terakhir, $total_stok_gabungan);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_stok_semua.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_sisa_stok.$row_data_terakhir)->getAlignment()->setWrapText(true); 

    $excel->setActiveSheetIndex(0)->setCellValue('A'.$row_data_terakhir, "Jumlah");
    $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $total_harga_semua);
    $excel->setActiveSheetIndex(0)->setCellValue('D'.$row_data_terakhir, $total_stok_sebelumnya);

    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    $excel->getActiveSheet()->getStyle('A'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->applyFromArray($border);

    // $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $json);
    $excel->getActiveSheet()->mergeCells('A'.$row_data_terakhir.':B'.$row_data_terakhir);
    // $excel->getActiveSheet()->getStyle($convert_kolom_sisa_stok.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 





    $excel->getActiveSheet()->mergeCells('E3:'.$convert_kolom_merge_penambahan_stok.'3');
    // $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);

//         $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
//     $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 

// // Judul Laporan
//     $excel->getActiveSheet()->getStyle('A6:A7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

 

    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    















//      $excel->getActiveSheet()->getStyle('P'.$baris_mulai_paket)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    



    // Set width kolom
  // Set width kolom E
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export = $caption_judul.'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }
















  public function export_order_bulanan(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    // Panggil class PHPExcel nya

    // Settingan awal fil excel
    // $excel->getProperties()->setCreator('My Notes Code')
    //              ->setLastModifiedBy('My Notes Code')
    //              ->setTitle("Data Siswa")
    //              ->setSubject("Siswa")
    //              ->setDescription("Laporan Semua Data Siswa")
    //              ->setKeywords("Data Siswa");

    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    // $fill_program = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'f0cdf5')
    //     )
    // );
    // $fill_kegiatan = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'FF99CC')
    //     )
    // );




// // Untuk judulnya
//     $excel->getActiveSheet()->mergeCells('A1:AR1');
//     $excel->getActiveSheet()->mergeCells('A2:AR2');
//     $excel->getActiveSheet()->mergeCells('A3:AR3');


    $bulan_order = $this->input->get('bulan');
    $tahun_order = $this->input->get('tahun');
    $caption_judul = "Laporan penjualan fnb bulan ".bulan_global(intval($bulan_order))." ".$tahun_order;

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Produk");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "Harga");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "Penjualan / Tgl");

    $excel->getActiveSheet()->mergeCells('A3:A4');
    $excel->getActiveSheet()->mergeCells('B3:B4');
    $excel->getActiveSheet()->mergeCells('C3:C4');







    $banyak_hari = jml_hari_dalam_bulan($bulan_order, $tahun_order) -1;
    $start_kolom = 4; //D
    $merge_kolom = $start_kolom + $banyak_hari; //D




    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(12);


    // setting kolom tanggal
    $convert_kolom_merge_penambahan_order = $this->numberToColumnName($merge_kolom);
    $kolom_total = $merge_kolom+1;
    $kolom_total_harga = $kolom_total+1;
    $convert_kolom_sum_row = $this->numberToColumnName($kolom_total-1);
    $convert_kolom_total_order = $this->numberToColumnName($kolom_total);
    $convert_kolom_total_harga = $this->numberToColumnName($kolom_total_harga);


    $excel->setActiveSheetIndex(0)->setCellValue('A5', "1");
    $excel->setActiveSheetIndex(0)->setCellValue('B5', "2");
    $excel->setActiveSheetIndex(0)->setCellValue('C5', "3");
    $excel->setActiveSheetIndex(0)->setCellValue('D5', "4");

    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('B3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D5')->applyFromArray($border);



    $row_kolom_angka = $start_kolom;
    for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 
    $row_kolom_angka +=1;
        $tgl = $i-3;
        $kolom_tgl = $this->numberToColumnName($i);
            $excel->getActiveSheet()->getColumnDimension($kolom_tgl)->setWidth(6);
            $excel->getActiveSheet()->getStyle($kolom_tgl.'3')->applyFromArray($border);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.'4', $tgl);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.'5', $i);

            $excel->getActiveSheet()->getStyle($kolom_tgl.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($kolom_tgl.'5')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($kolom_tgl.'4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
            $excel->getActiveSheet()->getStyle($kolom_tgl.'5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

        # code...
    }
    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_order)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.'3', "Banyak Terjual Bulan Ini");
            $excel->getActiveSheet()->getStyle($convert_kolom_total_order.'3')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_order.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_order.'5')->applyFromArray($border);





    $row_kolom_total_order = $merge_kolom+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.'5', $row_kolom_total_order."=SUM(E".$start_kolom.":".$convert_kolom_sum_row."".$start_kolom.")");

    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_harga)->setWidth(15);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.'3', "Total Harga");

    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'5')->applyFromArray($border);



    $row_kolom_total_harga = $row_kolom_angka+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.'5', $row_kolom_total_harga);




    $excel->getActiveSheet()->mergeCells($convert_kolom_total_order.'3:'.$convert_kolom_total_order.'4');
    $excel->getActiveSheet()->mergeCells($convert_kolom_total_harga.'3:'.$convert_kolom_total_harga.'4');

    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 





    $row_kolom_sisa = $row_kolom_total_harga+1;







    $q_fnb = $this->db->query("SELECT id_fnb, jenis, produk, harga from fnb where status=1")->result_array();





    $row_start = 6;
    $row_data_terakhir = 6;

    $kumpul_total_fnb = [];
    $kumpul_terjual = [];
    $total_harga_semua =0;
    $total_harga_penjualan_semua =0;
    $total_order_gabungan = 0;


    foreach ($q_fnb as $k => $v) {
        $row_data_terakhir +=1;
        $id_fnb = $v['id_fnb'];


        $total_harga_semua += $v['harga'];
        $baris = $row_start + $k;
        $no = $k+1;
        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris, $no);
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['produk']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, $v['harga']);
        $excel->getActiveSheet()->getStyle('A'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('B'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('C'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('D'.$baris)->applyFromArray($border);

        $excel->getActiveSheet()->getStyle('C'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

    $excel->getActiveSheet()->getStyle('D'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 
    $excel->getActiveSheet()->getStyle('A'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

        $total_terjual = 0;
          for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 

                $tgl = $i-3;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_tgl = $this->numberToColumnName($i);

                
            $id_fnb = $v['id_fnb'];
            $order_fnb = $this->db->query("SELECT  qty, action from order_fnb where status='1' and id_fnb='$id_fnb'
                and day(tgl_order)='$tgl' and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'")->result_array();
            $qty_fnb_terjual = 0 ; 
            $qty_fnb_entertain = 0 ; 
            $rp_fnb_terjual = 0 ; 
            foreach ($order_fnb as $k_fnb => $v_fnb) {
            $qty = $v_fnb['qty'];
               if ($v_fnb['action']=='Penjualan') {
                  $qty_fnb_terjual+=$qty;
                    $total = $v_fnb['qty'] * $v['harga'];
                  $rp_fnb_terjual+=$total;
               }else{
                  $qty_fnb_entertain +=$qty;

               }

            }
           


            // $order_fnb = $this->db->query("SELECT sum(qty) as qty from order_fnb
            //     where id_fnb='$id_fnb' 
            //     and day(tgl_order)='$tgl' and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'
            //     ")->row_array();
            //     $terjual = $order_fnb['qty'] == '' ? 0 : $order_fnb['qty'];
                $total_terjual += $qty_fnb_terjual;

                $kumpul_total_fnb[$index_jumlah][$k] = $qty_fnb_terjual; 

                    $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$baris, $qty_fnb_terjual);
                    $excel->getActiveSheet()->getStyle($kolom_tgl.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

                $excel->getActiveSheet()->getStyle($kolom_tgl.$baris)->applyFromArray($border);
                # code...
            }


    $total_harga = $total_terjual * $v['harga'];
    $total_harga_penjualan_semua += $total_harga;

    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.$baris, $total_terjual);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 


    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.$baris, $total_harga);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 

        $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

        
    }



    $kumpul_total_order_semua = [];
     for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 


                $tgl = $i-3;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_tgl = $this->numberToColumnName($i);
                $json = json_encode($kumpul_total_fnb[$index_jumlah]);
                $total = array_sum($kumpul_total_fnb[$index_jumlah]);
                $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$row_data_terakhir, $total);
                array_push($kumpul_total_order_semua, $total);
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->applyFromArray($border);

     }


    $total_order_semua = array_sum($kumpul_total_order_semua);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.$row_data_terakhir, $total_order_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$row_data_terakhir)->applyFromArray($border);

    $total_terjual_semua = array_sum($kumpul_terjual);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.$row_data_terakhir, $total_harga_penjualan_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);




    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_total_harga.$row_data_terakhir)->getAlignment()->setWrapText(true); 

    $excel->setActiveSheetIndex(0)->setCellValue('A'.$row_data_terakhir, "Jumlah");
    $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $total_harga_semua);

    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    $excel->getActiveSheet()->getStyle('A'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->applyFromArray($border);

    // $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $json);
    $excel->getActiveSheet()->mergeCells('A'.$row_data_terakhir.':B'.$row_data_terakhir);





    $excel->getActiveSheet()->mergeCells('D3:'.$convert_kolom_merge_penambahan_order.'3');
    // $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);

//         $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
//     $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 

// // Judul Laporan
//     $excel->getActiveSheet()->getStyle('A6:A7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

 

    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    















//      $excel->getActiveSheet()->getStyle('P'.$baris_mulai_paket)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    



    // Set width kolom
  // Set width kolom E
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export = $caption_judul.'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }

















  public function export_order_tahunan(){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    $excel = new PHPExcel();
     
        $excel->getSheet(0)->setTitle('Data '.date('Y-m-d H.i.s'));

    // Panggil class PHPExcel nya

    // Settingan awal fil excel
    // $excel->getProperties()->setCreator('My Notes Code')
    //              ->setLastModifiedBy('My Notes Code')
    //              ->setTitle("Data Siswa")
    //              ->setSubject("Siswa")
    //              ->setDescription("Laporan Semua Data Siswa")
    //              ->setKeywords("Data Siswa");

    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel
    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $border = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    // $fill_program = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'f0cdf5')
    //     )
    // );
    // $fill_kegiatan = array(
    //     'fill' => array(
    //         'type' => PHPExcel_Style_Fill::FILL_SOLID,
    //         'color' => array('rgb' => 'FF99CC')
    //     )
    // );




// // Untuk judulnya
//     $excel->getActiveSheet()->mergeCells('A1:AR1');
//     $excel->getActiveSheet()->mergeCells('A2:AR2');
//     $excel->getActiveSheet()->mergeCells('A3:AR3');


    $bulan_order = $this->input->get('bulan');
    $tahun_order = $this->input->get('tahun');
    $caption_judul = "Laporan penjualan fnb tahun ".$tahun_order;

    $excel->setActiveSheetIndex(0)->setCellValue('A1', $caption_judul);
    // $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->setActiveSheetIndex(0)->setCellValue('A3', "No");
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "Produk");
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "Harga");
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "Penjualan / Tgl");

    $excel->getActiveSheet()->mergeCells('A3:A4');
    $excel->getActiveSheet()->mergeCells('B3:B4');
    $excel->getActiveSheet()->mergeCells('C3:C4');







    $banyak_bulan = 12 -1 ;// jml_hari_dalam_bulan($bulan_order, $tahun_order) -1;
    $start_kolom = 4; //D
    $merge_kolom = $start_kolom + $banyak_bulan; //D




    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(12);


    // setting kolom tanggal
    $convert_kolom_merge_penambahan_order = $this->numberToColumnName($merge_kolom);
    $kolom_total = $merge_kolom+1;
    $kolom_total_harga = $kolom_total+1;
    $convert_kolom_sum_row = $this->numberToColumnName($kolom_total-1);
    $convert_kolom_total_order = $this->numberToColumnName($kolom_total);
    $convert_kolom_total_harga = $this->numberToColumnName($kolom_total_harga);


    $excel->setActiveSheetIndex(0)->setCellValue('A5', "1");
    $excel->setActiveSheetIndex(0)->setCellValue('B5', "2");
    $excel->setActiveSheetIndex(0)->setCellValue('C5', "3");
    $excel->setActiveSheetIndex(0)->setCellValue('D5', "4");

    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('B3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->getActiveSheet()->getStyle('A5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('B5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('D5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

    $excel->getActiveSheet()->getStyle('A4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D4')->applyFromArray($border);

    $excel->getActiveSheet()->getStyle('A5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C5')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D5')->applyFromArray($border);



    $row_kolom_angka = $start_kolom;
    for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 
    $row_kolom_angka +=1;
        $bulan = $i-3;
        $nama_bulan = substr(bulan_global($bulan), 0,3);
        $kolom_bulan = $this->numberToColumnName($i);
            $excel->getActiveSheet()->getColumnDimension($kolom_bulan)->setWidth(6);
            $excel->getActiveSheet()->getStyle($kolom_bulan.'3')->applyFromArray($border);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_bulan.'4', $nama_bulan);
            $excel->setActiveSheetIndex(0)->setCellValue($kolom_bulan.'5', $i);

            $excel->getActiveSheet()->getStyle($kolom_bulan.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($kolom_bulan.'5')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($kolom_bulan.'4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
            $excel->getActiveSheet()->getStyle($kolom_bulan.'5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

        # code...
    }
    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_order)->setWidth(8);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.'3', "Banyak Terjual Bulan Ini");
            $excel->getActiveSheet()->getStyle($convert_kolom_total_order.'3')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_order.'4')->applyFromArray($border);
            $excel->getActiveSheet()->getStyle($convert_kolom_total_order.'5')->applyFromArray($border);





    $row_kolom_total_order = $merge_kolom+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.'5', $row_kolom_total_order."=SUM(E".$start_kolom.":".$convert_kolom_sum_row."".$start_kolom.")");

    $excel->getActiveSheet()->getColumnDimension($convert_kolom_total_harga)->setWidth(15);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.'3', "Total Harga");

    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'3')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'4')->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'5')->applyFromArray($border);



    $row_kolom_total_harga = $row_kolom_angka+1;
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.'5', $row_kolom_total_harga);




    $excel->getActiveSheet()->mergeCells($convert_kolom_total_order.'3:'.$convert_kolom_total_order.'4');
    $excel->getActiveSheet()->mergeCells($convert_kolom_total_harga.'3:'.$convert_kolom_total_harga.'4');

    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.'5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 





    $row_kolom_sisa = $row_kolom_total_harga+1;







    $q_fnb = $this->db->query("SELECT id_fnb, jenis, produk, harga from fnb where status=1")->result_array();





    $row_start = 6;
    $row_data_terakhir = 6;

    $kumpul_total_fnb = [];
    $kumpul_terjual = [];
    $total_harga_semua =0;
    $total_harga_penjualan_semua =0;
    $total_order_gabungan = 0;


    foreach ($q_fnb as $k => $v) {
        $row_data_terakhir +=1;
        $id_fnb = $v['id_fnb'];


        $total_harga_semua += $v['harga'];
        $baris = $row_start + $k;
        $no = $k+1;
        $excel->setActiveSheetIndex(0)->setCellValue('A'.$baris, $no);
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$baris, $v['produk']);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$baris, $v['harga']);
        $excel->getActiveSheet()->getStyle('A'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('B'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('C'.$baris)->applyFromArray($border);
        $excel->getActiveSheet()->getStyle('D'.$baris)->applyFromArray($border);

        $excel->getActiveSheet()->getStyle('C'.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

    $excel->getActiveSheet()->getStyle('D'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 
    $excel->getActiveSheet()->getStyle('A'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

        $total_terjual = 0;
          for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 

              
                $bulan_order = $i-3;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_bulan = $this->numberToColumnName($i);

                   $id_fnb = $v['id_fnb'];
                    $order_fnb = $this->db->query("SELECT  qty, action from order_fnb where status='1' and id_fnb='$id_fnb'
                      and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'")->result_array();
                    $qty_fnb_terjual = 0 ; 
                    $qty_fnb_entertain = 0 ; 
                    $rp_fnb_terjual = 0 ; 
                    foreach ($order_fnb as $k_fnb => $v_fnb) {
                    $qty = $v_fnb['qty'];
                       if ($v_fnb['action']=='Penjualan') {
                          $qty_fnb_terjual+=$qty;
                            $total = $v_fnb['qty'] * $v['harga'];
                          $rp_fnb_terjual+=$total;
                       }else{
                          $qty_fnb_entertain +=$qty;

                       }

                    }



               //      $order_fnb = $this->db->query("SELECT sum(qty) as qty from order_fnb
               //  where id_fnb='$id_fnb' 
               // and month(tgl_order)='$bulan_order' and year(tgl_order)='$tahun_order'
               //  ")->row_array();
                // $qty_fnb_terjual    = $order_fnb['qty'] == '' ? 0 : $order_fnb['qty'];
                $total_terjual += $qty_fnb_terjual ;

                $kumpul_total_fnb[$index_jumlah][$k] = $qty_fnb_terjual; 

                    $excel->setActiveSheetIndex(0)->setCellValue($kolom_bulan.$baris, $qty_fnb_terjual );
                    $excel->getActiveSheet()->getStyle($kolom_bulan.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

                $excel->getActiveSheet()->getStyle($kolom_bulan.$baris)->applyFromArray($border);
                # code...
            }


    $total_harga = $total_terjual * $v['harga'];
    $total_harga_penjualan_semua += $total_harga;

    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.$baris, $total_terjual);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 


    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.$baris, $total_harga);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$baris)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 

        $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$baris)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);

        
    }



    $kumpul_total_order_semua = [];
     for ($i= $start_kolom; $i <= $merge_kolom ; $i++) { 


                $tgl = $i-3;
                $index_jumlah = $i-$start_kolom ; 
                $kolom_tgl = $this->numberToColumnName($i);
                $json = json_encode($kumpul_total_fnb[$index_jumlah]);
                $total = array_sum($kumpul_total_fnb[$index_jumlah]);
                $excel->setActiveSheetIndex(0)->setCellValue($kolom_tgl.$row_data_terakhir, $total);
                array_push($kumpul_total_order_semua, $total);
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
                $excel->getActiveSheet()->getStyle($kolom_tgl.$row_data_terakhir)->applyFromArray($border);

     }


    $total_order_semua = array_sum($kumpul_total_order_semua);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_order.$row_data_terakhir, $total_order_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_order.$row_data_terakhir)->applyFromArray($border);

    $total_terjual_semua = array_sum($kumpul_terjual);
    $excel->setActiveSheetIndex(0)->setCellValue($convert_kolom_total_harga.$row_data_terakhir, $total_harga_penjualan_semua);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); 
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle($convert_kolom_total_harga.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);




    $excel->getActiveSheet()->getStyle('A3:'.$convert_kolom_total_harga.$row_data_terakhir)->getAlignment()->setWrapText(true); 

    $excel->setActiveSheetIndex(0)->setCellValue('A'.$row_data_terakhir, "Jumlah");
    $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $total_harga_semua);

    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    $excel->getActiveSheet()->getStyle('A'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('B'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('C'.$row_data_terakhir)->applyFromArray($border);
    $excel->getActiveSheet()->getStyle('D'.$row_data_terakhir)->applyFromArray($border);

    // $excel->setActiveSheetIndex(0)->setCellValue('C'.$row_data_terakhir, $json);
    $excel->getActiveSheet()->mergeCells('A'.$row_data_terakhir.':B'.$row_data_terakhir);





    $excel->getActiveSheet()->mergeCells('D3:'.$convert_kolom_merge_penambahan_order.'3');
    // $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);

//         $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 
//     $excel->getActiveSheet()->getStyle('A9:AR12')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); 

// // Judul Laporan
//     $excel->getActiveSheet()->getStyle('A6:A7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); 

 

    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    // $excel->getActiveSheet()->getStyle('A9:AR11')->applyFromArray($border);
    















//      $excel->getActiveSheet()->getStyle('P'.$baris_mulai_paket)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    



    // Set width kolom
  // Set width kolom E
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    $excel->setActiveSheetIndex(0);

  
    $download_export = $caption_judul.'.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$download_export.'"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }





function numberToColumnName($number){
    $abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $abc_len = strlen($abc);

    $result_len = 1; // how much characters the column's name will have
    $pow = 0;
    while( ( $pow += pow($abc_len, $result_len) ) < $number ){
        $result_len++;
    }

    $result = "";
    $next = false;
    // add each character to the result...
    for($i = 1; $i<=$result_len; $i++){
        $index = ($number % $abc_len) - 1; // calculate the module

        // sometimes the index should be decreased by 1
        if( $next || $next = false ){
            $index--;
        }

        // this is the point that will be calculated in the next iteration
        $number = floor($number / strlen($abc));

        // if the index is negative, convert it to positive
        if( $next = ($index < 0) ) {
            $index = $abc_len + $index;
        }

        $result = $abc[$index].$result; // concatenate the letter
    }
    return $result;
}

























}
