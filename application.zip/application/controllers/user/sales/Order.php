<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
        ]);

        date_default_timezone_set('Asia/Jakarta');
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='3') {
            redirect('auth/login/kick');
        }
    }





    public function index()
    {
        $data['judul'] = 'Data Kredit Aktif';
        $data['breadchumb'] = ' <a  href="'.base_url('user/sales/order/stok').'" class="btn btn-default btn-sm" title="redirect ke menu laporan">
                Filter
              </a> 
              <a  href="'.base_url('user/sales/laporan/order_kredit/export').'" class="btn btn-warning btn-sm" title="Order baru">
                Print
              </a>
              <a  href="'.base_url('user/sales/order/kredit_lunas').'" class="btn btn-info btn-sm" title="Order baru">
                Data Kredit Lunas
              </a> 
              <a  href="'.base_url('user/sales/order/new').'" class="btn btn-info btn-sm" title="Order baru">
                Tambahkan Kredit baru
              </a>';
        $q = $this->db->query("SELECT  
         ok.id_order,ok.id_jenis_barang,ok.jenis_barang,ok.keterangan_barang,ok.harga,ok.angsuran,ok.lama_angsuran,ok.satuan_angsuran,ok.dp,ok.id_pelanggan,ok.status, ok.no_kontrak,
         p.nama, p.alamat, p.no_hp, p.usaha 
         from order_kredit ok  
         left join pelanggan p on ok.id_pelanggan = p.id_pelanggan
         where ok.status = 'Belum Lunas' order by ok.id_order desc")->result_array();
        $data['data'] = $q;
        $data['page'] = '';
        $this->template->load('template/user_adminlte','user/sales/order/order_kredit', $data);

    }
    public function kredit_lunas()
    {
        $data['page'] = 'kredit_lunas';
        $data['judul'] = 'Data Kredit Aktif';
        $data['breadchumb'] = ' <a  href="'.base_url('user/sales/order/').'" class="btn btn-info btn-sm" title="Kredit Belum Lunas">
                Data Kredit Belum Lunas
              </a>';
        $q = $this->db->query("SELECT  
         ok.id_order,ok.id_jenis_barang,ok.jenis_barang,ok.keterangan_barang,ok.harga,ok.angsuran,ok.lama_angsuran,ok.satuan_angsuran,ok.dp,ok.id_pelanggan,ok.status, ok.no_kontrak,
         p.nama, p.alamat, p.no_hp, p.usaha 
         from order_kredit ok  
         left join pelanggan p on ok.id_pelanggan = p.id_pelanggan
         where ok.status = 'Lunas' order by ok.id_order desc")->result_array();
        $data['data'] = $q;
        $this->template->load('template/user_adminlte','user/sales/order/order_kredit', $data);

    }

    public function new()
    {
        $data['judul'] = 'Order Baru';
        $data['breadchumb'] = '<a  href="'.base_url('user/sales/order/download_sk').'" class="btn btn-info btn-sm" title="Lihat Syarat Dan Ketenruan">
                Lihat Syarat Dan Ketenruan
              </a> <a  href="'.base_url('user/sales/order/').'" class="btn btn-info btn-sm" title="Kembali">
                Kembali
              </a>';
        $q = $this->db->query("SELECT  id_jenis_barang, jenis_barang from jenis_barang where status = 1")->result_array();
        $q_pel = $this->db->query("SELECT   id_pelanggan , nama, alamat, no_hp, usaha  from pelanggan")->result_array();
        $data['jenis_barang'] = $q;
        $data['pelanggan'] = $q_pel;
        $this->template->load('template/user_adminlte','user/sales/order/new', $data);

    }

    public function detail($id_order, $page='')
    {
        $data['breadchumb'] = '<a  href="'.base_url('user/sales/order/'.$page).'" class="btn btn-info btn-sm" title="Kembali">
                Kembali
              </a>';
      $id_order = enkripsi($id_order,'D');
        $q_order = $this->db->query("SELECT   p.id_pelanggan , p.nama, p.alamat, p.no_hp, p.usaha ,
o.id_order, o.no_kontrak, o.jenis_barang, o.keterangan_barang, o.harga, o.angsuran, o.lama_angsuran, o.satuan_angsuran, o.dp, o.status, o.mulai, o.selesai,
(SELECT max(angsuran_ke) from pembayaran where id_order=o.id_order) as angsuran_terakhir
         from order_kredit o left join pelanggan p  on o.id_pelanggan = p.id_pelanggan where o.id_order='$id_order'")->row_array();
        $q_pembayaran = $this->db->query("SELECT * from pembayaran where id_order = '$id_order' order by angsuran_ke desc")->result_array();
        $q_list_barang = $this->db->query("SELECT  jenis_barang, keterangan, harga  from item_kredit where id_order = '$id_order'")->result_array();
        $data['order'] = $q_order;
        $data['judul'] = 'Detail Order '.$q_order['nama'];
        $data['pembayaran'] = $q_pembayaran;
        $data['list_barang'] = $q_list_barang;
        $angsuran_terakhir = $q_order['angsuran_terakhir'];
        $angsuran_berikutnya = $angsuran_terakhir == '' ? 1 : $q_order['angsuran_terakhir'] + 1;
        $data['angsuran_berikutnya'] = $angsuran_berikutnya;
        $this->template->load('template/user_adminlte','user/sales/order/detail', $data);

    }

    public function print_kwitansi_all($id_order)
    {
        
      $id_order = enkripsi($id_order,'D');
        $q_order = $this->db->query("SELECT   p.id_pelanggan , p.nama, p.alamat, p.no_hp, p.usaha ,
o.id_order, o.no_kontrak, o.jenis_barang, o.keterangan_barang, o.harga, o.angsuran, o.lama_angsuran, o.satuan_angsuran, o.dp, o.status, o.mulai, o.selesai,
(SELECT max(angsuran_ke) from pembayaran where id_order=o.id_order) as angsuran_terakhir
         from order_kredit o left join pelanggan p  on o.id_pelanggan = p.id_pelanggan where o.id_order='$id_order'")->row_array();
        $q_pembayaran = $this->db->query("SELECT * from pembayaran where id_order = '$id_order'")->result_array();
        $q_item = $this->db->query("SELECT * from item_kredit where id_order = '$id_order'")->result_array();

  $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => 'A4',
            "margin_left" => 3,
            "margin_right" => 3,
            "margin_top" => 3,
            "margin_bottom" => 3,
            'orientation' => 'P',
            'tempDir' => '/tmp'
        ]);

        $kumpul_pembayaran = [];
        foreach ($q_pembayaran as $k => $v) {
            $kumpul_pembayaran[$v['angsuran_ke']] = [
                'terima_dari' => $v['penyetor'],
                'tanggal_bayar' => $v['tanggal_dibayar'],
                'angsuran_ke' => $v['angsuran_ke'],
                'dibayar' => $v['dibayar'],
            ];
        }
        $data['pembayaran']=$kumpul_pembayaran;
        $data['order']=$q_order;
        $data['item']=$q_item;
         $html =  $this->load->view('user/sales/order/print_kwitansi_all', $data, true);

        $mpdf->WriteHTML($html);
        // $mpdf->AutoPrint(true);
        $mpdf->Output('Kwitansi '.$q_order['nama'].'.pdf', 'I');

    }

    public function print_kontrak($id_order)
    {
        
      $id_order = enkripsi($id_order,'D');
        $q_order = $this->db->query("SELECT   p.id_pelanggan , p.nama, p.alamat, p.no_hp, p.usaha ,
o.id_order, o.no_kontrak, o.jenis_barang, o.keterangan_barang, o.harga, o.angsuran, o.lama_angsuran, o.satuan_angsuran, o.dp, o.status, o.mulai, o.selesai,
(SELECT max(angsuran_ke) from pembayaran where id_order=o.id_order) as angsuran_terakhir
         from order_kredit o left join pelanggan p  on o.id_pelanggan = p.id_pelanggan where o.id_order='$id_order'")->row_array();
        $q_pembayaran = $this->db->query("SELECT * from pembayaran where id_order = '$id_order'")->result_array();
        $q_item = $this->db->query("SELECT  jenis_barang,keterangan,harga,qty  from item_kredit where id_order = '$id_order'")->result_array();

  $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => [210, 110],
            "margin_left" => 3,
            "margin_right" => 3,
            "margin_top" => 3,
            "margin_bottom" => 3,
            'orientation' => 'P',
            'tempDir' => '/tmp'
        ]);

        $kumpul_pembayaran = [];
        foreach ($q_pembayaran as $k => $v) {
            $kumpul_pembayaran[$v['angsuran_ke']] = [
                'terima_dari' => $v['penyetor'],
                'tanggal_bayar' => $v['tanggal_bayar'],
                'angsuran_ke' => $v['angsuran_ke'],
                'dibayar' => $v['dibayar'],
            ];
        }
        $data['pembayaran']=$kumpul_pembayaran;
        $data['order']=$q_order;
        $data['item']=$q_item;
         $html =  $this->load->view('user/sales/order/print_kontrak', $data, true);

        $mpdf->WriteHTML($html);
        // $mpdf->AutoPrint(true);
        $mpdf->Output('Kontrak '.$q_order['nama'].'.pdf', 'I');

    }

    public function simpan_order()
    {
        $jenis_pel = $this->input->post('jenis_pel');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $nohp = $this->input->post('nohp');
        $usaha = $this->input->post('usaha');
        
        $no_kontrak = $this->input->post('no_kontrak');
             $angsuran = $this->input->post('angsuran');
        $dp = $this->input->post('dp');
        $lama = $this->input->post('lama');
        $jenis_angsuran = $this->input->post('jenis_angsuran');
        $tanggal = $this->input->post('tanggal');
        $tgl_mulai = $this->input->post('tgl_mulai');
        $tgl_selesai = $this->input->post('tgl_selesai');
        $data_pelanggan = [
        'nama'=>$nama,
        'alamat'=>$alamat,
        'no_hp'=>$nohp,
        'usaha'=>$usaha
        ];

        $this->db->trans_start();
        if ($jenis_pel=='') {
            $this->db->insert('pelanggan', $data_pelanggan);
            $id_pelanggan = $this->db->insert_id();
        }else{
            $id_pelanggan = $this->input->post('id_pel');
        }
        $data_order = [

        'no_kontrak'=>$no_kontrak,
        // 'id_jenis_barang'=>$id_jenis_barang,
        // 'jenis_barang'=>$jenis_barang,
        // 'keterangan_barang'=>$keterangan,
        // 'harga'=>$harga,
        'angsuran'=>$angsuran,
        'lama_angsuran'=>$lama,
        'satuan_angsuran'=>$jenis_angsuran,
        'dp'=>$dp,
        'mulai' =>$tgl_mulai, 
        'selesai' =>$tgl_selesai, 
        'id_pelanggan' =>$id_pelanggan, 
        'status' =>'Belum Lunas' 
];



        $jenis_barang = $this->input->post('jenis_barang');
        $keterangan = $this->input->post('keterangan');
        $harga = $this->input->post('harga');
        


        if (count($jenis_barang)>0) {
            $this->db->insert('order_kredit', $data_order);
                $id_order = $this->db->insert_id();
                $kumpul_barang = [];
                for ($i=0; $i < count($jenis_barang) ; $i++) { 
                    $pecah_jenis = explode('|', $jenis_barang[$i]);
                    $data = [
                        'id_pelanggan'=>$pecah_jenis[0],
                        'id_order   '=>$id_order,
                        'id_jenis_barang'=>$pecah_jenis[0],
                        'jenis_barang'=>$pecah_jenis[1],
                        'keterangan'=>$keterangan[$i],
                        'harga'=>$harga[$i],
                    ];
                    array_push($kumpul_barang, $data);
                }
            $this->db->insert_batch('item_kredit', $kumpul_barang);
              $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Order Disimpan</div>');
                $this->db->trans_commit();

            $redirect = 'user/sales/order/detail/'.enkripsi($id_order);
            # code...
        }else{
              $this->db->trans_rollback();
            $redirect = 'user/sales/order/new';
              $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Order Gagal Disimpan<br>Anda belum memasukan item barang kredit</div>');

        }
        
            
            redirect($redirect);
    }
    public function simpan_pembayaran()
    {
        $tanggal = $this->input->post('tanggal');
        $id_order = $this->input->post('id_order');
        $ke = $this->input->post('ke');
        $dibayar = $this->input->post('dibayar');
        $penyetor = $this->input->post('penyetor');
        $angsuran = $this->input->post('angsuran');
        $id_pelanggan = $this->input->post('id_pelanggan');
        $id_user = $this->session->userdata('id_hak_akses');
        $status_kredit = $this->input->post('status_kredit');
       

       $banyak_angsuran =  intval($dibayar / $angsuran);

       $kumpul_pembayaran = [];
       if ($banyak_angsuran == 0) {
            $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Pembayaran Gagal Disimpan</div>');
            $redirect = 'user/sales/order/detail/'.enkripsi($id_order);
       }else{
       for ($i=0; $i < $banyak_angsuran; $i++) { 
        $angsuran_ke = $ke+$i;
            $data = [
            'id_order'=>$id_order,
            'id_pelanggan'=>$id_pelanggan,
            'dibayar'=>$angsuran,
            'angsuran_ke'=>$angsuran_ke,
            'penyetor'=>$penyetor,
            'tanggal_dibayar'=>$tanggal,
            'id_user'=>$id_user,
            ];
          array_push($kumpul_pembayaran, $data);
       }




        $this->db->insert_batch('pembayaran', $kumpul_pembayaran);
        if ($status_kredit=='Lunas') {
            $this->db->update('order_kredit', ['status'=>'Lunas'], ['id_order'=>$id_order]);
        $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Pembayaran Disimpan<br>Status kredit telah lunas</div>');
            $redirect = 'user/sales/order/';
        }else{
        $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Pembayaran Disimpan</div>');
            $redirect = 'user/sales/order/detail/'.enkripsi($id_order);
        }

        
       }
                    
        redirect($redirect);
    }
    public function ringkasan(){
        $tgl = $this->input->post('tanggal');
        $lama = $this->input->post('lama');


        $jenis_barang = $this->input->post('jenis_barang');
        $keterangan = $this->input->post('keterangan');
        $harga = $this->input->post('harga');
        
        $kumpul_barang = [];
        for ($i=0; $i < count($jenis_barang) ; $i++) { 
            $pecah_jenis = explode('|', $jenis_barang[$i]);
            $data = [
                'jenis_barang'=>$pecah_jenis[1],
                'keterangan'=>$keterangan[$i],
                'harga'=>$harga[$i],
            ];
            array_push($kumpul_barang, $data);
        }



            $mulai = date('Y-m-d', strtotime($tgl .' +1 day'));
            $next_date = date('Y-m-d', strtotime($tgl .' +'.$lama.' day'));
            $output = ['selesai'=>$next_date,'mulai'=>$mulai, 'barang'=>$kumpul_barang];
            echo json_encode($output);
    }


    function download_sk(){
    $isi = 'Here is some text!';
    $nama_file = 'file/kontrak/chart.pdf';
force_download($nama_file, NULL);
}



}
