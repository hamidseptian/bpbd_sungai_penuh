<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Voucher extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model', 
        ]);

        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - voucher';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah voucher
              </button>';
        $q = $this->db->query("SELECT  v.id_voucher ,v.jenis,v.besar_voucher, v.keterangan, v.nama_voucher, v.status, v.peruntukan,
            v.id_jenis_member, v.id_kelas, v.id_detail_kelas,
            jm.jenis_member, k.kelas, dk.nama_paket_kelas
            from voucher v
            left join jenis_member jm on v.id_jenis_member = jm.id_jenis_member
            left join kelas k on v.id_kelas = k.id_kelas
            left join detail_kelas dk on v.id_detail_kelas = dk.id_detail_kelas

            ")->result_array();
        $data['voucher'] = $q;
        $this->template->load('template/user_adminlte','user/admin/voucher/data_voucher', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_voucher = $this->input->post('id_voucher');
            $q = $this->db->query("SELECT  id_voucher ,jenis,besar_voucher, keterangan, nama_voucher, status, peruntukan, id_jenis_member, id_kelas, id_detail_kelas from voucher where id_voucher='$id_voucher'")->row_array();
            $output = [
                'id_voucher'=>$q['id_voucher'],
                'jenis'=>$q['jenis'],
                'besar_voucher'=>$q['besar_voucher'],
                'keterangan'=>str_replace('<br />', '', $q['keterangan']),
                'nama_voucher'=>$q['nama_voucher'],
                'status'=>$q['status'],
                'peruntukan'=>$q['peruntukan'],
                'id_jenis_member'=>$q['id_jenis_member'],
                'id_kelas'=>$q['id_kelas'],
                'id_detail_kelas'=>$q['id_detail_kelas'],
            ];
            echo json_encode($output);
		// $this->load->view('template/admin');
	}


    public function pilihan_member()
    {
        
            $q = $this->db->query("SELECT id_jenis_member, jenis_member from jenis_member where status='1' and id_jenis_member !='1'")->result_array();
            $output = [
                'data'=>$q,
            ];
            echo json_encode($output);
        // $this->load->view('template/admin');
    }



    public function pilihan_kelas()
    {
        
            $q = $this->db->query("SELECT id_kelas, kelas from kelas where status='1'")->result_array();
            $output = [
                'data'=>$q,
            ];
            echo json_encode($output);
        // $this->load->view('template/admin');
    }

    public function paket_kelas()
    {
        $id_kelas = $this->input->post('id_kelas');
            
            $q_kelas = $this->db->query("SELECT kelas from kelas where id_kelas='$id_kelas'")->row_array();
            $q = $this->db->query("SELECT id_detail_kelas, nama_paket_kelas from detail_kelas where id_kelas='$id_kelas' and status='1'")->result_array();
            $output = [
                'data'=>$q,
                'kelas'=>$q_kelas['kelas'],
            ];
            echo json_encode($output);
        // $this->load->view('template/admin');
    }




    public function simpan(){
     
     $jenis = $this->input->post('jenis');
     $voucher = $this->input->post('voucher');
     $nama_voucher = $this->input->post('nama_voucher');
     $keterangan = $this->input->post('keterangan');
     $peruntukan = $this->input->post('peruntukan');
     $id_jenis_member = $this->input->post('id_jenis_member');
     $kelas = $this->input->post('kelas');
     $paket_kelas = $this->input->post('paket_kelas');

     if ($peruntukan=='Membership') {
         $data = [
            'jenis'=>$jenis,
            'besar_voucher'=>$voucher,
            'nama_voucher'=>$nama_voucher,
            'keterangan'=>nl2br($keterangan),
            'peruntukan'=>$peruntukan,
            'id_jenis_member'=>$id_jenis_member,
            'status '=>1
         ];
         $this->db->insert('voucher', $data);
        $this->session->set_flashdata('pesan','<div class="alert alert-info">Data voucher Disimpan</div>');
         
     }
     elseif ($peruntukan=='Kelas') {
        if ($kelas=='semua') {
               
             $data = [
                'jenis'=>$jenis,
                'besar_voucher'=>$voucher,
                'nama_voucher'=>$nama_voucher,
                'keterangan'=>nl2br($keterangan),
                'peruntukan'=>$peruntukan,
                'id_kelas'=>$kelas,
                'status '=>1
             ];
        }else{

             $data = [
                'jenis'=>$jenis,
                'besar_voucher'=>$voucher,
                'nama_voucher'=>$nama_voucher,
                'keterangan'=>nl2br($keterangan),
                'peruntukan'=>$peruntukan,
                'id_kelas'=>$kelas,
                'id_detail_kelas'=>$paket_kelas,
                'status '=>1
             ];
        }
         $this->db->insert('voucher', $data);
         
     }else{
        $this->session->set_flashdata('pesan','<div class="alert alert-info">Data voucher Disimpan</div>');
        $this->session->set_flashdata('pesan','<div class="alert alert-danger">Data voucher gagal disimpan</div>');

     }

            redirect('user/admin/voucher');

    }




    public function simpanedit(){
     
     $jenis = $this->input->post('jenis');
     $voucher = $this->input->post('voucher');
     $nama_voucher = $this->input->post('nama_voucher');
     $keterangan = $this->input->post('keterangan');
     $peruntukan = $this->input->post('peruntukan');
     $id_jenis_member = $this->input->post('id_jenis_member');
     $kelas = $this->input->post('kelas');
     $paket_kelas = $this->input->post('paket_kelas');

     $id_voucher = $this->input->post('id_voucher');
 $where = [
        'id_voucher'=>$id_voucher,
     ];

     if ($peruntukan=='Membership') {
         $data = [
            'jenis'=>$jenis,
            'besar_voucher'=>$voucher,
            'nama_voucher'=>$nama_voucher,
            'keterangan'=>nl2br($keterangan),
            'peruntukan'=>$peruntukan,
            'id_jenis_member'=>$id_jenis_member,
            'status '=>1
         ];
         
         $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data voucher Diperbaharui</div>');
         
              $this->db->update('voucher', $data, $where);
     }
     elseif ($peruntukan=='Kelas') {
        if ($kelas=='semua') {
               
             $data = [
                'jenis'=>$jenis,
                'besar_voucher'=>$voucher,
                'nama_voucher'=>$nama_voucher,
                'keterangan'=>nl2br($keterangan),
                'peruntukan'=>$peruntukan,
                'id_kelas'=>$kelas,
                'status '=>1
             ];
        }else{

             $data = [
                'jenis'=>$jenis,
                'besar_voucher'=>$voucher,
                'nama_voucher'=>$nama_voucher,
                'keterangan'=>nl2br($keterangan),
                'peruntukan'=>$peruntukan,
                'id_kelas'=>$kelas,
                'id_detail_kelas'=>$paket_kelas,
                'status '=>1
             ];
        }
              $this->db->update('voucher', $data, $where);
         
         $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data voucher Diperbaharui</div>');
     }else{
         $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data voucher gagal diperbaharui</div>');

     }

            redirect('user/admin/voucher');

    }





    public function hapus()
    {
                $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data voucher Dinonaktifkan</div>');
            $id_voucher = $this->input->post('id_voucher');
            $q = $this->db->query("UPDATE voucher set status='0' where id_voucher='$id_voucher'");
            
        
    }


}
