<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class instruktur extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model', 
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }






    public function simpan(){
        $config['upload_path']          = './file/instruktur';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $new_file_name=date("Ymdhi");
        // $config['file_name']            = $new_file_name;
        $nama_file = $_FILES['berkas']['name'] ;
        $pecah = explode(".", $nama_file);
        $extensi = end($pecah);
        $new_file_name=date("Ymdhi").'.'.$extensi;
        $config['file_name']            = $new_file_name;
            $config['max_size']         = '10000';


     $id_user = $this->session->userdata('id_user');



        $nama = $this->input->post('nama');
        $tgll = $this->input->post('thll').'-'.$this->input->post('blll').'-'.$this->input->post('tgll');
        $jk = $this->input->post('jk');
        $alamat = $this->input->post('alamat');
        $nohp = $this->input->post('nohp');
        $email = $this->input->post('email');

      

        $ig = $this->input->post('ig');
        $tmpl = $this->input->post('tmpl');
        $pekerjaan = $this->input->post('pekerjaan');

  
      

        $this->load->library('upload', $config);
      
    
        if ( ! $this->upload->do_upload('berkas')){
            if ($nama_file=='') {
                 $data_insert = [
                    'id_user'=>$id_user,
                    'nama'=>$nama,
                    'tmpl'=>$tmpl,
                    'tgll'=>$tgll,
                    'pekerjaan'=>$pekerjaan,
                    'ig'=>$ig,
                    'jk'=>$jk,
                    'alamat'=>$alamat,
                    'no_hp'=>$nohp,
                    'email'=>$email,
                    'status'=>1,
                ];
                $error = 0;
                $pesan = "Data instruktur disimpan tanpa foto";

            $warna = 'alert alert-success';
              
            }else{
                
                $error = 1;
                $pesan_ERROR = $this->upload->display_errors();
                $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;

            }


        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong><br>Data instruktur disimpan dengan foto";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/admin/instruktur';

             $data_insert = [
                    'id_user'=>$id_user,
                    'nama'=>$nama,
                    'tmpl'=>$tmpl,
                    'tgll'=>$tgll,
                    'pekerjaan'=>$pekerjaan,
                    'ig'=>$ig,
                    'jk'=>$jk,
                    'alamat'=>$alamat,
                    'no_hp'=>$nohp,
                    'email'=>$email,
                    'foto'=>$new_file_name,
                    'status'=>1,
               
              
            ];
        }


            if ($error>0) {
                $redirect = 'user/admin/instruktur';
            }else{
                    $this->db->insert('instruktur', $data_insert);

                $redirect = 'user/admin/instruktur';
          $this->session->set_flashdata('pesan','<div class="'.$warna.'"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'.$pesan.'</div>');
        // echo json_encode($output);

    }
            redirect($redirect);
}


    public function simpanedit(){
        $config['upload_path']          = './file/instruktur';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $new_file_name=date("Ymdhi");
        // $config['file_name']            = $new_file_name;
        $nama_file = $_FILES['berkas']['name'] ;
        $pecah = explode(".", $nama_file);
        $extensi = end($pecah);
        $new_file_name=date("Ymdhi").'.'.$extensi;
        $config['file_name']            = $new_file_name;
            $config['max_size']         = '10000';


     $id_user = $this->session->userdata('id_user');



        $nama = $this->input->post('nama');
        $tgll = $this->input->post('thll').'-'.$this->input->post('blll').'-'.$this->input->post('tgll');
        $jk = $this->input->post('jk');
        $alamat = $this->input->post('alamat');
        $nohp = $this->input->post('nohp');
        $email = $this->input->post('email');

      

        $ig = $this->input->post('ig');
        $tmpl = $this->input->post('tmpl');
        $pekerjaan = $this->input->post('pekerjaan');
        $status = $this->input->post('status');
        $foto_lama = $this->input->post('foto_lama');
        $id_instruktur = $this->input->post('id_instruktur');

  
        $where = ['id_instruktur'=>$id_instruktur];

        $this->load->library('upload', $config);
      
    
        if ( ! $this->upload->do_upload('berkas')){
            if ($nama_file=='') {
                 $data_insert = [
                    'id_user'=>$id_user,
                    'nama'=>$nama,
                    'tmpl'=>$tmpl,
                    'tgll'=>$tgll,
                    'pekerjaan'=>$pekerjaan,
                    'ig'=>$ig,
                    'jk'=>$jk,
                    'alamat'=>$alamat,
                    'no_hp'=>$nohp,
                    'email'=>$email,
                    'status'=>$status,
                ];
                $error = 0;
                $pesan = "Data instruktur disimpan tanpa foto";

            $warna = 'alert alert-success';
              
            }else{
                
                $error = 1;
                $pesan_ERROR = $this->upload->display_errors();
                $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;

            }


        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong><br>Data instruktur disimpan dengan foto";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/admin/instruktur';

             $data_insert = [
                    'id_user'=>$id_user,
                    'nama'=>$nama,
                    'tmpl'=>$tmpl,
                    'tgll'=>$tgll,
                    'pekerjaan'=>$pekerjaan,
                    'ig'=>$ig,
                    'jk'=>$jk,
                    'alamat'=>$alamat,
                    'no_hp'=>$nohp,
                    'email'=>$email,
                    'foto'=>$new_file_name,
                    'status'=>$status,
               
              
            ];

        }


            if ($error>0) {
                $redirect = 'user/admin/instruktur';
            }else{
                    $this->db->update('instruktur', $data_insert, $where);
                    if ($foto_lama!='') {
                    unlink('./file/instruktur/'.$foto_lama);
                        # code...
                    }

                $redirect = 'user/admin/instruktur';
          $this->session->set_flashdata('pesan','<div class="'.$warna.'"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'.$pesan.'</div>');
        // echo json_encode($output);

    }
            redirect($redirect);
}



    public function index()
    {
        $data['judul'] = 'Master Data - Instruktur';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah Instruktur
              </button>';
        $q = $this->db->query("SELECT  id_instruktur,nama,alamat, no_hp, tmpl,tgll, email, ig, jk, no_hp, status, foto from instruktur ")->result_array();
        $data['instruktur'] = $q;
        $this->template->load('template/user_adminlte','user/admin/instruktur/data_instruktur', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_instruktur = $this->input->post('id_instruktur');
            $q = $this->db->query("SELECT id_instruktur, nama, tmpl, tgll, pekerjaan, ig, jk, alamat, no_hp, email, foto, status  from instruktur where id_instruktur='$id_instruktur'")->row_array();
            echo json_encode($q);
		// $this->load->view('template/admin');
	}


    public function edit_instruktur_kelas()
    {
        
            $id_kelas_instruktur = $this->input->post('id_kelas_instruktur');
            $q = $this->db->query("SELECT id_instruktur_kelas , id_detail_kelas, id_kelas,tgl_awal, tgl_akhir  from instruktur_kelas where id_instruktur_kelas='$id_kelas_instruktur'")->row_array();

        $q_kelas = $this->db->query("SELECT k.kelas, dk.nama_paket_kelas , dk.id_detail_kelas, dk.id_kelas
            from detail_kelas dk 
            left join kelas k on dk.id_kelas = k.id_kelas
            ")->result_array();
            $output = [
                'data' =>$q,
                'list_kelas'=>$q_kelas,
            ];
            echo json_encode($output);
        // $this->load->view('template/admin');
    }




    public function nonaktifkan()
    {
            $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Instruktur Dinonaktifkan</div>');
            $id_instruktur = $this->input->post('id_instruktur');
            $q = $this->db->query("UPDATE instruktur set status='0' where id_instruktur='$id_instruktur'");
            
        
    }

    public function hapus_kelas_instruktur()
    {
            $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Instruktur Kelas dihapus</div>');
            $id_kelas_instruktur = $this->input->post('id_kelas_instruktur');
            $q = $this->db->query("DELETE from instruktur_kelas where id_instruktur_kelas='$id_kelas_instruktur'");
            
        
    }



    public function detail($id_instruktur)
    {
        $data['breadchumb'] = '

              <a href="'.base_url('user/admin/instruktur/').'" class="btn btn-info btn-sm" >Kembali</a>
               <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah Kelas instruktur
              </button>';

        $id_instruktur = enkripsi($id_instruktur, 'D');
        $q = $this->db->query("SELECT   id_instruktur,nama,alamat, no_hp, tmpl,tgll, email, ig, jk, no_hp, status, foto from instruktur where id_instruktur='$id_instruktur'")->row_array();
        $q_detail = $this->db->query("SELECT 
            ik.id_instruktur_kelas, ik.id_instruktur, k.kelas, dk.nama_paket_kelas, ik.tgl_awal, ik.tgl_akhir, ik.status, ik.id_detail_kelas
         from instruktur_kelas ik
            left join kelas k on ik.id_kelas=k.id_kelas
            left join detail_kelas dk on ik.id_detail_kelas = dk.id_detail_kelas 
         where id_instruktur='$id_instruktur'")->result_array();

        $q_kelas = $this->db->query("SELECT k.kelas, k.id_kelas
            from kelas k 
            where id_kelas not in (SELECT id_kelas from instruktur_kelas where status=1 and id_instruktur='$id_instruktur')
            ")->result_array();
        $data['judul'] = 'Master Data - instruktur <br><small>Detail instruktur '.$q['nama'].'</small>';
        $data['instruktur'] = $q;
        $data['status'] = ['Tidak Aktif','Aktif'];
        $data['instruktur_kelas'] = $q_detail;
        $data['kelas'] = $q_kelas;
        $this->template->load('template/user_adminlte','user/admin/instruktur/detail_instruktur', $data);

        // $this->load->view('template/user_adminlte');
    }





    public function simpan_kelas_instruktur(){
     
     // $id_detail_kelas = $this->input->post('id_detail_kelas');
     $id_kelas = $this->input->post('id_kelas');
     // $pecah = explode('|', $id_detail_kelas);
     // $id_detail_kelas = $pecah[0];
     // $id_kelas = $pecah[1];
     $id_instruktur = $this->input->post('id_instruktur');
     
     $data = [
        // ' id_detail_kelas'=>$id_detail_kelas,
        ' id_kelas'=>$id_kelas,
        'id_instruktur'=>$id_instruktur,
      
        'status'=>1
     ];
     if ($id_kelas=='') {
     $this->session->set_flashdata('pesan','<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data kelas instruktur gagal disimpan<br>Harap pilih kelas yang tersedia</div>');
            redirect('user/admin/instruktur/detail/'.enkripsi($id_instruktur));
     	// code...
     }else{

     $this->db->insert('instruktur_kelas', $data);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data kela s instruktur disimpan</div>');
            redirect('user/admin/instruktur/detail/'.enkripsi($id_instruktur));
     }

    }

    public function simpanedit_kelas_instruktur(){
     
     $id_detail_kelas = $this->input->post('id_detail_kelas');
     $id_instruktur_kelas = $this->input->post('id_instruktur_kelas');
     $pecah = explode('|', $id_detail_kelas);
     $id_detail_kelas = $pecah[0];
     $id_kelas = $pecah[1];
     $id_instruktur = $this->input->post('id_instruktur');
     $status = $this->input->post('status');
        $where = ['id_instruktur_kelas' =>$id_instruktur_kelas];
     $data = [
        'id_detail_kelas'=>$id_detail_kelas,
        'id_kelas'=>$id_kelas,
        'id_instruktur'=>$id_instruktur,
        'status'=>1
     ];
     $this->db->update('instruktur_kelas', $data, $where);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data kela sinstruktur disimpan</div>');
            redirect('user/admin/instruktur/detail/'.enkripsi($id_instruktur));

    }

}
