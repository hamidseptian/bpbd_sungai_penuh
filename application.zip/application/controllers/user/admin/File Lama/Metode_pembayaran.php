<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Metode_pembayaran extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model', 
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - Metode Pembayaran';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah_metode">
                Tambah Metode Pembayaran
              </button>';
        $q = $this->db->query("SELECT  id_metode_pembayaran,metode_pembayaran,status from metode_pembayaran ")->result_array();
        $data['metode_pembayaran'] = $q;
        $this->template->load('template/user_adminlte','user/admin/metode_pembayaran/data_metode_pembayaran', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_metode_pembayaran = $this->input->post('id_metode_pembayaran');
            $q = $this->db->query("SELECT id_metode_pembayaran,metode_pembayaran,status from metode_pembayaran where id_metode_pembayaran='$id_metode_pembayaran'")->row_array();
            echo json_encode($q);
		// $this->load->view('template/admin');
	}




    public function simpan(){
     
     $metode = $this->input->post('metode_pembayaran');
     $data = [
        'metode_pembayaran'=>$metode,
        'status'=>1
     ];
     $this->db->insert('metode_pembayaran', $data);
      $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Metode Pembayaran Disimpan</div>');
            redirect('user/admin/metode_pembayaran');

    }
    public function simpanedit(){
     
     $metode = $this->input->post('metode_pembayaran');
     $status = $this->input->post('status');
     $id_metode = $this->input->post('id_metode_pembayaran');
     $data = [
        'metode_pembayaran'=>$metode,
        'status'=>$status
     ];
     $where = [
        'id_metode_pembayaran'=>$id_metode,
     ];
     $this->db->update('metode_pembayaran', $data, $where);
      $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Metode Pembayaran Diperbaharui</div>');
            redirect('user/admin/metode_pembayaran');

    }


    public function hapus()
    {
            $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Metode Pembayaran Dinonaktifkan</div>');
            $id_metode_pembayaran = $this->input->post('id_metode_pembayaran');
            $q = $this->db->query("UPDATE metode_pembayaran set status='0' where id_metode_pembayaran='$id_metode_pembayaran'");
            
        
    }


}
