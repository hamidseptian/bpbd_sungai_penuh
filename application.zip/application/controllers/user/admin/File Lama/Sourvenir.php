<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sourvenir extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - Sourvenir';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah sourvenir
              </button>';
        $q = $this->db->query("SELECT  id_sourvenir ,jenis,produk, harga, modal, status from sourvenir ")->result_array();
        $data['sourvenir'] = $q;
        $this->template->load('template/user_adminlte','user/admin/sourvenir/data_sourvenir', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_sourvenir = $this->input->post('id_sourvenir');
            $q = $this->db->query("SELECT  id_sourvenir ,jenis,produk, harga, modal, status from sourvenir where id_sourvenir='$id_sourvenir'")->row_array();
            echo json_encode($q);
		// $this->load->view('template/admin');
	}




    public function simpan(){
     
     $jenis = $this->input->post('jenis');
     $sourvenir = $this->input->post('sourvenir');
     $harga = $this->input->post('harga');
     $modal = $this->input->post('modal');
     $data = [
        'jenis'=>$jenis,
        'produk'=>$sourvenir,
        'modal'=>$modal,
        'harga'=>$harga,
        'status '=>1
     ];
     $this->db->insert('sourvenir', $data);
        $this->session->set_flashdata('pesan','<div class="alert alert-info">Data Sourvenir Disimpan</div>');
            redirect('user/admin/sourvenir');

    }
    public function simpanedit(){
     
     $id_sourvenir = $this->input->post('id_sourvenir');
     $jenis = $this->input->post('jenis');
     $sourvenir = $this->input->post('sourvenir');
     $harga = $this->input->post('harga');
     $modal = $this->input->post('modal');
     $status = $this->input->post('status');
     $data = [
         'jenis'=>$jenis,
        'produk'=>$sourvenir,
        'modal'=>$modal,
        'harga'=>$harga,
        'status'=>$status,
        
        'updated_at'=>date('Y-m-d H:i:s')
     ];
     $where = [
        'id_sourvenir'=>$id_sourvenir,
     ];
     $this->db->update('sourvenir', $data, $where);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Sourvenir Diperbaharui</div>');
            redirect('user/admin/sourvenir');

    }


    public function hapus()
    {
                $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Sourvenir Dinonaktifkan</div>');
            $id_sourvenir = $this->input->post('id_sourvenir');
            $q = $this->db->query("UPDATE sourvenir set status = '0' where id_sourvenir='$id_sourvenir'");
            
        
    }


}
