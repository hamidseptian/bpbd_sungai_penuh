<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Diskon extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model', 
        ]);

        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - Diskon';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah diskon
              </button>';
        $q = $this->db->query("SELECT  id_diskon ,jenis,besar_diskon, keterangan, nama_diskon, status from diskon ")->result_array();
        $data['diskon'] = $q;
        $this->template->load('template/user_adminlte','user/admin/diskon/data_diskon', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_diskon = $this->input->post('id_diskon');
            $q = $this->db->query("SELECT  id_diskon ,jenis,besar_diskon, keterangan, nama_diskon, status from diskon where id_diskon='$id_diskon'")->row_array();
            $output = [
                'id_diskon'=>$q['id_diskon'],
                'jenis'=>$q['jenis'],
                'besar_diskon'=>$q['besar_diskon'],
                'keterangan'=>str_replace('<br />', '', $q['keterangan']),
                'nama_diskon'=>$q['nama_diskon'],
                'status'=>$q['status'],
            ];
            echo json_encode($output);
		// $this->load->view('template/admin');
	}




    public function simpan(){
     
     $jenis = $this->input->post('jenis');
     $diskon = $this->input->post('diskon');
     $nama_diskon = $this->input->post('nama_diskon');
     $keterangan = $this->input->post('keterangan');
     $data = [
        'jenis'=>$jenis,
        'besar_diskon'=>$diskon,
        'nama_diskon'=>$nama_diskon,
        'keterangan'=>nl2br($keterangan),
        'status '=>1
     ];
     $this->db->insert('diskon', $data);
        $this->session->set_flashdata('pesan','<div class="alert alert-info">Data diskon Disimpan</div>');
            redirect('user/admin/diskon');

    }
    public function simpanedit(){
     
     $id_diskon = $this->input->post('id_diskon');
     $jenis = $this->input->post('jenis');
     $diskon = $this->input->post('diskon');
     $nama_diskon = $this->input->post('nama_diskon');
     $keterangan = $this->input->post('keterangan');
     $status = $this->input->post('status');
     $data = [
         'jenis'=>$jenis,
        'besar_diskon'=>$diskon,
        'nama_diskon'=>$nama_diskon,
        'keterangan'=>nl2br($keterangan),
        'status'=>$status,
        
        'updated_at'=>date('Y-m-d H:i:s')
     ];
     $where = [
        'id_diskon'=>$id_diskon,
     ];
     $this->db->update('diskon', $data, $where);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data diskon Diperbaharui</div>');
            redirect('user/admin/diskon');

    }


    public function hapus()
    {
                $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data diskon Dinonaktifkan</div>');
            $id_diskon = $this->input->post('id_diskon');
            $q = $this->db->query("UPDATE diskon set status='0' where id_diskon='$id_diskon'");
            
        
    }


}
