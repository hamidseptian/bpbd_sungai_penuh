<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fnb extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
        ]);
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
        if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - FnB';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah FnB
              </button>';
        $q = $this->db->query("SELECT  id_fnb ,jenis,produk, harga, modal, status from fnb ")->result_array();
        $data['fnb'] = $q;
        $this->template->load('template/user_adminlte','user/admin/fnb/data_fnb', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_fnb = $this->input->post('id_fnb');
            $q = $this->db->query("SELECT  id_fnb ,jenis,produk, harga, modal, status from fnb where id_fnb='$id_fnb'")->row_array();
            echo json_encode($q);
		// $this->load->view('template/admin');
	}




    public function simpan(){
     
     $jenis = $this->input->post('jenis');
     $fnb = $this->input->post('fnb');
     $harga = $this->input->post('harga');
     $modal = $this->input->post('modal');
     $data = [
        'jenis'=>$jenis,
        'produk'=>$fnb,
        'harga'=>$harga,
        'modal'=>$modal,
        'status '=>1
     ];
     $this->db->insert('fnb', $data);
        $this->session->set_flashdata('pesan','<div class="alert alert-info">Data FnB Disimpan</div>');
            redirect('user/admin/fnb');

    }
    public function simpanedit(){
     
     $id_fnb = $this->input->post('id_fnb');
     $jenis = $this->input->post('jenis');
     $fnb = $this->input->post('fnb');
     $harga = $this->input->post('harga');
     $modal = $this->input->post('modal');
     $status = $this->input->post('status');
     $data = [
         'jenis'=>$jenis,
        'produk'=>$fnb,
        'modal'=>$modal,
        'harga'=>$harga,
        'status'=>$status,
        'updated_at'=>date('Y-m-d H:i:s')
     ];
     $where = [
        'id_fnb'=>$id_fnb,
     ];
     $this->db->update('fnb', $data, $where);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data fnb Diperbaharui</div>');
            redirect('user/admin/fnb');

    }


    public function hapus()
    {
                $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data fnb Dinonaktifkan</div>');
            $id_fnb = $this->input->post('id_fnb');
            $q = $this->db->query("UPDATE fnb set status='0' where id_fnb='$id_fnb'");
            
        
    }


}
