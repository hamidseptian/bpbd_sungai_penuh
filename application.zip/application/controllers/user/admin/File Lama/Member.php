<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model', 
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='2') {
            redirect('auth/login/kick');
           
        }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - Jenis Member';

        $data['breadchumb'] = '<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah Jenis Member
              </button>';
        $q = $this->db->query("SELECT id_jenis_member, jenis_member,biaya,masa_aktif,satuan_masa_aktif,status,  wajib_register  from jenis_member ")->result_array();
        $data['jenis_member'] = $q;
        $this->template->load('template/user_adminlte','user/admin/jenis_member/data_jenis_member', $data);

        // $this->load->view('template/user_adminlte');
    }

	public function edit()
	{
		
            $id_member = $this->input->post('id_jenis_member');
            $q = $this->db->query("SELECT id_jenis_member, jenis_member,biaya,masa_aktif,satuan_masa_aktif,status, wajib_register  from jenis_member where id_jenis_member='$id_member'")->row_array();
            echo json_encode($q);
		// $this->load->view('template/admin');
	}




    public function simpan(){
     
     $jenis_member = $this->input->post('jenis_member');
     $masa_aktif = $this->input->post('masa_aktif');
     $satuan_masa_aktif = $this->input->post('satuan_masa_aktif');
     $wajib_register = $this->input->post('wajib_register');
     $wajib_register = $wajib_register == true ? 1 : 0 ;
     $biaya = $this->input->post('biaya');
     $data = [
        'jenis_member'=>$jenis_member,
        'masa_aktif'=>$masa_aktif,
        'satuan_masa_aktif'=>$satuan_masa_aktif,
        'biaya'=>$biaya,
        'wajib_register'=>$wajib_register,
        'status'=>1
     ];
     $this->db->insert('jenis_member', $data);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Jenis Member Disimpan</div>');
            redirect('user/admin/member');

    }
    public function simpanedit(){
     
     $id_jenis_member = $this->input->post('id_jenis_member');
     $jenis_member = $this->input->post('jenis_member');
     $masa_aktif = $this->input->post('masa_aktif');
     $satuan_masa_aktif = $this->input->post('satuan_masa_aktif');
     $biaya = $this->input->post('biaya');
     
     $wajib_register = $this->input->post('wajib_register');
     $wajib_register = $wajib_register == true ? 1 : 0 ;
     $status = $this->input->post('status');
     $data = [
        'jenis_member'=>$jenis_member,
        'masa_aktif'=>$masa_aktif,
        'satuan_masa_aktif'=>$satuan_masa_aktif,
        'biaya'=>$biaya,
        'wajib_register'=>$wajib_register,
        'status'=>$status
     ];
     $where = [
        'id_jenis_member'=>$id_jenis_member,
     ];
     $this->db->update('jenis_member', $data, $where);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Jenis Member Diperbaharui</div>');
            redirect('user/admin/member');

    }


    public function hapus()
    {
             $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Jenis Member Dinonaktifkan</div>');
            $id_member = $this->input->post('id_jenis_member');
            $q = $this->db->query("UPDATE jenis_member set status='0' where id_jenis_member='$id_member'");
            
        
    }


}
