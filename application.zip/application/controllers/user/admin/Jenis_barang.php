<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis_barang extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model', 
        ]);
        
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
        //   if ($id_hak_akses!='2') {
        //     redirect('auth/login/kick');
           
        // }
    }





    public function index()
    {
        $data['judul'] = 'Master Data - Jenis Barang';
        $data['breadchumb'] = ' <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah jenis barang
              </button>';
        $q = $this->db->query("SELECT  id_jenis_barang,jenis_barang,status from jenis_barang ")->result_array();
        $data['jenis_barang'] = $q;
        $this->template->load('template/user_adminlte','user/admin/jenis_barang/data_jenis_barang', $data);

        // $this->load->view('template/user_adminlte');
    }


    public function detail($id_jenis_barang)
    {
        $data['breadchumb'] = '

              <a href="'.base_url('user/admin/jenis_barang/').'" class="btn btn-info btn-sm" >Kembali</a>
               <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#tambah">
                Tambah Paket jenis_barang
              </button>';

        $id_jenis_barang = enkripsi($id_jenis_barang, 'D');
        $q = $this->db->query("SELECT  id_jenis_barang,jenis_barang,status from jenis_barang where id_jenis_barang='$id_jenis_barang'")->row_array();
        $q_detail = $this->db->query("SELECT  id_detail_jenis_barang, id_jenis_barang, nama_paket_jenis_barang, banyak_pertemuan, masa_aktif, satuan_masa_aktif, biaya, status from detail_jenis_barang where id_jenis_barang='$id_jenis_barang'")->result_array();
        $data['judul'] = 'Master Data - jenis_barang <br><small>Detail jenis_barang '.$q['jenis_barang'].'</small>';
        $data['jenis_barang'] = $q;
        $data['detail_jenis_barang'] = $q_detail;
        $this->template->load('template/user_adminlte','user/admin/jenis_barang/detail_jenis_barang', $data);

        // $this->load->view('template/user_adminlte');
    }




    public function simpan_detail(){
     
     $id_jenis_barang = $this->input->post('id_jenis_barang');
     $nama_paket = $this->input->post('nama_paket');
     $masa_aktif = $this->input->post('masa_aktif');
     $satuan_masa_aktif = $this->input->post('satuan_masa_aktif');
     $pertemuan = $this->input->post('pertemuan');
     $biaya = $this->input->post('biaya');
     $data = [
        'nama_paket_jenis_barang'=>$nama_paket,
        'id_jenis_barang'=>$id_jenis_barang,
        'masa_aktif'=>$masa_aktif,
        'satuan_masa_aktif'=>$satuan_masa_aktif,
        'biaya'=>$biaya,
        'banyak_pertemuan'=>$pertemuan,
        'status'=>1
     ];
     $this->db->insert('detail_jenis_barang', $data);
     $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Jenis Member Disimpan</div>');
            redirect('user/admin/jenis_barang/detail/'.enkripsi($id_jenis_barang));

    }

	public function edit()
	{
		
            $id_jenis_barang = $this->input->post('id_jenis_barang');
            $q = $this->db->query("SELECT id_jenis_barang,jenis_barang,status from jenis_barang where id_jenis_barang='$id_jenis_barang'")->row_array();
            echo json_encode($q);
		// $this->load->view('template/admin');
	}




    public function edit_detail()
    {
        
            $id_detail_jenis_barang = $this->input->post('id_detail_jenis_barang');
            $q = $this->db->query("SELECT  id_detail_jenis_barang, id_jenis_barang, nama_paket_jenis_barang, banyak_pertemuan, masa_aktif, satuan_masa_aktif, biaya, status from detail_jenis_barang where id_detail_jenis_barang='$id_detail_jenis_barang'")->row_array();
            echo json_encode($q);
        // $this->load->view('template/admin');
    }




    public function simpan(){
     
     $jenis_barang = $this->input->post('jenis_barang');
     $data = [
        'jenis_barang'=>$jenis_barang,
        'status'=>1
     ];
     $this->db->insert('jenis_barang', $data);
      $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data jenis_barang Disimpan</div>');
            redirect('user/admin/jenis_barang');

    }
    public function simpanedit(){
     
     $jenis_barang = $this->input->post('jenis_barang');
     $status = $this->input->post('status');
     $id_jenis_barang = $this->input->post('id_jenis_barang');
     $data = [
        'jenis_barang'=>$jenis_barang,
        'status'=>$status
     ];
     $where = [
        'id_jenis_barang'=>$id_jenis_barang,
     ];
     $this->db->update('jenis_barang', $data, $where);
      $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data jenis_barang Diperbaharui</div>');
            redirect('user/admin/jenis_barang');

    }

    public function simpanedit_detail(){
     
     
     $id_jenis_barang = $this->input->post('id_jenis_barang');
     $nama_paket = $this->input->post('nama_paket');
     $masa_aktif = $this->input->post('masa_aktif');
     $satuan_masa_aktif = $this->input->post('satuan_masa_aktif');
     $pertemuan = $this->input->post('pertemuan');
     $biaya = $this->input->post('biaya');

     $status = $this->input->post('status');
     $id_detail_jenis_barang = $this->input->post('id_detail_jenis_barang');
     $data = [
        'nama_paket_jenis_barang'=>$nama_paket,
        'id_jenis_barang'=>$id_jenis_barang,
        'masa_aktif'=>$masa_aktif,
        'satuan_masa_aktif'=>$satuan_masa_aktif,
        'biaya'=>$biaya,
        'banyak_pertemuan'=>$pertemuan,
        'status'=>$status
     ];
     $where = [
        'id_detail_jenis_barang'=>$id_detail_jenis_barang,
     ];
     $this->db->update('detail_jenis_barang', $data, $where);
      $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Paket jenis_barang Diperbaharui</div>');
            redirect('user/admin/jenis_barang/detail/'.enkripsi($id_jenis_barang));

    }


    public function hapus()
    {
            $id_jenis_barang = $this->input->post('id_jenis_barang');
            $q = $this->db->query("UPDATE jenis_barang set status='0' where id_jenis_barang='$id_jenis_barang'");
            $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data jenis_barang Dinonaktifkan</div>');
            
        
    }


    public function nonaktifkan_detail_jenis_barang()
    {
            $id_detail_jenis_barang = $this->input->post('id_detail_jenis_barang');
            $jenis_barang = $this->input->post('jenis_barang');
            $q = $this->db->query("UPDATE detail_jenis_barang set status='0' where id_detail_jenis_barang='$id_detail_jenis_barang'");
            $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data Paket jenis_barang '.$jenis_barang.' Dinonaktifkan</div>');
            
        
    }


}
