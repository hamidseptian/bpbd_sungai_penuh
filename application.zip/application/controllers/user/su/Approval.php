<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Approval extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
        // $this->form_validation->CI = &$this;
        $this->load->model([
            'datatables_model'                         => 'datatables_model',
    //         'paket_pekerjaan/master_paket_model'      => 'master_paket_model',
    //         'data_apbd/data_apbd_model'      => 'data_apbd_model',
    //         'data_apbd/master_data_apbd_model' => 'master_data_apbd_model',

    // 'Laporan/realisasi_akumulasi_model'     => 'realisasi_akumulasi_model',
        ]);
        $id_hak_akses = $this->session->userdata('id_hak_akses'); 
          if ($id_hak_akses!='1') {
            redirect('auth/login/kick');
        }
    }





    public function pengeluaran()
    {
       
          $data['breadchumb'] = ' 
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_harian">
              Filter Harian
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_bulanan">
              Filter Bulanan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_tahunan">
              Filter Tahunan
            </button>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#filter_periode">
              Filter Periode
            </button>

            ';






        $filter = $this->input->get('filter');

        if ($this->input->get('filter')) {
            if ($filter=='harian') {
                $tgl_daftar = $this->input->get('tgl');
                $q_filter = "where tgl_transaksi='$tgl_daftar'";
                $caption = "Laporan pengeluaran tanggal ".$tgl_daftar;

            }
            else if ($filter=='bulanan') {
                $bulan = $this->input->get('bulan');
                $tahun = $this->input->get('tahun');
                $q_filter = "where month(tgl_transaksi)='$bulan' and year(tgl_transaksi)='$tahun'";
                $data['bulan'] = $bulan;
                $data['tahun'] = $tahun;
                $caption = "Laporan pengeluaran bulan ".bulan_global(intval($bulan))." ".$tahun;
                # code...
            }
            else if ($filter=='tahunan') {
                $tahun = $this->input->get('tahun');
                $q_filter = "where  year(tgl_transaksi)='$tahun'";
                $data['tahun'] = $tahun;
                $caption = "Laporan pengeluaran tahun  ".$tahun;
                # code...
            }
            else if ($filter=='periode') {
                $tgl_awal = $this->input->get('tgl_awal');
                $tgl_akhir = $this->input->get('tgl_akhir');
                $q_filter = "where tgl_transaksi between '$tgl_awal' and '$tgl_akhir' ";

                $caption = "Laporan pengeluaran tanggal ".$tgl_awal.' s/d '.$tgl_akhir;
                # code...
            }
            else if ($filter=='semua') {
                $q_filter = "";

                $caption = "Laporan pengeluaran keseluruhan ";
                # code...
            }
        }else{
            $tgls = date('Y-m-d');
                $q_filter = "where tgl_transaksi='$tgls'";

                $caption = "Laporan pengeluaran hari ini <br>".$tgls;

        }




         $data['judul'] = 'Pengeluaran - Keuangan <br> '.'<small>'.$caption.'</small>';
           $q = $this->db->query("SELECT 

        p.id_pengeluaran, p.tgl_transaksi, p.besar_pengeluaran, p.keterangan, p.id_user, p.file, p.status, p.approval, p.tgl_approval, p.keterangan_approval , u.nama 
        from pengeluaran p 
            left join user u on p.id_user = u.id_user 
            $q_filter
            order by id_pengeluaran desc")->result_array();
        
        $data['pengeluaran'] = $q;
        $data['status'] = ['Menunggu Verifikasi','Telah Di Verifikasi','Dibatalkan'];
        $data['approval'] = ['Pengeluaran Ditolak','Pengeluaran Di ACC'];
        $this->template->load('template/user_adminlte','user/master/approval/data_pengeluaran', $data);

    }


    public function approve_pengeluaran()
    {
        
        $id_pengeluaran = $this->input->post('id_pengeluaran');
        $approval = $this->input->post('approval');
        $keterangan_approval = $this->input->post('keterangan_approval');

        $where = ['id_pengeluaran'=>$id_pengeluaran];
        $data = [
            'approval'=>$approval,
            'status'=>1,
            'keterangan_approval'=>nl2br($keterangan_approval)
        ];
        $this->db->update('pengeluaran',$data, $where);
        $approv = ['Pengeluaran Ditolak','Pengeluaran Di ACC'];
        $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'.$approv[$approval].'</div>');
            $redirect = 'user/master/approval/pengeluaran';

            redirect($redirect);

    }





    public function detail_transaksi()
    {
        $id_transaksi = $this->input->post('id_pengeluaran');
       
             $q_transaksi = $this->db->query("SELECT 
                p.*,
                u.nama as kasir, u.jabatan
                from pengeluaran p 
                left join user u on p.id_user = u.id_user
                where p.id_pengeluaran='$id_transaksi'
                ");
            $output = [
                'transaksi'=>$q_transaksi->row_array(),
            ];
            echo json_encode($output);
        // $this->load->view('template/admin');
    }







    public function simpan_pengeluaran(){
        $config['upload_path']          = './file/pengeluaran';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $new_file_name=date("Ymdhi");
        // $config['file_name']            = $new_file_name;
        $nama_file = $_FILES['berkas']['name'] ;
        $pecah = explode(".", $nama_file);
        $extensi = end($pecah);
        $new_file_name=date("Ymdhi").'.'.$extensi;
        $config['file_name']            = $new_file_name;
            $config['max_size']         = '10000';

        $tgl = $this->input->post('tgl');
        $keterangan = $this->input->post('keterangan');
        $rp = $this->input->post('rp');
        $id_user = $this->session->userdata('id_user');


      

        $this->load->library('upload', $config);
      
    
        if ( ! $this->upload->do_upload('berkas')){
            
                $pesan = "<strong>Upload Failed ! </strong><br>".$pesan_ERROR;



        }else{
            array('upload_data' => $this->upload->data());
            $error = 0;
            $pesan = "<strong>Upload Success ! </strong><br>Data pengeluaran disimpan";
            $warna = 'alert alert-success';
            // $this->load->view('v_upload_sukses', $data);
            $redirect = 'user/kassa/pengeluaran';

             $data_insert = [
                    'tgl_transaksi'=>$tgl ,
                    'besar_pengeluaran'=>$rp ,
                    'keterangan'=>nl2br($keterangan) ,
                    'id_user'=>$id_user ,
                    'status'=>0,
                    // 'aproval'=>$new_file_name ,
                    'file'=>$new_file_name ,
                   
               
              
            ];

                $this->db->insert('pengeluaran', $data_insert);
        }


           
          $this->session->set_flashdata('pesan','<div class="'.$warna.'"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'.$pesan.'</div>');

            redirect($redirect);

    }






    public function aktifkan()
    {
            $id_kartu = $this->input->post('id_kartu');
            $q = $this->db->query("UPDATE kartu_member set status=0");
            $q = $this->db->query("UPDATE kartu_member set status=1 where id_kartu_member='$id_kartu'");
             $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data kartu aktif diperbaharui</div>');
            
        
    }

    public function hapus()
    {
            $id_kartu = $this->input->post('id_kartu');
            $file = $this->input->post('file');
            $q = $this->db->query("DELETE from pengeluaran where id_pengeluaran='$id_kartu'");
             $this->session->set_flashdata('pesan','<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Data pengeluaran dihapus</div>');
            
        
    }


}
